# CodeDojo Daily: DailyDebug Derby

> **Campus Placement Daily Coding & Team Contest Arena**  
> Built for Computer Science batches preparing for technical interviews through structured daily problem releases, collaborative peer accountability, and real-time squad leaderboards.

---

## 🎯 Project Overview & Objective

Computer science students preparing for campus placements struggle to maintain daily coding consistency without structured releases and collaborative accountability. Existing practice platforms cater primarily to individual problem solvers and lack engaging, lightweight team contest formats tailored for college student cohorts.

**CodeDojo Daily** bridges this gap by combining:
1. **Curated Daily Problem Drops** with placement difficulty ratings and constraints.
2. **In-Browser Monaco Code Snippet Workspace** with multi-language execution and test case verification.
3. **Peer Squad Roster Formation (3–4 Members)** with invite codes and captain assignments.
4. **Live Team Contest Leaderboards** featuring real-time ranking jumps powered by:
   $$\text{TeamScore} = \sum \text{MemberScores} + \text{StreakBonus} + \text{SpeedBonus}$$
5. **Weekend Sprint War Arena** with live 60-minute countdown and a 1.5x point multiplier.
6. **Non-Spoiler AI Hint Assistant** with automated 3-fail unlocking and code diagnosis.
7. **Levenshtein Code Plagiarism Checker** comparing submission similarity and syntax token diffs.
8. **GitHub-Style Contribution Heatmap Calendar** to track placement preparation streaks.

---

## 🚀 Key Features

### 1. Core Must-Have Features
- **Daily Problem Release Hub**: Features today's challenge (*"Two Sum Variant: Minimal Element Gap"*) with problem statement, constraints, example test cases, countdown expiration timer, and placement interview tips.
- **Problem Tag & Difficulty Filter**: Comprehensive repository of **26 algorithmic challenges** categorized across Easy, Medium, and Hard tiers, filterable by algorithmic domain (*Arrays & Hash Maps, Two Pointers, Sliding Window, Dynamic Programming, Greedy, Monotonic Stack, Graph & Matrix, Binary Search, Trees & BFS*).
- **In-Browser Code Snippet Workspace**: Integrated Monaco Editor with syntax highlighting, language selector (*JavaScript / Python*), pre-populated starter code, sample test cases runner, custom test case drawer, and an optional **"Load Optimal Solution"** button for quick demonstration.
- **Client/Server Test Runner & Sandbox**: Evaluates code against public sample cases and hidden edge cases (5 test cases per problem). Reliably returns status badges: `Accepted`, `Wrong Answer`, `Time Limit Exceeded`, or `Runtime Error` with execution runtime (ms) and memory stats.
- **Team Creation & Roster Management**: Students form 3–4 member peer squads with customizable avatars, squad taglines, college batch tags, and 6-character invite codes (`BEAST7`, `NINJA9`, `BRAWL4`).
- **Team Contest Leaderboard**: Dynamic ranking table with podium medals (🥇, 🥈, 🥉), score breakdowns (Base, Streak, Speed), and real-time rank jump badges (`▲ +2`). Auto-refreshes every 5 seconds.

### 2. Stretch Features (Fully Implemented)
- **Live Countdown Team War Arena**: Synchronized 60-minute sprint sprint mode with a ticking countdown clock, active 1.5x bonus multiplier, sprint problem queue, and a real-time battle event ticker (`"Alex Chen from Binary Beasts passed Two Sum Variant! +350 pts"`).
- **AI Hint Assistant**: Progressive 3-tier clue progression:
  - *Clue 1*: Intuitive perspective (non-spoiler concept).
  - *Clue 2*: Recommended data structures & algorithmic pattern.
  - *Clue 3*: Pseudo-code blueprint & edge-case shield.
  - *Code Pitfall Diagnosis*: Scans user code for common traps (e.g., $O(n^2)$ nested loops, infinite loops, boundary errors). Automatically triggers after 3 failed test runs.
- **Code Plagiarism Similarity Checker**: Calculates normalized **Levenshtein edit distance** and **Tokenized Jaccard similarity**. Includes one-click demo presets (*Copied with Renamed Variables* vs *Independent Implementations*) and customizable side-by-side diff comparison.
- **Daily Challenge Streak Calendar**: 20-week GitHub-style contribution heatmap visualizing daily solves, active streaks 🔥, longest streaks ⚡, and placement readiness percentile.

---

## 🛠️ Tech Stack & Architecture

- **Frontend**: React 18, TypeScript, Vite, Monaco Editor (`@monaco-editor/react`), Tailwind CSS, Lucide Icons, Canvas Confetti.
- **Backend**: Node.js v26, Express, TypeScript (`tsx`).
- **Database**: SQLite using Node's high-performance built-in `node:sqlite` (`DatabaseSync`), zero external native C++ dependencies.
- **Code Execution**: Sandboxed runner using Node's `node:vm` with memory isolation and configurable timeouts (2000ms), alongside Python CLI execution.
- **Scoring Engine**: Deduplication engine awarding points strictly to the first accepted solve per problem per user, preventing score manipulation.

---

## 🎬 What a Good Demo Looks Like (Step-by-Step)

1. **Launch the Web App**: Open [http://localhost:5000](http://localhost:5000) in your browser.
2. **View Today's Challenge**: The hero banner showcases today's challenge: *"Two Sum Variant: Minimal Element Gap"*.
3. **Check the Current Leaderboard**: Click **Leaderboard** tab:
   - Rank 1: **AlgoNinjas** (2850 pts)
   - Rank 2: **ByteBrawlers** (2590 pts)
   - Rank 3: **Binary Beasts** (2520 pts) — *Your Squad!*
4. **Open the Code Workspace**: Click **"Solve Today's Challenge"** or click the problem from the library.
5. **Run Tests**: Click **"Load Optimal Solution"** (or type out the hash map solution) and click **"Run Tests"**. Notice all test cases turn green with execution time under 10ms.
6. **Submit Code & Climb to #1**: Click **"Submit Solution"**.
   - Confetti explodes across the screen! 🎉
   - Green notification banner announces: *"Accepted! +188 pts awarded! Your squad 'Binary Beasts' gained +575 pts and is now Rank #1!"*
   - Squad **Binary Beasts** instantly climbs from **3rd to 1st place** with a glowing `▲ +2` rank badge!
7. **Inspect Team War Arena**: Switch to **Team War Sprint** tab to see the 60-minute countdown timer and the live battle feed showing Alex's recent solve.
8. **Test Plagiarism Checker**: Switch to **Plagiarism Check** tab and click **"Demo Copied Pair"** to see Levenshtein distance detecting a 91% similarity with a `High Plagiarism Alert` badge.
9. **Reset Demo Anytime**: Click **"Reset Demo"** in the top navigation bar to reset Binary Beasts back to 3rd place to replay the live climb for other judges.

---

## 📦 How to Run

### Single-Command Start (Production Fullstack)
```bash
npm start
```
*Opens the fullstack server on [http://localhost:5000](http://localhost:5000), serving both the API and the React frontend.*

### Development Mode (Independent Frontend & Backend)
Terminal 1 (Backend Server):
```bash
npm run dev:server
```
Terminal 2 (Vite Frontend with Hot Reload):
```bash
npm run dev:client
```
*Vite dev server starts on [http://localhost:5173](http://localhost:5173) with automated API proxy to port 5000.*

### Automated Verification Test Suite
```bash
npm run test:verification
```
*Runs the 9-point end-to-end automated test suite verifying all APIs, execution runners, scoring logic, and plagiarism algorithms.*
