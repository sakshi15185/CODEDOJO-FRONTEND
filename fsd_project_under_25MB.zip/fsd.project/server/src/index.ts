import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db } from './db/database.js';
import { CodeRunner } from './services/runner.js';
import { ScoringService } from './services/scoring.ts';
import { PlagiarismService } from './services/plagiarism.js';
import { AIHintAssistant } from './services/aiHint.js';
import { Submission } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Log incoming requests
app.use((req, res, next) => {
  if (req.url.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.url}`);
  }
  next();
});

// --- PROBLEMS ENDPOINTS ---
app.get('/api/problems', (req, res) => {
  try {
    const { difficulty, category, tag, search } = req.query;
    let problems = db.getProblems();

    if (difficulty && difficulty !== 'All') {
      problems = problems.filter(p => p.difficulty.toLowerCase() === (difficulty as string).toLowerCase());
    }

    if (category && category !== 'All') {
      problems = problems.filter(p => p.category.toLowerCase().includes((category as string).toLowerCase()));
    }

    if (tag && tag !== 'All') {
      problems = problems.filter(p => p.tags.some(t => t.toLowerCase() === (tag as string).toLowerCase()));
    }

    if (search) {
      const q = (search as string).toLowerCase();
      problems = problems.filter(
        p => p.title.toLowerCase().includes(q) || p.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    res.json({ success: true, count: problems.length, problems });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/problems/daily', (req, res) => {
  try {
    const daily = db.getDailyProblem();
    if (!daily) {
      return res.status(404).json({ success: false, error: 'No daily problem available' });
    }
    const publicTestCases = db.getTestCases(daily.id, false);
    res.json({ success: true, problem: daily, testCases: publicTestCases });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/problems/:idOrSlug', (req, res) => {
  try {
    const problem = db.getProblemById(req.params.idOrSlug);
    if (!problem) {
      return res.status(404).json({ success: false, error: 'Problem not found' });
    }
    const publicTestCases = db.getTestCases(problem.id, false);
    res.json({ success: true, problem, testCases: publicTestCases });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- CODE RUNNER & SUBMISSIONS ---

// Fast run against public sample test cases (interactive workspace runner)
app.post('/api/run', async (req, res) => {
  try {
    const { problemId, code, language, customInput } = req.body;
    const problem = db.getProblemById(problemId);
    if (!problem) {
      return res.status(404).json({ success: false, error: 'Problem not found' });
    }

    let testCases = db.getTestCases(problemId, false);

    // If user provided a custom input to run
    if (customInput && customInput.trim()) {
      testCases = [
        {
          id: 'custom-1',
          problemId,
          input: customInput,
          expectedOutput: '""',
          isHidden: false,
          explanation: 'User custom test case'
        }
      ];
    }

    const result = await CodeRunner.execute(code, language || 'javascript', problem.functionName, testCases);
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Formal submission: runs against all public + hidden test cases, updates scores
app.post('/api/submit', async (req, res) => {
  try {
    const { problemId, userId, code, language } = req.body;
    const problem = db.getProblemById(problemId);
    if (!problem) {
      return res.status(404).json({ success: false, error: 'Problem not found' });
    }

    const user = db.getUserById(userId || 'user-alex');
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Run against ALL test cases (public + hidden)
    const allTestCases = db.getTestCases(problemId, true);
    const execResult = await CodeRunner.execute(code, language || 'javascript', problem.functionName, allTestCases);

    const isAccepted = execResult.status === 'Accepted';

    // Process scoring via ScoringService
    const scoreOutcome = ScoringService.processSubmissionScore(
      user.id,
      problem,
      isAccepted,
      execResult.runtimeMs
    );

    // Record submission
    const submission: Submission = {
      id: 'sub-' + Math.random().toString(36).substring(2, 9),
      problemId: problem.id,
      userId: user.id,
      teamId: user.teamId,
      code,
      language: language || 'javascript',
      status: execResult.status,
      runtimeMs: execResult.runtimeMs,
      memoryMb: execResult.memoryMb,
      passedCount: execResult.passedCount,
      totalCount: execResult.totalCount,
      pointsAwarded: scoreOutcome.pointsAwarded,
      createdAt: new Date().toISOString(),
      details: execResult.details
    };

    db.createSubmission(submission);

    // Return comprehensive response
    const updatedLeaderboard = db.getTeams();
    const updatedUser = db.getUserById(user.id);

    res.json({
      success: true,
      submission,
      execution: execResult,
      scoreOutcome,
      updatedUser,
      leaderboard: updatedLeaderboard
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/submissions', (req, res) => {
  try {
    const { problemId, userId, teamId } = req.query;
    const submissions = db.getSubmissions({
      problemId: problemId as string,
      userId: userId as string,
      teamId: teamId as string
    });
    res.json({ success: true, count: submissions.length, submissions });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- TEAMS & LEADERBOARDS ---
app.get('/api/teams', (req, res) => {
  try {
    const teams = db.getTeams();
    res.json({ success: true, count: teams.length, teams });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/teams/:id', (req, res) => {
  try {
    const team = db.getTeamById(req.params.id);
    if (!team) {
      return res.status(404).json({ success: false, error: 'Team not found' });
    }
    res.json({ success: true, team });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/teams', (req, res) => {
  try {
    const { name, tagline, avatar, batch, creatorUserId } = req.body;
    if (!name || !creatorUserId) {
      return res.status(400).json({ success: false, error: 'Name and creatorUserId are required' });
    }
    const team = db.createTeam({
      name,
      tagline: tagline || 'Code and Conquer',
      avatar: avatar || '🚀',
      batch: batch || 'Batch 2026',
      creatorUserId
    });
    res.json({ success: true, team });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/teams/join', (req, res) => {
  try {
    const { joinCode, userId } = req.body;
    if (!joinCode || !userId) {
      return res.status(400).json({ success: false, error: 'Join code and userId are required' });
    }
    const team = db.joinTeamByCode(joinCode, userId);
    if (!team) {
      return res.status(404).json({ success: false, error: 'Invalid join code. Squad not found.' });
    }
    res.json({ success: true, team });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// --- USERS ---
app.get('/api/users', (req, res) => {
  try {
    const users = db.getUsers();
    res.json({ success: true, users });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/users/:id', (req, res) => {
  try {
    const user = db.getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- DERBY LIVE WAR ARENA ---
app.get('/api/derby', (req, res) => {
  try {
    const session = db.getDerbySession();
    res.json({ success: true, session });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- AI HINT ASSISTANT ---
app.post('/api/hints', (req, res) => {
  try {
    const { problemId, failedCount, userCode } = req.body;
    const problem = db.getProblemById(problemId);
    if (!problem) {
      return res.status(404).json({ success: false, error: 'Problem not found' });
    }
    const hints = AIHintAssistant.generateHints(problem, failedCount || 1, userCode);
    res.json({ success: true, hints });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- CODE PLAGIARISM CHECKER ---
app.post('/api/plagiarism/compare', (req, res) => {
  try {
    const { code1, code2 } = req.body;
    if (!code1 || !code2) {
      return res.status(400).json({ success: false, error: 'code1 and code2 are required' });
    }
    const analysis = PlagiarismService.compareSubmissions(code1, code2);
    res.json({ success: true, analysis });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- DEMO RESET ---
app.post('/api/demo/reset', (req, res) => {
  try {
    db.resetDemoState();
    const teams = db.getTeams();
    const user = db.getUserById('user-alex');
    res.json({ success: true, message: 'Demo state successfully reset to initial baseline', teams, user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- SERVE STATIC FRONTEND IN PRODUCTION ---
const clientDistPath = path.resolve(__dirname, '../../client/dist');
if (fs.existsSync(clientDistPath)) {
  console.log(`[Server] Serving static frontend from ${clientDistPath}`);
  app.use(express.static(clientDistPath));
  app.get('*', (req, res, next) => {
    if (req.url.startsWith('/api')) return next();
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`[CodeDojo Daily Server] Running on http://localhost:${PORT}`);
});
