export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface TestCase {
  id: string;
  problemId: string;
  input: string; // JSON string representation of arguments
  expectedOutput: string; // JSON string representation of return value
  isHidden: boolean;
  explanation?: string;
}

export interface Problem {
  id: string;
  title: string;
  slug: string;
  difficulty: Difficulty;
  category: string;
  tags: string[];
  description: string;
  inputFormat: string;
  outputFormat: string;
  constraints: string[];
  examples: {
    input: string;
    output: string;
    explanation?: string;
  }[];
  starterCode: {
    javascript: string;
    python: string;
  };
  functionName: string;
  isDaily: boolean;
  dailyDate?: string;
  points: number;
  acceptanceRate: number;
  solvedCount: number;
}

export interface User {
  id: string;
  username: string;
  name: string;
  avatar: string;
  batch: string;
  college: string;
  teamId: string | null;
  role: 'Captain' | 'Member';
  currentStreak: number;
  maxStreak: number;
  totalSolved: number;
  score: number;
  activityHistory: { [date: string]: number }; // e.g. "2026-11-20": 2
}

export interface Team {
  id: string;
  name: string;
  tagline: string;
  avatar: string;
  joinCode: string;
  batch: string;
  totalScore: number;
  baseScore: number;
  streakBonus: number;
  speedBonus: number;
  solveCount: number;
  rank: number;
  previousRank: number;
  rankChange: number;
  members: User[];
  completedProblemIds: string[];
}

export interface Submission {
  id: string;
  problemId: string;
  userId: string;
  teamId: string | null;
  code: string;
  language: 'javascript' | 'python';
  status: 'Accepted' | 'Wrong Answer' | 'Time Limit Exceeded' | 'Runtime Error';
  runtimeMs: number;
  memoryMb: number;
  passedCount: number;
  totalCount: number;
  pointsAwarded: number;
  createdAt: string;
  details?: {
    testCaseId: string;
    passed: boolean;
    input: string;
    expected: string;
    actual?: string;
    error?: string;
    isHidden: boolean;
  }[];
}

export interface DerbyWarEvent {
  id: string;
  timestamp: string;
  teamId: string;
  teamName: string;
  userId: string;
  userName: string;
  userAvatar: string;
  problemId: string;
  problemTitle: string;
  points: number;
  message: string;
}

export interface DerbySession {
  id: string;
  title: string;
  status: 'active' | 'upcoming' | 'completed';
  startTime: string;
  durationMinutes: number;
  multiplier: number;
  featuredProblemIds: string[];
  events: DerbyWarEvent[];
}
