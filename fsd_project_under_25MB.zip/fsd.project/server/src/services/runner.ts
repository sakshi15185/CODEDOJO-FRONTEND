import vm from 'node:vm';
import { spawn } from 'node:child_process';
import { TestCase } from '../types.js';

export interface TestExecutionResult {
  status: 'Accepted' | 'Wrong Answer' | 'Time Limit Exceeded' | 'Runtime Error';
  passedCount: number;
  totalCount: number;
  runtimeMs: number;
  memoryMb: number;
  details: {
    testCaseId: string;
    passed: boolean;
    input: string;
    expected: string;
    actual?: string;
    error?: string;
    isHidden: boolean;
  }[];
}

export class CodeRunner {
  static async execute(
    code: string,
    language: 'javascript' | 'python',
    functionName: string,
    testCases: TestCase[]
  ): Promise<TestExecutionResult> {
    if (language === 'javascript') {
      return this.executeJavaScript(code, functionName, testCases);
    } else {
      return this.executePython(code, functionName, testCases);
    }
  }

  private static executeJavaScript(
    userCode: string,
    functionName: string,
    testCases: TestCase[]
  ): TestExecutionResult {
    const startTime = performance.now();
    const details: TestExecutionResult['details'] = [];
    let passedCount = 0;
    let globalStatus: TestExecutionResult['status'] = 'Accepted';

    for (const tc of testCases) {
      let args: any[];
      try {
        args = JSON.parse(tc.input);
      } catch {
        args = [tc.input];
      }

      let expectedValue: any;
      try {
        expectedValue = JSON.parse(tc.expectedOutput);
      } catch {
        expectedValue = tc.expectedOutput;
      }

      const sandbox: any = {
        console: { log: () => {}, error: () => {}, warn: () => {} },
        Math,
        Array,
        Object,
        String,
        Number,
        Set,
        Map,
        Boolean,
        parseInt,
        parseFloat,
        Infinity,
        NaN
      };

      const context = vm.createContext(sandbox);

      const runnerScript = `
        ${userCode}
        if (typeof ${functionName} !== 'function') {
          throw new Error('Function ${functionName} is not defined.');
        }
        const __result = ${functionName}(...__args);
        __result;
      `;

      try {
        sandbox.__args = args;
        const script = new vm.Script(runnerScript);
        const tcStart = performance.now();
        const actualResult = script.runInContext(context, { timeout: 2000 });
        const tcTime = performance.now() - tcStart;

        const passed = this.deepCompare(actualResult, expectedValue);
        if (passed) {
          passedCount++;
        } else if (globalStatus === 'Accepted') {
          globalStatus = 'Wrong Answer';
        }

        details.push({
          testCaseId: tc.id,
          passed,
          input: tc.input,
          expected: tc.expectedOutput,
          actual: JSON.stringify(actualResult),
          isHidden: tc.isHidden
        });
      } catch (err: any) {
        const isTimeout = err.code === 'ERR_SCRIPT_EXECUTION_TIMEOUT' || err.message?.includes('timed out');
        if (isTimeout) {
          globalStatus = 'Time Limit Exceeded';
        } else if (globalStatus === 'Accepted') {
          globalStatus = 'Runtime Error';
        }

        details.push({
          testCaseId: tc.id,
          passed: false,
          input: tc.input,
          expected: tc.expectedOutput,
          error: isTimeout ? 'Time Limit Exceeded (2000ms)' : (err.message || 'Runtime execution error'),
          isHidden: tc.isHidden
        });
      }
    }

    const totalRuntime = Math.round((performance.now() - startTime) * 10) / 10;
    const memoryEstimate = Math.round((30 + Math.random() * 8) * 10) / 10;

    return {
      status: globalStatus,
      passedCount,
      totalCount: testCases.length,
      runtimeMs: totalRuntime,
      memoryMb: memoryEstimate,
      details
    };
  }

  private static async executePython(
    userCode: string,
    functionName: string,
    testCases: TestCase[]
  ): Promise<TestExecutionResult> {
    const startTime = performance.now();
    const details: TestExecutionResult['details'] = [];
    let passedCount = 0;
    let globalStatus: TestExecutionResult['status'] = 'Accepted';

    const testPayload = JSON.stringify(
      testCases.map(tc => ({
        id: tc.id,
        args: JSON.parse(tc.input),
        expected: JSON.parse(tc.expectedOutput),
        isHidden: tc.isHidden
      }))
    );

    const pythonHarness = `
import json, sys, time

${userCode}

payload = json.loads('''${testPayload.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}''')
results = []

fn = globals().get('${functionName}')
if not fn:
    print(json.dumps({"error": "Function ${functionName} is not defined"}))
    sys.exit(0)

for item in payload:
    args = item['args']
    try:
        if isinstance(args, list):
            res = fn(*args)
        else:
            res = fn(args)
        results.append({"id": item['id'], "actual": res})
    except Exception as e:
        results.append({"id": item['id'], "error": str(e)})

print(json.dumps({"results": results}))
`;

    try {
      const output = await this.runProcess('python', ['-c', pythonHarness], 3000);
      const parsed = JSON.parse(output.trim());

      if (parsed.error) {
        return {
          status: 'Runtime Error',
          passedCount: 0,
          totalCount: testCases.length,
          runtimeMs: Math.round(performance.now() - startTime),
          memoryMb: 35.2,
          details: testCases.map(tc => ({
            testCaseId: tc.id,
            passed: false,
            input: tc.input,
            expected: tc.expectedOutput,
            error: parsed.error,
            isHidden: tc.isHidden
          }))
        };
      }

      const resMap = new Map(parsed.results.map((r: any) => [r.id, r]));

      for (const tc of testCases) {
        const item: any = resMap.get(tc.id);
        const expected = JSON.parse(tc.expectedOutput);

        if (!item || item.error) {
          if (globalStatus === 'Accepted') globalStatus = 'Runtime Error';
          details.push({
            testCaseId: tc.id,
            passed: false,
            input: tc.input,
            expected: tc.expectedOutput,
            error: item?.error || 'Test failed to execute',
            isHidden: tc.isHidden
          });
        } else {
          const passed = this.deepCompare(item.actual, expected);
          if (passed) {
            passedCount++;
          } else if (globalStatus === 'Accepted') {
            globalStatus = 'Wrong Answer';
          }
          details.push({
            testCaseId: tc.id,
            passed,
            input: tc.input,
            expected: tc.expectedOutput,
            actual: JSON.stringify(item.actual),
            isHidden: tc.isHidden
          });
        }
      }
    } catch (err: any) {
      const isTimeout = err.message?.includes('TIMED_OUT');
      globalStatus = isTimeout ? 'Time Limit Exceeded' : 'Runtime Error';
      for (const tc of testCases) {
        details.push({
          testCaseId: tc.id,
          passed: false,
          input: tc.input,
          expected: tc.expectedOutput,
          error: isTimeout ? 'Time Limit Exceeded (3000ms)' : (err.message || 'Python execution error'),
          isHidden: tc.isHidden
        });
      }
    }

    return {
      status: globalStatus,
      passedCount,
      totalCount: testCases.length,
      runtimeMs: Math.round(performance.now() - startTime),
      memoryMb: 38.5,
      details
    };
  }

  private static runProcess(command: string, args: string[], timeoutMs: number): Promise<string> {
    return new Promise((resolve, reject) => {
      const proc = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
      let stdout = '';
      let stderr = '';

      const timer = setTimeout(() => {
        proc.kill();
        reject(new Error('TIMED_OUT'));
      }, timeoutMs);

      proc.stdout.on('data', chunk => (stdout += chunk.toString()));
      proc.stderr.on('data', chunk => (stderr += chunk.toString()));

      proc.on('close', code => {
        clearTimeout(timer);
        if (code !== 0 && !stdout.trim()) {
          reject(new Error(stderr || `Process exited with code ${code}`));
        } else {
          resolve(stdout);
        }
      });

      proc.on('error', err => {
        clearTimeout(timer);
        reject(err);
      });
    });
  }

  private static deepCompare(actual: any, expected: any): boolean {
    if (actual === expected) return true;
    if (actual === null || expected === null) return actual === expected;
    if (typeof actual !== typeof expected) return false;

    if (typeof actual === 'number' && typeof expected === 'number') {
      return Math.abs(actual - expected) < 1e-6;
    }

    if (Array.isArray(actual) && Array.isArray(expected)) {
      if (actual.length !== expected.length) return false;
      for (let i = 0; i < actual.length; i++) {
        if (!this.deepCompare(actual[i], expected[i])) return false;
      }
      return true;
    }

    if (typeof actual === 'object' && typeof expected === 'object') {
      const keysA = Object.keys(actual).sort();
      const keysB = Object.keys(expected).sort();
      if (keysA.length !== keysB.length) return false;
      for (let i = 0; i < keysA.length; i++) {
        if (keysA[i] !== keysB[i]) return false;
        if (!this.deepCompare(actual[keysA[i]], expected[keysB[i]])) return false;
      }
      return true;
    }

    return false;
  }
}
