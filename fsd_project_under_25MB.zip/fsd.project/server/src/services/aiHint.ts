import { Problem } from '../types.js';

export interface AIHintResponse {
  problemId: string;
  problemTitle: string;
  triggerReason: string;
  unlockedClues: {
    level: 1 | 2 | 3;
    title: string;
    content: string;
  }[];
  codeDiagnosis?: {
    likelyPitfall: string;
    suggestion: string;
  };
}

export class AIHintAssistant {
  private static HINT_KNOWLEDGE_BASE: Record<
    string,
    {
      clue1: string;
      clue2: string;
      clue3: string;
      commonBugs: { pattern: RegExp; issue: string; advice: string }[];
    }
  > = {
    'prob-1': {
      clue1:
        'Instead of checking all pairs with two nested loops (O(n²)), think about what value you need at each step. If you are currently at nums[j], what value complement = target - nums[j] would complete the sum?',
      clue2:
        'Use a Hash Map (Object/Map in JS, dict in Python) mapping each number seen so far to its index. Whenever target - nums[j] is in the map, evaluate |nums[i] - nums[j]| and keep track of the pair with minimal gap.',
      clue3:
        'Keep track of bestPair and minDiff = Infinity. Loop j from 0 to n-1: if map has complement = target - nums[j], compute diff = |nums[map[complement]] - nums[j]|. If diff < minDiff, update minDiff and bestPair = [min(i, j), max(i, j)]. Then save map[nums[j]] = j. Finally return bestPair || [].',
      commonBugs: [
        {
          pattern: /for\s*\([^)]*for\s*\(/,
          issue: 'Nested loops detected (O(n²) time complexity)',
          advice: 'A nested loop will cause Time Limit Exceeded on 10^5 elements. Replace with a single-pass Hash Map lookup.'
        },
        {
          pattern: /bestPair\s*=\s*\[j,\s*i\]/,
          issue: 'Wrong index ordering in return array',
          advice: 'The specification requires i < j. Ensure you return [min(i, j), max(i, j)].'
        }
      ]
    },
    'prob-2': {
      clue1:
        'Notice that only vowels need to be swapped, while consonants and special characters remain in their exact original positions.',
      clue2:
        'Use the Two Pointers technique: one pointer starting at index 0 and moving forward, and another pointer starting at the end of the string moving backward.',
      clue3:
        'Define a set of vowels {"a","e","i","o","u", "A","E","I","O","U"}. While left < right: advance left until s[left] is a vowel; retreat right until s[right] is a vowel; if left < right, swap and increment/decrement both.',
      commonBugs: [
        {
          pattern: /['"]aeiou['"](?!.*[AEIOU])/,
          issue: 'Missing uppercase vowels',
          advice: 'Make sure your vowel check handles both lowercase ("aeiou") and uppercase ("AEIOU").'
        }
      ]
    },
    'prob-3': {
      clue1:
        'The water capacity between two lines is determined by the shorter of the two heights multiplied by the distance between them: min(height[i], height[j]) * (j - i).',
      clue2:
        'Start with the maximum possible width (pointers at extreme ends: left=0, right=n-1). To have any chance of finding a larger area, which pointer should you move?',
      clue3:
        'Always move the pointer pointing to the shorter vertical bar inward (if height[left] < height[right], left++, else right--). Moving the taller bar can only decrease width without increasing height.',
      commonBugs: []
    },
    'prob-4': {
      clue1:
        'Instead of generating all substrings, imagine a sliding window [start, end] of unique characters that expands to the right.',
      clue2:
        'Maintain a Hash Map storing the most recent index where each character appeared. When you encounter a character already in your window, jump the start pointer past its previous occurrence.',
      clue3:
        'For each character at index i: if map has s[i] and map.get(s[i]) >= start, set start = map.get(s[i]) + 1. Then record map.set(s[i], i) and update maxLen = Math.max(maxLen, i - start + 1).',
      commonBugs: []
    },
    'prob-5': {
      clue1:
        'Kadane\'s algorithm insight: At any index i, you either extend the previous subarray or start a fresh subarray at nums[i].',
      clue2:
        'curSum = Math.max(nums[i], curSum + nums[i]); and maxSum = Math.max(maxSum, curSum).',
      clue3:
        'Initialize curSum = nums[0] and maxSum = nums[0]. Iterate from index 1 to n-1. Be careful when all numbers are negative!',
      commonBugs: [
        {
          pattern: /maxSum\s*=\s*0/,
          issue: 'Initializing maximum sum to 0',
          advice: 'If all numbers in the array are negative (e.g. [-5, -2]), initializing maxSum = 0 returns 0 instead of -2. Initialize to nums[0] instead.'
        }
      ]
    }
  };

  static generateHints(problem: Problem, failedCount: number, userCode?: string): AIHintResponse {
    const kb = this.HINT_KNOWLEDGE_BASE[problem.id] || {
      clue1: `Focus on the core constraints of '${problem.title}'. What is the simplest subproblem you can solve first?`,
      clue2: `Consider applying algorithmic patterns typical for '${problem.category}' (e.g. Two Pointers, Hash Table, or Dynamic Programming memoization).`,
      clue3: `Write out the state transition or loop invariants step-by-step. Don't forget boundary conditions like empty inputs or single elements!`,
      commonBugs: []
    };

    // Determine unlocked clues based on failed test runs or explicit request
    const unlockedClues: AIHintResponse['unlockedClues'] = [];

    // Clue 1 is unlocked
    unlockedClues.push({
      level: 1,
      title: 'Intuitive Perspective (Non-Spoiler)',
      content: kb.clue1
    });

    // Clue 2 unlocked on 2+ failed attempts or requested
    if (failedCount >= 2) {
      unlockedClues.push({
        level: 2,
        title: 'Algorithmic Pattern & Data Structure Clue',
        content: kb.clue2
      });
    }

    // Clue 3 unlocked on 3+ failed attempts
    if (failedCount >= 3) {
      unlockedClues.push({
        level: 3,
        title: 'Pseudo-Code Blueprint & Edge Case Shield',
        content: kb.clue3
      });
    }

    // Code diagnosis if user provided code snippet
    let codeDiagnosis: AIHintResponse['codeDiagnosis'] = undefined;
    if (userCode) {
      for (const bug of kb.commonBugs) {
        if (bug.pattern.test(userCode)) {
          codeDiagnosis = {
            likelyPitfall: bug.issue,
            suggestion: bug.advice
          };
          break;
        }
      }

      if (!codeDiagnosis && userCode.includes('while') && !userCode.includes('++') && !userCode.includes('+=')) {
        codeDiagnosis = {
          likelyPitfall: 'Potential Infinite Loop in while block',
          suggestion: 'Ensure your while loop variable increments or decrements towards the termination condition.'
        };
      }
    }

    return {
      problemId: problem.id,
      problemTitle: problem.title,
      triggerReason:
        failedCount >= 3
          ? `Automatic AI Assist triggered after ${failedCount} test run attempts.`
          : `AI Hint Assistant ready to provide non-spoiler conceptual guidance.`,
      unlockedClues,
      codeDiagnosis
    };
  }
}
