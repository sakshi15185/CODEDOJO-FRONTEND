export interface PlagiarismComparisonResult {
  code1: string;
  code2: string;
  levenshteinDistance: number;
  similarityPercentage: number;
  tokenSimilarity: number;
  verdict: 'Original' | 'Minor Similarity' | 'Suspicious' | 'High Plagiarism Alert';
  isFlagged: boolean;
  explanation: string;
}

export class PlagiarismService {
  /**
   * Calculates Levenshtein edit distance between two strings
   */
  static levenshteinDistance(a: string, b: string): number {
    const m = a.length;
    const n = b.length;
    if (m === 0) return n;
    if (n === 0) return m;

    let v0 = new Int32Array(n + 1);
    let v1 = new Int32Array(n + 1);

    for (let i = 0; i <= n; i++) v0[i] = i;

    for (let i = 0; i < m; i++) {
      v1[0] = i + 1;
      for (let j = 0; j < n; j++) {
        const cost = a[i] === b[j] ? 0 : 1;
        v1[j + 1] = Math.min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost);
      }
      for (let j = 0; j <= n; j++) v0[j] = v1[j];
    }

    return v1[n];
  }

  /**
   * Normalize code: strip comments, normalize whitespaces, standardize common tokens
   */
  static normalizeCode(code: string): string {
    return code
      .replace(/\/\*[\s\S]*?\*\/|([^:]|^)\/\/.*$/gm, '') // remove comments
      .replace(/#.*$/gm, '') // python comments
      .replace(/\s+/g, ' ') // collapse whitespaces
      .trim();
  }

  /**
   * Tokenize code into syntactical structural chunks
   */
  static extractTokens(code: string): string[] {
    const normalized = this.normalizeCode(code);
    return normalized
      .split(/([{}()[\];,.\s=+\-*/%&|^!<>?:])/)
      .map(t => t.trim())
      .filter(t => t.length > 0);
  }

  /**
   * Token-based Jaccard similarity
   */
  static tokenJaccardSimilarity(code1: string, code2: string): number {
    const tokens1 = new Set(this.extractTokens(code1));
    const tokens2 = new Set(this.extractTokens(code2));

    let intersectionCount = 0;
    tokens1.forEach(t => {
      if (tokens2.has(t)) intersectionCount++;
    });

    const unionCount = new Set([...tokens1, ...tokens2]).size;
    if (unionCount === 0) return 1;
    return Math.round((intersectionCount / unionCount) * 100);
  }

  /**
   * Compare two code snippets and compute Levenshtein distance and plagiarism verdict
   */
  static compareSubmissions(code1: string, code2: string): PlagiarismComparisonResult {
    const clean1 = this.normalizeCode(code1);
    const clean2 = this.normalizeCode(code2);

    const maxLen = Math.max(clean1.length, clean2.length);
    if (maxLen === 0) {
      return {
        code1,
        code2,
        levenshteinDistance: 0,
        similarityPercentage: 100,
        tokenSimilarity: 100,
        verdict: 'High Plagiarism Alert',
        isFlagged: true,
        explanation: 'Both code snippets are empty.'
      };
    }

    const dist = this.levenshteinDistance(clean1, clean2);
    const charSimilarity = Math.max(0, Math.round(((maxLen - dist) / maxLen) * 100));
    const tokenSim = this.tokenJaccardSimilarity(code1, code2);

    // Weighted similarity: 60% Levenshtein, 40% Token Jaccard
    const overallSimilarity = Math.round(charSimilarity * 0.6 + tokenSim * 0.4);

    let verdict: PlagiarismComparisonResult['verdict'] = 'Original';
    let isFlagged = false;
    let explanation = 'Code structures are sufficiently distinct and independent.';

    if (overallSimilarity >= 85) {
      verdict = 'High Plagiarism Alert';
      isFlagged = true;
      explanation = 'Extremely high syntactic and structural similarity detected (>85%). Direct copy suspected.';
    } else if (overallSimilarity >= 65) {
      verdict = 'Suspicious';
      isFlagged = true;
      explanation = 'Noticeable structural correlation or slight renaming detected between submissions.';
    } else if (overallSimilarity >= 40) {
      verdict = 'Minor Similarity';
      explanation = 'Common algorithmic pattern or canonical solution structure observed.';
    }

    return {
      code1,
      code2,
      levenshteinDistance: dist,
      similarityPercentage: overallSimilarity,
      tokenSimilarity: tokenSim,
      verdict,
      isFlagged,
      explanation
    };
  }
}
