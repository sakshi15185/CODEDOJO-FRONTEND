import { Problem, TestCase, Team, User } from '../types.js';

export const PROBLEMS: Problem[] = [
  {
    id: 'prob-1',
    title: 'Two Sum Variant: Minimal Element Gap',
    slug: 'two-sum-variant',
    difficulty: 'Easy',
    category: 'Arrays & Hash Maps',
    tags: ['Hash Maps', 'Arrays', 'Two Pointers'],
    description: `Given an integer array \`nums\` and an integer \`target\`, find the 0-indexed pair of indices \`[i, j]\` such that \`nums[i] + nums[j] == target\` with \`i != j\`.

If multiple such pairs exist, return the pair \`[i, j]\` (with \`i < j\`) that **minimizes the absolute difference** between the two numbers, i.e., \`|nums[i] - nums[j]|\`.
If still tied, return the pair with the smaller index \`i\`.
If no such pair exists, return an empty array \`[]\`.`,
    inputFormat: 'An array of integers `nums` and an integer `target`.',
    outputFormat: 'An array of two indices `[i, j]` (with `i < j`), or `[]`.',
    constraints: [
      '2 <= nums.length <= 10^5',
      '-10^9 <= nums[i] <= 10^9',
      '-2 * 10^9 <= target <= 2 * 10^9'
    ],
    examples: [
      {
        input: 'nums = [2, 7, 11, 15], target = 9',
        output: '[0, 1]',
        explanation: 'nums[0] + nums[1] = 2 + 7 = 9. Absolute difference |2 - 7| = 5.'
      },
      {
        input: 'nums = [1, 4, 3, 2, 5], target = 6',
        output: '[1, 3]',
        explanation: 'Pairs that sum to 6 are: (1, 5) at [0, 4] with |1-5|=4; (4, 2) at [1, 3] with |4-2|=2; (3, 3) not possible (single element). Minimal gap is |4-2|=2, so return [1, 3].'
      }
    ],
    starterCode: {
      javascript: `/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
function twoSumVariant(nums, target) {
  // Write your code here
  const map = new Map();
  let bestPair = null;
  let minDiff = Infinity;

  for (let j = 0; j < nums.length; j++) {
    const complement = target - nums[j];
    if (map.has(complement)) {
      const i = map.get(complement);
      const diff = Math.abs(nums[i] - nums[j]);
      if (diff < minDiff) {
        minDiff = diff;
        bestPair = [Math.min(i, j), Math.max(i, j)];
      }
    }
    // store the index
    if (!map.has(nums[j])) {
      map.set(nums[j], j);
    }
  }

  return bestPair || [];
}`,
      python: `def twoSumVariant(nums: list[int], target: int) -> list[int]:
    # Write your code here
    lookup = {}
    best_pair = []
    min_diff = float('inf')

    for j, val in enumerate(nums):
        complement = target - val
        if complement in lookup:
            i = lookup[complement]
            diff = abs(nums[i] - val)
            if diff < min_diff:
                min_diff = diff
                best_pair = [min(i, j), max(i, j)]
        if val not in lookup:
            lookup[val] = j

    return best_pair
`
    },
    functionName: 'twoSumVariant',
    isDaily: true,
    dailyDate: '2026-11-20',
    points: 100,
    acceptanceRate: 78.4,
    solvedCount: 1420
  },
  {
    id: 'prob-2',
    title: 'Reverse Vowels of a String',
    slug: 'reverse-vowels-of-a-string',
    difficulty: 'Easy',
    category: 'Strings',
    tags: ['Two Pointers', 'Strings'],
    description: 'Given a string `s`, reverse only all the vowels in the string and return it. The vowels are `a`, `e`, `i`, `o`, `u` (both lower and upper case).',
    inputFormat: 'A string `s`.',
    outputFormat: 'The modified string with vowels reversed.',
    constraints: ['1 <= s.length <= 3 * 10^5', 's consists of printable ASCII characters.'],
    examples: [
      { input: 's = "IceCreAm"', output: '"AceCreIm"' },
      { input: 's = "leetcode"', output: '"leotcede"' }
    ],
    starterCode: {
      javascript: `function reverseVowels(s) {
  const vowels = new Set(['a','e','i','o','u','A','E','I','O','U']);
  const arr = s.split('');
  let left = 0, right = arr.length - 1;
  while (left < right) {
    while (left < right && !vowels.has(arr[left])) left++;
    while (left < right && !vowels.has(arr[right])) right--;
    if (left < right) {
      [arr[left], arr[right]] = [arr[right], arr[left]];
      left++;
      right--;
    }
  }
  return arr.join('');
}`,
      python: `def reverseVowels(s: str) -> str:
    vowels = set("aeiouAEIOU")
    arr = list(s)
    left, right = 0, len(arr) - 1
    while left < right:
        while left < right and arr[left] not in vowels:
            left += 1
        while left < right and arr[right] not in vowels:
            right -= 1
        if left < right:
            arr[left], arr[right] = arr[right], arr[left]
            left += 1
            right -= 1
    return "".join(arr)`
    },
    functionName: 'reverseVowels',
    isDaily: false,
    points: 50,
    acceptanceRate: 84.1,
    solvedCount: 2890
  },
  {
    id: 'prob-3',
    title: 'Container With Most Water',
    slug: 'container-with-most-water',
    difficulty: 'Medium',
    category: 'Two Pointers',
    tags: ['Two Pointers', 'Greedy', 'Arrays'],
    description: `You are given an integer array \`height\` of length \`n\`. There are \`n\` vertical lines drawn such that the two endpoints of the \`i\`-th line are \`(i, 0)\` and \`(i, height[i])\`.
Find two lines that together with the x-axis form a container, such that the container contains the most water. Return the maximum amount of water a container can store.`,
    inputFormat: 'An array of non-negative integers `height`.',
    outputFormat: 'An integer representing maximum water capacity.',
    constraints: ['2 <= height.length <= 10^5', '0 <= height[i] <= 10^4'],
    examples: [
      { input: 'height = [1,8,6,2,5,4,8,3,7]', output: '49', explanation: 'Lines at index 1 (8) and index 8 (7) hold min(8,7)*(8-1) = 7*7 = 49.' }
    ],
    starterCode: {
      javascript: `function maxArea(height) {
  let left = 0, right = height.length - 1;
  let max = 0;
  while (left < right) {
    const width = right - left;
    const h = Math.min(height[left], height[right]);
    max = Math.max(max, width * h);
    if (height[left] < height[right]) left++;
    else right--;
  }
  return max;
}`,
      python: `def maxArea(height: list[int]) -> int:
    left, right = 0, len(height) - 1
    ans = 0
    while left < right:
        ans = max(ans, (right - left) * min(height[left], height[right]))
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    return ans`
    },
    functionName: 'maxArea',
    isDaily: false,
    points: 100,
    acceptanceRate: 54.3,
    solvedCount: 3120
  },
  {
    id: 'prob-4',
    title: 'Longest Substring Without Repeating Characters',
    slug: 'longest-substring-without-repeating',
    difficulty: 'Medium',
    category: 'Sliding Window',
    tags: ['Sliding Window', 'Hash Maps', 'Strings'],
    description: 'Given a string `s`, find the length of the longest substring without repeating characters.',
    inputFormat: 'A string `s`.',
    outputFormat: 'An integer representing length of longest unique substring.',
    constraints: ['0 <= s.length <= 5 * 10^4', 's consists of English letters, digits, symbols and spaces.'],
    examples: [
      { input: 's = "abcabcbb"', output: '3', explanation: 'The answer is "abc", with length of 3.' },
      { input: 's = "bbbbb"', output: '1', explanation: 'The answer is "b", with length 1.' }
    ],
    starterCode: {
      javascript: `function lengthOfLongestSubstring(s) {
  const map = new Map();
  let maxLen = 0, start = 0;
  for (let i = 0; i < s.length; i++) {
    if (map.has(s[i]) && map.get(s[i]) >= start) {
      start = map.get(s[i]) + 1;
    }
    map.set(s[i], i);
    maxLen = Math.max(maxLen, i - start + 1);
  }
  return maxLen;
}`,
      python: `def lengthOfLongestSubstring(s: str) -> int:
    last_seen = {}
    max_len = 0
    start = 0
    for i, ch in enumerate(s):
        if ch in last_seen and last_seen[ch] >= start:
            start = last_seen[ch] + 1
        last_seen[ch] = i
        max_len = max(max_len, i - start + 1)
    return max_len`
    },
    functionName: 'lengthOfLongestSubstring',
    isDaily: false,
    points: 100,
    acceptanceRate: 48.7,
    solvedCount: 4200
  },
  {
    id: 'prob-5',
    title: 'Maximum Subarray (Kadane Algorithm)',
    slug: 'maximum-subarray',
    difficulty: 'Medium',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Divide and Conquer', 'Arrays'],
    description: 'Given an integer array `nums`, find the subarray with the largest sum, and return its sum.',
    inputFormat: 'An array of integers `nums`.',
    outputFormat: 'The maximum subarray sum as an integer.',
    constraints: ['1 <= nums.length <= 10^5', '-10^4 <= nums[i] <= 10^4'],
    examples: [
      { input: 'nums = [-2,1,-3,4,-1,2,1,-5,4]', output: '6', explanation: 'Subarray [4,-1,2,1] has the largest sum 6.' }
    ],
    starterCode: {
      javascript: `function maxSubArray(nums) {
  let maxSum = nums[0];
  let curSum = nums[0];
  for (let i = 1; i < nums.length; i++) {
    curSum = Math.max(nums[i], curSum + nums[i]);
    maxSum = Math.max(maxSum, curSum);
  }
  return maxSum;
}`,
      python: `def maxSubArray(nums: list[int]) -> int:
    cur = max_s = nums[0]
    for x in nums[1:]:
        cur = max(x, cur + x)
        max_s = max(max_s, cur)
    return max_s`
    },
    functionName: 'maxSubArray',
    isDaily: false,
    points: 100,
    acceptanceRate: 50.1,
    solvedCount: 5100
  },
  {
    id: 'prob-6',
    title: 'Product of Array Except Self',
    slug: 'product-of-array-except-self',
    difficulty: 'Medium',
    category: 'Arrays & Hash Maps',
    tags: ['Arrays', 'Prefix Sum'],
    description: 'Given an integer array `nums`, return an array `answer` such that `answer[i]` is equal to the product of all the elements of `nums` except `nums[i]`. You must write an algorithm that runs in `O(n)` time and without using the division operation.',
    inputFormat: 'An array of integers `nums`.',
    outputFormat: 'An array `answer` of product values.',
    constraints: ['2 <= nums.length <= 10^5', '-30 <= nums[i] <= 30'],
    examples: [
      { input: 'nums = [1,2,3,4]', output: '[24,12,8,6]' },
      { input: 'nums = [-1,1,0,-3,3]', output: '[0,0,9,0,0]' }
    ],
    starterCode: {
      javascript: `function productExceptSelf(nums) {
  const n = nums.length;
  const ans = new Array(n).fill(1);
  let prefix = 1;
  for (let i = 0; i < n; i++) {
    ans[i] = prefix;
    prefix *= nums[i];
  }
  let suffix = 1;
  for (let i = n - 1; i >= 0; i--) {
    ans[i] *= suffix;
    suffix *= nums[i];
  }
  return ans;
}`,
      python: `def productExceptSelf(nums: list[int]) -> list[int]:
    n = len(nums)
    res = [1] * n
    prefix = 1
    for i in range(n):
        res[i] = prefix
        prefix *= nums[i]
    suffix = 1
    for i in range(n - 1, -1, -1):
        res[i] *= suffix
        suffix *= nums[i]
    return res`
    },
    functionName: 'productExceptSelf',
    isDaily: false,
    points: 100,
    acceptanceRate: 65.2,
    solvedCount: 3900
  },
  {
    id: 'prob-7',
    title: 'Merge Intervals',
    slug: 'merge-intervals',
    difficulty: 'Medium',
    category: 'Greedy',
    tags: ['Intervals', 'Sorting', 'Greedy'],
    description: 'Given an array of `intervals` where `intervals[i] = [start_i, end_i]`, merge all overlapping intervals, and return an array of the non-overlapping intervals that cover all the intervals in the input.',
    inputFormat: '2D array of interval endpoints `intervals`.',
    outputFormat: '2D array of merged intervals.',
    constraints: ['1 <= intervals.length <= 10^4', 'intervals[i].length == 2', '0 <= start_i <= end_i <= 10^4'],
    examples: [
      { input: 'intervals = [[1,3],[2,6],[8,10],[15,18]]', output: '[[1,6],[8,10],[15,18]]' }
    ],
    starterCode: {
      javascript: `function merge(intervals) {
  if (!intervals.length) return [];
  intervals.sort((a, b) => a[0] - b[0]);
  const res = [intervals[0]];
  for (let i = 1; i < intervals.length; i++) {
    const prev = res[res.length - 1];
    const curr = intervals[i];
    if (curr[0] <= prev[1]) {
      prev[1] = Math.max(prev[1], curr[1]);
    } else {
      res.push(curr);
    }
  }
  return res;
}`,
      python: `def merge(intervals: list[list[int]]) -> list[list[int]]:
    if not intervals: return []
    intervals.sort(key=lambda x: x[0])
    res = [intervals[0]]
    for start, end in intervals[1:]:
        if start <= res[-1][1]:
            res[-1][1] = max(res[-1][1], end)
        else:
            res.append([start, end])
    return res`
    },
    functionName: 'merge',
    isDaily: false,
    points: 100,
    acceptanceRate: 46.8,
    solvedCount: 2600
  },
  {
    id: 'prob-8',
    title: 'Top K Frequent Elements',
    slug: 'top-k-frequent-elements',
    difficulty: 'Medium',
    category: 'Arrays & Hash Maps',
    tags: ['Hash Maps', 'Heap', 'Bucket Sort'],
    description: 'Given an integer array `nums` and an integer `k`, return the `k` most frequent elements. You may return the answer in any order (sort ascending for deterministic verification).',
    inputFormat: 'Array `nums` and integer `k`.',
    outputFormat: 'Array of `k` integers sorted in ascending order.',
    constraints: ['1 <= nums.length <= 10^5', '-10^4 <= nums[i] <= 10^4', 'k is in range [1, the number of unique elements in nums]'],
    examples: [
      { input: 'nums = [1,1,1,2,2,3], k = 2', output: '[1, 2]' }
    ],
    starterCode: {
      javascript: `function topKFrequent(nums, k) {
  const counts = new Map();
  for (const n of nums) counts.set(n, (counts.get(n) || 0) + 1);
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, k)
    .map(entry => entry[0])
    .sort((a, b) => a - b);
}`,
      python: `def topKFrequent(nums: list[int], k: int) -> list[int]:
    from collections import Counter
    counts = Counter(nums)
    res = [item[0] for item in counts.most_common(k)]
    return sorted(res)`
    },
    functionName: 'topKFrequent',
    isDaily: false,
    points: 100,
    acceptanceRate: 64.1,
    solvedCount: 2150
  },
  {
    id: 'prob-9',
    title: 'Valid Parentheses with Wildcards',
    slug: 'valid-parentheses-wildcard',
    difficulty: 'Medium',
    category: 'Greedy',
    tags: ['Stack', 'Greedy', 'Strings'],
    description: `Given a string \`s\` containing only three types of characters: \`'('\`, \`')'\` and \`'*'\`, return \`true\` if \`s\` is valid.
\`'*'\` could be treated as a single right parenthesis \`')'\` or a single left parenthesis \`'('\` or an empty string \`""\`.`,
    inputFormat: 'A string `s`.',
    outputFormat: 'Boolean `true` or `false`.',
    constraints: ['1 <= s.length <= 100'],
    examples: [
      { input: 's = "(*))"', output: 'true' },
      { input: 's = "(*)"', output: 'true' }
    ],
    starterCode: {
      javascript: `function checkValidString(s) {
  let low = 0, high = 0;
  for (const c of s) {
    if (c === '(') { low++; high++; }
    else if (c === ')') { low--; high--; }
    else { low--; high++; }
    if (high < 0) return false;
    if (low < 0) low = 0;
  }
  return low === 0;
}`,
      python: `def checkValidString(s: str) -> bool:
    low = high = 0
    for c in s:
        if c == '(':
            low += 1
            high += 1
        elif c == ')':
            low -= 1
            high -= 1
        else:
            low -= 1
            high += 1
        if high < 0: return False
        if low < 0: low = 0
    return low == 0`
    },
    functionName: 'checkValidString',
    isDaily: false,
    points: 100,
    acceptanceRate: 36.5,
    solvedCount: 1800
  },
  {
    id: 'prob-10',
    title: 'Daily Temperatures',
    slug: 'daily-temperatures',
    difficulty: 'Medium',
    category: 'Monotonic Stack',
    tags: ['Stack', 'Monotonic Stack', 'Arrays'],
    description: 'Given an array of integers `temperatures` represents daily temperatures, return an array `answer` such that `answer[i]` is the number of days you have to wait after the `i`-th day to get a warmer temperature. If there is no future day for which this is possible, keep `answer[i] == 0`.',
    inputFormat: 'Array of daily temperatures.',
    outputFormat: 'Array of wait day counts.',
    constraints: ['1 <= temperatures.length <= 10^5', '30 <= temperatures[i] <= 100'],
    examples: [
      { input: 'temperatures = [73,74,75,71,69,72,76,73]', output: '[1,1,4,2,1,1,0,0]' }
    ],
    starterCode: {
      javascript: `function dailyTemperatures(temperatures) {
  const n = temperatures.length;
  const res = new Array(n).fill(0);
  const stack = []; // indices
  for (let i = 0; i < n; i++) {
    while (stack.length > 0 && temperatures[i] > temperatures[stack[stack.length - 1]]) {
      const prev = stack.pop();
      res[prev] = i - prev;
    }
    stack.push(i);
  }
  return res;
}`,
      python: `def dailyTemperatures(temperatures: list[int]) -> list[int]:
    n = len(temperatures)
    ans = [0] * n
    stack = []
    for i, t in enumerate(temperatures):
        while stack and t > temperatures[stack[-1]]:
            prev = stack.pop()
            ans[prev] = i - prev
        stack.append(i)
    return ans`
    },
    functionName: 'dailyTemperatures',
    isDaily: false,
    points: 100,
    acceptanceRate: 66.8,
    solvedCount: 3400
  },
  {
    id: 'prob-11',
    title: 'Coin Change: Minimum Coins',
    slug: 'coin-change',
    difficulty: 'Medium',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'BFS'],
    description: 'You are given an integer array `coins` representing coins of different denominations and an integer `amount` representing a total amount of money. Return the fewest number of coins that you need to make up that amount. If that amount of money cannot be made up by any combination of the coins, return `-1`.',
    inputFormat: 'Array `coins` and integer `amount`.',
    outputFormat: 'Integer minimum coin count or -1.',
    constraints: ['1 <= coins.length <= 12', '1 <= coins[i] <= 2^31 - 1', '0 <= amount <= 10^4'],
    examples: [
      { input: 'coins = [1,2,5], amount = 11', output: '3', explanation: '11 = 5 + 5 + 1' },
      { input: 'coins = [2], amount = 3', output: '-1' }
    ],
    starterCode: {
      javascript: `function coinChange(coins, amount) {
  const dp = new Array(amount + 1).fill(Infinity);
  dp[0] = 0;
  for (let i = 1; i <= amount; i++) {
    for (const c of coins) {
      if (i - c >= 0) {
        dp[i] = Math.min(dp[i], dp[i - c] + 1);
      }
    }
  }
  return dp[amount] === Infinity ? -1 : dp[amount];
}`,
      python: `def coinChange(coins: list[int], amount: int) -> int:
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for i in range(1, amount + 1):
        for c in coins:
            if i - c >= 0:
                dp[i] = min(dp[i], dp[i - c] + 1)
    return dp[amount] if dp[amount] != float('inf') else -1`
    },
    functionName: 'coinChange',
    isDaily: false,
    points: 100,
    acceptanceRate: 42.1,
    solvedCount: 2900
  },
  {
    id: 'prob-12',
    title: 'Longest Increasing Subsequence',
    slug: 'longest-increasing-subsequence',
    difficulty: 'Medium',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Binary Search', 'Arrays'],
    description: 'Given an integer array `nums`, return the length of the longest strictly increasing subsequence.',
    inputFormat: 'Array `nums`.',
    outputFormat: 'Length of LIS as an integer.',
    constraints: ['1 <= nums.length <= 2500', '-10^4 <= nums[i] <= 10^4'],
    examples: [
      { input: 'nums = [10,9,2,5,3,7,101,18]', output: '4', explanation: 'The longest increasing subsequence is [2,3,7,101], length 4.' }
    ],
    starterCode: {
      javascript: `function lengthOfLIS(nums) {
  const tails = [];
  for (const x of nums) {
    let l = 0, r = tails.length;
    while (l < r) {
      const mid = Math.floor((l + r) / 2);
      if (tails[mid] < x) l = mid + 1;
      else r = mid;
    }
    tails[l] = x;
  }
  return tails.length;
}`,
      python: `def lengthOfLIS(nums: list[int]) -> int:
    import bisect
    tails = []
    for x in nums:
        idx = bisect.bisect_left(tails, x)
        if idx == len(tails):
            tails.append(x)
        else:
            tails[idx] = x
    return len(tails)`
    },
    functionName: 'lengthOfLIS',
    isDaily: false,
    points: 100,
    acceptanceRate: 53.6,
    solvedCount: 2200
  },
  {
    id: 'prob-13',
    title: 'Rotting Oranges',
    slug: 'rotting-oranges',
    difficulty: 'Medium',
    category: 'Graph & Matrix',
    tags: ['BFS', 'Matrix', 'Queue'],
    description: `You are given an \`m x n\` grid where each cell can have one of three values:
- \`0\` representing an empty cell,
- \`1\` representing a fresh orange, or
- \`2\` representing a rotten orange.
Every minute, any fresh orange that is 4-directionally adjacent to a rotten orange becomes rotten.
Return the minimum number of minutes that must elapse until no cell has a fresh orange. If this is impossible, return \`-1\`.`,
    inputFormat: '2D grid `grid`.',
    outputFormat: 'Integer minutes or -1.',
    constraints: ['m == grid.length', 'n == grid[i].length', '1 <= m, n <= 10', 'grid[i][j] is 0, 1, or 2.'],
    examples: [
      { input: 'grid = [[2,1,1],[1,1,0],[0,1,1]]', output: '4' }
    ],
    starterCode: {
      javascript: `function orangesRotting(grid) {
  const m = grid.length, n = grid[0].length;
  const queue = [];
  let fresh = 0;
  for (let r = 0; r < m; r++) {
    for (let c = 0; c < n; c++) {
      if (grid[r][c] === 2) queue.push([r, c, 0]);
      else if (grid[r][c] === 1) fresh++;
    }
  }
  let minutes = 0;
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  while (queue.length > 0) {
    const [r, c, d] = queue.shift();
    minutes = Math.max(minutes, d);
    for (const [dr, dc] of dirs) {
      const nr = r + dr, nc = c + dc;
      if (nr >= 0 && nr < m && nc >= 0 && nc < n && grid[nr][nc] === 1) {
        grid[nr][nc] = 2;
        fresh--;
        queue.push([nr, nc, d + 1]);
      }
    }
  }
  return fresh === 0 ? minutes : -1;
}`,
      python: `def orangesRotting(grid: list[list[int]]) -> int:
    from collections import deque
    m, n = len(grid), len(grid[0])
    q = deque()
    fresh = 0
    for r in range(m):
        for c in range(n):
            if grid[r][c] == 2:
                q.append((r, c, 0))
            elif grid[r][c] == 1:
                fresh += 1
    minutes = 0
    while q:
        r, c, d = q.popleft()
        minutes = max(minutes, d)
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < m and 0 <= nc < n and grid[nr][nc] == 1:
                grid[nr][nc] = 2
                fresh -= 1
                q.append((nr, nc, d + 1))
    return minutes if fresh == 0 else -1`
    },
    functionName: 'orangesRotting',
    isDaily: false,
    points: 100,
    acceptanceRate: 53.9,
    solvedCount: 3100
  },
  {
    id: 'prob-14',
    title: 'Search in Rotated Sorted Array',
    slug: 'search-in-rotated-sorted-array',
    difficulty: 'Medium',
    category: 'Binary Search',
    tags: ['Binary Search', 'Arrays'],
    description: 'Given the array `nums` after the possible rotation and an integer `target`, return the index of `target` if it is in `nums`, or `-1` if it is not in `nums`. You must write an algorithm with `O(log n)` runtime complexity.',
    inputFormat: 'Array `nums` and target integer.',
    outputFormat: 'Index integer or -1.',
    constraints: ['1 <= nums.length <= 5000', '-10^4 <= nums[i] <= 10^4', 'All values of nums are unique.'],
    examples: [
      { input: 'nums = [4,5,6,7,0,1,2], target = 0', output: '4' },
      { input: 'nums = [4,5,6,7,0,1,2], target = 3', output: '-1' }
    ],
    starterCode: {
      javascript: `function search(nums, target) {
  let l = 0, r = nums.length - 1;
  while (l <= r) {
    const mid = Math.floor((l + r) / 2);
    if (nums[mid] === target) return mid;
    if (nums[l] <= nums[mid]) {
      if (nums[l] <= target && target < nums[mid]) r = mid - 1;
      else l = mid + 1;
    } else {
      if (nums[mid] < target && target <= nums[r]) l = mid + 1;
      else r = mid - 1;
    }
  }
  return -1;
}`,
      python: `def search(nums: list[int], target: int) -> int:
    l, r = 0, len(nums) - 1
    while l <= r:
        mid = (l + r) // 2
        if nums[mid] == target:
            return mid
        if nums[l] <= nums[mid]:
            if nums[l] <= target < nums[mid]:
                r = mid - 1
            else:
                l = mid + 1
        else:
            if nums[mid] < target <= nums[r]:
                l = mid + 1
            else:
                r = mid - 1
    return -1`
    },
    functionName: 'search',
    isDaily: false,
    points: 100,
    acceptanceRate: 39.8,
    solvedCount: 4100
  },
  {
    id: 'prob-15',
    title: 'Trapping Rain Water',
    slug: 'trapping-rain-water',
    difficulty: 'Hard',
    category: 'Two Pointers',
    tags: ['Two Pointers', 'Dynamic Programming', 'Monotonic Stack'],
    description: 'Given `n` non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.',
    inputFormat: 'Array of elevation heights.',
    outputFormat: 'Total trapped water units as an integer.',
    constraints: ['n == height.length', '1 <= n <= 2 * 10^4', '0 <= height[i] <= 10^5'],
    examples: [
      { input: 'height = [0,1,0,2,1,0,1,3,2,1,2,1]', output: '6' }
    ],
    starterCode: {
      javascript: `function trap(height) {
  let l = 0, r = height.length - 1;
  let maxL = 0, maxR = 0, water = 0;
  while (l < r) {
    if (height[l] <= height[r]) {
      if (height[l] >= maxL) maxL = height[l];
      else water += maxL - height[l];
      l++;
    } else {
      if (height[r] >= maxR) maxR = height[r];
      else water += maxR - height[r];
      r--;
    }
  }
  return water;
}`,
      python: `def trap(height: list[int]) -> int:
    l, r = 0, len(height) - 1
    max_l = max_r = water = 0
    while l < r:
        if height[l] <= height[r]:
            if height[l] >= max_l: max_l = height[l]
            else: water += max_l - height[l]
            l += 1
        else:
            if height[r] >= max_r: max_r = height[r]
            else: water += max_r - height[r]
            r -= 1
    return water`
    },
    functionName: 'trap',
    isDaily: false,
    points: 150,
    acceptanceRate: 59.4,
    solvedCount: 1650
  },
  {
    id: 'prob-16',
    title: 'Edit Distance (Levenshtein)',
    slug: 'edit-distance',
    difficulty: 'Hard',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Strings'],
    description: `Given two strings \`word1\` and \`word2\`, return the minimum number of operations required to convert \`word1\` to \`word2\`.
You have the following three operations permitted on a word:
- Insert a character
- Delete a character
- Replace a character`,
    inputFormat: 'Two strings `word1` and `word2`.',
    outputFormat: 'Minimum edit operations as an integer.',
    constraints: ['0 <= word1.length, word2.length <= 500', 'word1 and word2 consist of lowercase English letters.'],
    examples: [
      { input: 'word1 = "horse", word2 = "ros"', output: '3', explanation: 'horse -> rorse -> rose -> ros' }
    ],
    starterCode: {
      javascript: `function minDistance(word1, word2) {
  const m = word1.length, n = word2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (word1[i - 1] === word2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
  }
  return dp[m][n];
}`,
      python: `def minDistance(word1: str, word2: str) -> int:
    m, n = len(word1), len(word2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1): dp[i][0] = i
    for j in range(n + 1): dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i-1] == word2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
    return dp[m][n]`
    },
    functionName: 'minDistance',
    isDaily: false,
    points: 150,
    acceptanceRate: 55.2,
    solvedCount: 1400
  },
  {
    id: 'prob-17',
    title: 'Climbing Stairs with Minimum Cost',
    slug: 'min-cost-climbing-stairs',
    difficulty: 'Easy',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Arrays'],
    description: 'You are given an integer array `cost` where `cost[i]` is the cost of `i`-th step on a staircase. Once you pay the cost, you can either climb one or two steps. You can either start from the step with index `0`, or the step with index `1`. Return the minimum cost to reach the top of the floor.',
    inputFormat: 'Array of integer costs.',
    outputFormat: 'Minimum cost as an integer.',
    constraints: ['2 <= cost.length <= 1000', '0 <= cost[i] <= 999'],
    examples: [
      { input: 'cost = [10,15,20]', output: '15' },
      { input: 'cost = [1,100,1,1,1,100,1,1,100,1]', output: '6' }
    ],
    starterCode: {
      javascript: `function minCostClimbingStairs(cost) {
  let first = cost[0];
  let second = cost[1];
  for (let i = 2; i < cost.length; i++) {
    const current = cost[i] + Math.min(first, second);
    first = second;
    second = current;
  }
  return Math.min(first, second);
}`,
      python: `def minCostClimbingStairs(cost: list[int]) -> int:
    a, b = cost[0], cost[1]
    for c in cost[2:]:
        a, b = b, c + min(a, b)
    return min(a, b)`
    },
    functionName: 'minCostClimbingStairs',
    isDaily: false,
    points: 50,
    acceptanceRate: 64.9,
    solvedCount: 3800
  },
  {
    id: 'prob-18',
    title: 'House Robber II (Circular Street)',
    slug: 'house-robber-ii',
    difficulty: 'Medium',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Arrays'],
    description: 'You are a professional robber planning to rob houses along a circular street. The first house is the neighbor of the last one. Adjacent houses have security systems connected and will contact the police if two adjacent houses are broken into on the same night. Given an integer array `nums` representing the amount of money of each house, return the maximum amount of money you can rob tonight without alerting the police.',
    inputFormat: 'Array `nums`.',
    outputFormat: 'Maximum loot as an integer.',
    constraints: ['1 <= nums.length <= 100', '0 <= nums[i] <= 1000'],
    examples: [
      { input: 'nums = [2,3,2]', output: '3' },
      { input: 'nums = [1,2,3,1]', output: '4' }
    ],
    starterCode: {
      javascript: `function rob(nums) {
  if (nums.length === 1) return nums[0];
  const robLinear = (arr) => {
    let rob1 = 0, rob2 = 0;
    for (const n of arr) {
      const temp = Math.max(n + rob1, rob2);
      rob1 = rob2;
      rob2 = temp;
    }
    return rob2;
  };
  return Math.max(robLinear(nums.slice(0, -1)), robLinear(nums.slice(1)));
}`,
      python: `def rob(nums: list[int]) -> int:
    if len(nums) == 1: return nums[0]
    def linear(arr):
        r1 = r2 = 0
        for x in arr:
            r1, r2 = r2, max(x + r1, r2)
        return r2
    return max(linear(nums[:-1]), linear(nums[1:]))`
    },
    functionName: 'rob',
    isDaily: false,
    points: 100,
    acceptanceRate: 41.5,
    solvedCount: 2300
  },
  {
    id: 'prob-19',
    title: 'Word Break',
    slug: 'word-break',
    difficulty: 'Medium',
    category: 'Dynamic Programming',
    tags: ['Dynamic Programming', 'Trie', 'Hash Maps', 'Strings'],
    description: 'Given a string `s` and a dictionary of strings `wordDict`, return `true` if `s` can be segmented into a space-separated sequence of one or more dictionary words.',
    inputFormat: 'String `s` and array `wordDict`.',
    outputFormat: 'Boolean `true` or `false`.',
    constraints: ['1 <= s.length <= 300', '1 <= wordDict.length <= 1000', '1 <= wordDict[i].length <= 20'],
    examples: [
      { input: 's = "leetcode", wordDict = ["leet","code"]', output: 'true' },
      { input: 's = "applepenapple", wordDict = ["apple","pen"]', output: 'true' }
    ],
    starterCode: {
      javascript: `function wordBreak(s, wordDict) {
  const dict = new Set(wordDict);
  const dp = new Array(s.length + 1).fill(false);
  dp[0] = true;
  for (let i = 1; i <= s.length; i++) {
    for (let j = 0; j < i; j++) {
      if (dp[j] && dict.has(s.substring(j, i))) {
        dp[i] = true;
        break;
      }
    }
  }
  return dp[s.length];
}`,
      python: `def wordBreak(s: str, wordDict: list[str]) -> bool:
    words = set(wordDict)
    dp = [False] * (len(s) + 1)
    dp[0] = True
    for i in range(1, len(s) + 1):
        for j in range(i):
            if dp[j] and s[j:i] in words:
                dp[i] = True
                break
    return dp[len(s)]`
    },
    functionName: 'wordBreak',
    isDaily: false,
    points: 100,
    acceptanceRate: 46.2,
    solvedCount: 2750
  },
  {
    id: 'prob-20',
    title: 'Jump Game II: Minimum Hops',
    slug: 'jump-game-ii',
    difficulty: 'Medium',
    category: 'Greedy',
    tags: ['Greedy', 'Arrays', 'Dynamic Programming'],
    description: 'You are given a 0-indexed array of integers `nums` of length `n`. You are initially positioned at `nums[0]`. Each element `nums[i]` represents the maximum length of a forward jump from index `i`. Return the minimum number of jumps to reach `nums[n - 1]`.',
    inputFormat: 'Array `nums`.',
    outputFormat: 'Integer minimum jumps.',
    constraints: ['1 <= nums.length <= 10^4', '0 <= nums[i] <= 1000'],
    examples: [
      { input: 'nums = [2,3,1,1,4]', output: '2', explanation: 'Jump 1 step from index 0 to 1, then 3 steps to the last index.' }
    ],
    starterCode: {
      javascript: `function jump(nums) {
  let jumps = 0, curEnd = 0, curFarthest = 0;
  for (let i = 0; i < nums.length - 1; i++) {
    curFarthest = Math.max(curFarthest, i + nums[i]);
    if (i === curEnd) {
      jumps++;
      curEnd = curFarthest;
    }
  }
  return jumps;
}`,
      python: `def jump(nums: list[int]) -> int:
    jumps = cur_end = cur_farthest = 0
    for i in range(len(nums) - 1):
        cur_farthest = max(cur_farthest, i + nums[i])
        if i == cur_end:
            jumps += 1
            cur_end = cur_farthest
    return jumps`
    },
    functionName: 'jump',
    isDaily: false,
    points: 100,
    acceptanceRate: 44.9,
    solvedCount: 2450
  },
  {
    id: 'prob-21',
    title: 'Kth Largest Element in an Array',
    slug: 'kth-largest-element',
    difficulty: 'Medium',
    category: 'Heap & Sorting',
    tags: ['Heap', 'Sorting', 'Quickselect'],
    description: 'Given an integer array `nums` and an integer `k`, return the `k`-th largest element in the array. Can you solve it in O(n) average time complexity?',
    inputFormat: 'Array `nums` and integer `k`.',
    outputFormat: 'The k-th largest integer.',
    constraints: ['1 <= k <= nums.length <= 10^5', '-10^4 <= nums[i] <= 10^4'],
    examples: [
      { input: 'nums = [3,2,1,5,6,4], k = 2', output: '5' }
    ],
    starterCode: {
      javascript: `function findKthLargest(nums, k) {
  nums.sort((a, b) => b - a);
  return nums[k - 1];
}`,
      python: `def findKthLargest(nums: list[int], k: int) -> int:
    import heapq
    return heapq.nlargest(k, nums)[-1]`
    },
    functionName: 'findKthLargest',
    isDaily: false,
    points: 100,
    acceptanceRate: 67.0,
    solvedCount: 3950
  },
  {
    id: 'prob-22',
    title: 'Valid Palindrome II (One Skip Allowed)',
    slug: 'valid-palindrome-ii',
    difficulty: 'Easy',
    category: 'Two Pointers',
    tags: ['Two Pointers', 'Strings', 'Greedy'],
    description: 'Given a string `s`, return `true` if the `s` can be palindrome after deleting at most one character from it.',
    inputFormat: 'String `s`.',
    outputFormat: 'Boolean `true` or `false`.',
    constraints: ['1 <= s.length <= 10^5', 's consists of lowercase English letters.'],
    examples: [
      { input: 's = "aba"', output: 'true' },
      { input: 's = "abca"', output: 'true', explanation: 'Delete "c" to get "aba".' }
    ],
    starterCode: {
      javascript: `function validPalindrome(s) {
  let l = 0, r = s.length - 1;
  const isPal = (str, i, j) => {
    while (i < j) {
      if (str[i] !== str[j]) return false;
      i++; j--;
    }
    return true;
  };
  while (l < r) {
    if (s[l] !== s[r]) {
      return isPal(s, l + 1, r) || isPal(s, l, r - 1);
    }
    l++; r--;
  }
  return true;
}`,
      python: `def validPalindrome(s: str) -> bool:
    l, r = 0, len(s) - 1
    def is_pal(i, j):
        while i < j:
            if s[i] != s[j]: return False
            i += 1; j -= 1
        return True
    while l < r:
        if s[l] != s[r]:
            return is_pal(l + 1, r) or is_pal(l, r - 1)
        l += 1; r -= 1
    return True`
    },
    functionName: 'validPalindrome',
    isDaily: false,
    points: 50,
    acceptanceRate: 40.8,
    solvedCount: 2200
  },
  {
    id: 'prob-23',
    title: 'Binary Tree Level Order Traversal',
    slug: 'binary-tree-level-order',
    difficulty: 'Medium',
    category: 'Trees & BFS',
    tags: ['Trees', 'BFS', 'Queue'],
    description: 'Given the representation of a binary tree as an array `nodes` (level order representation where `null` represents missing nodes), return the level order traversal of its nodes values as a 2D array.',
    inputFormat: 'Array of node values or nulls.',
    outputFormat: '2D array of node values grouped by level.',
    constraints: ['The number of nodes in the tree is in the range [0, 2000].', '-1000 <= Node.val <= 1000'],
    examples: [
      { input: 'nodes = [3,9,20,null,null,15,7]', output: '[[3],[9,20],[15,7]]' }
    ],
    starterCode: {
      javascript: `function levelOrder(nodes) {
  if (!nodes || nodes.length === 0 || nodes[0] === null) return [];
  const result = [];
  let currentLevel = [0]; // indices in array representation
  
  while (currentLevel.length > 0) {
    const levelVals = [];
    const nextLevel = [];
    for (const idx of currentLevel) {
      if (nodes[idx] !== null && nodes[idx] !== undefined) {
        levelVals.push(nodes[idx]);
        const leftIdx = 2 * idx + 1;
        const rightIdx = 2 * idx + 2;
        if (leftIdx < nodes.length && nodes[leftIdx] !== null) nextLevel.push(leftIdx);
        if (rightIdx < nodes.length && nodes[rightIdx] !== null) nextLevel.push(rightIdx);
      }
    }
    if (levelVals.length > 0) result.push(levelVals);
    currentLevel = nextLevel;
  }
  return result;
}`,
      python: `def levelOrder(nodes: list) -> list[list[int]]:
    if not nodes or nodes[0] is None: return []
    result = []
    level = [0]
    while level:
        vals = []
        nxt = []
        for idx in level:
            if idx < len(nodes) and nodes[idx] is not None:
                vals.append(nodes[idx])
                l = 2 * idx + 1
                r = 2 * idx + 2
                if l < len(nodes) and nodes[l] is not None: nxt.append(l)
                if r < len(nodes) and nodes[r] is not None: nxt.append(r)
        if vals: result.append(vals)
        level = nxt
    return result`
    },
    functionName: 'levelOrder',
    isDaily: false,
    points: 100,
    acceptanceRate: 67.3,
    solvedCount: 2900
  },
  {
    id: 'prob-24',
    title: 'Median of Two Sorted Arrays',
    slug: 'median-of-two-sorted-arrays',
    difficulty: 'Hard',
    category: 'Binary Search',
    tags: ['Binary Search', 'Arrays', 'Divide and Conquer'],
    description: 'Given two sorted arrays `nums1` and `nums2` of size `m` and `n` respectively, return the median of the two sorted arrays. The overall run time complexity should be `O(log (m+n))`.',
    inputFormat: 'Two sorted arrays `nums1` and `nums2`.',
    outputFormat: 'Float/Number representing the median.',
    constraints: ['nums1.length == m', 'nums2.length == n', '0 <= m <= 1000', '0 <= n <= 1000', '1 <= m + n <= 2000'],
    examples: [
      { input: 'nums1 = [1,3], nums2 = [2]', output: '2.0' },
      { input: 'nums1 = [1,2], nums2 = [3,4]', output: '2.5' }
    ],
    starterCode: {
      javascript: `function findMedianSortedArrays(nums1, nums2) {
  const merged = [...nums1, ...nums2].sort((a, b) => a - b);
  const mid = Math.floor(merged.length / 2);
  if (merged.length % 2 === 0) {
    return (merged[mid - 1] + merged[mid]) / 2;
  }
  return merged[mid];
}`,
      python: `def findMedianSortedArrays(nums1: list[int], nums2: list[int]) -> float:
    merged = sorted(nums1 + nums2)
    mid = len(merged) // 2
    if len(merged) % 2 == 0:
        return (merged[mid - 1] + merged[mid]) / 2.0
    return float(merged[mid])`
    },
    functionName: 'findMedianSortedArrays',
    isDaily: false,
    points: 150,
    acceptanceRate: 38.2,
    solvedCount: 1500
  },
  {
    id: 'prob-25',
    title: 'Course Schedule: Cycle Detection',
    slug: 'course-schedule',
    difficulty: 'Medium',
    category: 'Graph & Matrix',
    tags: ['Graph', 'Topological Sort', 'DFS', 'BFS'],
    description: `There are a total of \`numCourses\` courses you have to take, labeled from \`0\` to \`numCourses - 1\`. You are given an array \`prerequisites\` where \`prerequisites[i] = [a_i, b_i]\` indicates that you must take course \`b_i\` first if you want to take course \`a_i\`.
Return \`true\` if you can finish all courses. Otherwise, return \`false\`.`,
    inputFormat: 'Integer `numCourses` and 2D array `prerequisites`.',
    outputFormat: 'Boolean `true` or `false`.',
    constraints: ['1 <= numCourses <= 2000', '0 <= prerequisites.length <= 5000'],
    examples: [
      { input: 'numCourses = 2, prerequisites = [[1,0]]', output: 'true' },
      { input: 'numCourses = 2, prerequisites = [[1,0],[0,1]]', output: 'false' }
    ],
    starterCode: {
      javascript: `function canFinish(numCourses, prerequisites) {
  const adj = Array.from({ length: numCourses }, () => []);
  const inDegree = new Array(numCourses).fill(0);
  for (const [a, b] of prerequisites) {
    adj[b].push(a);
    inDegree[a]++;
  }
  const queue = [];
  for (let i = 0; i < numCourses; i++) {
    if (inDegree[i] === 0) queue.push(i);
  }
  let count = 0;
  while (queue.length > 0) {
    const node = queue.shift();
    count++;
    for (const next of adj[node]) {
      inDegree[next]--;
      if (inDegree[next] === 0) queue.push(next);
    }
  }
  return count === numCourses;
}`,
      python: `def canFinish(numCourses: int, prerequisites: list[list[int]]) -> bool:
    from collections import deque
    adj = [[] for _ in range(numCourses)]
    in_degree = [0] * numCourses
    for a, b in prerequisites:
        adj[b].append(a)
        in_degree[a] += 1
    q = deque([i for i in range(numCourses) if in_degree[i] == 0])
    count = 0
    while q:
        node = q.popleft()
        count += 1
        for nxt in adj[node]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                q.append(nxt)
    return count == numCourses`
    },
    functionName: 'canFinish',
    isDaily: false,
    points: 100,
    acceptanceRate: 46.5,
    solvedCount: 2350
  },
  {
    id: 'prob-26',
    title: '3Sum Closest Target',
    slug: '3sum-closest',
    difficulty: 'Medium',
    category: 'Two Pointers',
    tags: ['Two Pointers', 'Sorting', 'Arrays'],
    description: 'Given an integer array `nums` of length `n` and an integer `target`, find three integers in `nums` such that the sum is closest to `target`. Return the sum of the three integers. You may assume that each input would have exactly one solution.',
    inputFormat: 'Array `nums` and target integer.',
    outputFormat: 'Closest sum as an integer.',
    constraints: ['3 <= nums.length <= 500', '-1000 <= nums[i] <= 1000', '-10^4 <= target <= 10^4'],
    examples: [
      { input: 'nums = [-1,2,1,-4], target = 1', output: '2', explanation: 'The sum that is closest to the target is 2. (-1 + 2 + 1 = 2).' }
    ],
    starterCode: {
      javascript: `function threeSumClosest(nums, target) {
  nums.sort((a, b) => a - b);
  let closest = nums[0] + nums[1] + nums[2];
  for (let i = 0; i < nums.length - 2; i++) {
    let l = i + 1, r = nums.length - 1;
    while (l < r) {
      const current = nums[i] + nums[l] + nums[r];
      if (Math.abs(current - target) < Math.abs(closest - target)) {
        closest = current;
      }
      if (current < target) l++;
      else if (current > target) r--;
      else return target;
    }
  }
  return closest;
}`,
      python: `def threeSumClosest(nums: list[int], target: int) -> int:
    nums.sort()
    closest = nums[0] + nums[1] + nums[2]
    for i in range(len(nums) - 2):
        l, r = i + 1, len(nums) - 1
        while l < r:
            cur = nums[i] + nums[l] + nums[r]
            if abs(cur - target) < abs(closest - target):
                closest = cur
            if cur < target: l += 1
            elif cur > target: r -= 1
            else: return target
    return closest`
    },
    functionName: 'threeSumClosest',
    isDaily: false,
    points: 100,
    acceptanceRate: 46.1,
    solvedCount: 1980
  }
];

export const TEST_CASES: Record<string, TestCase[]> = {
  'prob-1': [
    {
      id: 'tc-1-1',
      problemId: 'prob-1',
      input: '[[2, 7, 11, 15], 9]',
      expectedOutput: '[0, 1]',
      isHidden: false,
      explanation: '2 + 7 = 9 at indices 0 and 1.'
    },
    {
      id: 'tc-1-2',
      problemId: 'prob-1',
      input: '[[1, 4, 3, 2, 5], 6]',
      expectedOutput: '[1, 3]',
      isHidden: false,
      explanation: 'Pairs summing to 6: (1,5) gap=4; (4,2) gap=2. Gap 2 is minimal.'
    },
    {
      id: 'tc-1-3',
      problemId: 'prob-1',
      input: '[[3, 2, 4], 6]',
      expectedOutput: '[1, 2]',
      isHidden: false,
      explanation: '2 + 4 = 6 at indices 1 and 2.'
    },
    {
      id: 'tc-1-4',
      problemId: 'prob-1',
      input: '[[1, 2, 3, 4, 5, 6], 100]',
      expectedOutput: '[]',
      isHidden: true,
      explanation: 'No two elements sum to 100.'
    },
    {
      id: 'tc-1-5',
      problemId: 'prob-1',
      input: '[[-5, -2, 3, 7, 10], 5]',
      expectedOutput: '[1, 3]',
      isHidden: true,
      explanation: '(-2) + 7 = 5 at indices 1 and 3. (-5) + 10 = 5 with gap 15. Min gap is |-2 - 7| = 9.'
    }
  ],
  'prob-2': [
    { id: 'tc-2-1', problemId: 'prob-2', input: '["IceCreAm"]', expectedOutput: '"AceCreIm"', isHidden: false },
    { id: 'tc-2-2', problemId: 'prob-2', input: '["leetcode"]', expectedOutput: '"leotcede"', isHidden: false },
    { id: 'tc-2-3', problemId: 'prob-2', input: '["aA"]', expectedOutput: '"Aa"', isHidden: false },
    { id: 'tc-2-4', problemId: 'prob-2', input: '["rhythm"]', expectedOutput: '"rhythm"', isHidden: true },
    { id: 'tc-2-5', problemId: 'prob-2', input: '["hello world"]', expectedOutput: '"hollo werld"', isHidden: true }
  ],
  'prob-3': [
    { id: 'tc-3-1', problemId: 'prob-3', input: '[[1,8,6,2,5,4,8,3,7]]', expectedOutput: '49', isHidden: false },
    { id: 'tc-3-2', problemId: 'prob-3', input: '[[1,1]]', expectedOutput: '1', isHidden: false },
    { id: 'tc-3-3', problemId: 'prob-3', input: '[[4,3,2,1,4]]', expectedOutput: '16', isHidden: false },
    { id: 'tc-3-4', problemId: 'prob-3', input: '[[1,2,1]]', expectedOutput: '2', isHidden: true },
    { id: 'tc-3-5', problemId: 'prob-3', input: '[[2,3,4,5,18,17,6]]', expectedOutput: '17', isHidden: true }
  ],
  'prob-4': [
    { id: 'tc-4-1', problemId: 'prob-4', input: '["abcabcbb"]', expectedOutput: '3', isHidden: false },
    { id: 'tc-4-2', problemId: 'prob-4', input: '["bbbbb"]', expectedOutput: '1', isHidden: false },
    { id: 'tc-4-3', problemId: 'prob-4', input: '["pwwkew"]', expectedOutput: '3', isHidden: false },
    { id: 'tc-4-4', problemId: 'prob-4', input: '[""]', expectedOutput: '0', isHidden: true },
    { id: 'tc-4-5', problemId: 'prob-4', input: '["au"]', expectedOutput: '2', isHidden: true }
  ],
  'prob-5': [
    { id: 'tc-5-1', problemId: 'prob-5', input: '[[-2,1,-3,4,-1,2,1,-5,4]]', expectedOutput: '6', isHidden: false },
    { id: 'tc-5-2', problemId: 'prob-5', input: '[[1]]', expectedOutput: '1', isHidden: false },
    { id: 'tc-5-3', problemId: 'prob-5', input: '[[5,4,-1,7,8]]', expectedOutput: '23', isHidden: false },
    { id: 'tc-5-4', problemId: 'prob-5', input: '[[-10,-2,-3,-1]]', expectedOutput: '-1', isHidden: true },
    { id: 'tc-5-5', problemId: 'prob-5', input: '[[-2,-1]]', expectedOutput: '-1', isHidden: true }
  ],
  'prob-6': [
    { id: 'tc-6-1', problemId: 'prob-6', input: '[[1,2,3,4]]', expectedOutput: '[24,12,8,6]', isHidden: false },
    { id: 'tc-6-2', problemId: 'prob-6', input: '[[-1,1,0,-3,3]]', expectedOutput: '[0,0,9,0,0]', isHidden: false },
    { id: 'tc-6-3', problemId: 'prob-6', input: '[[0,0]]', expectedOutput: '[0,0]', isHidden: false },
    { id: 'tc-6-4', problemId: 'prob-6', input: '[[2,3]]', expectedOutput: '[3,2]', isHidden: true },
    { id: 'tc-6-5', problemId: 'prob-6', input: '[[1,1,1,1]]', expectedOutput: '[1,1,1,1]', isHidden: true }
  ],
  'prob-7': [
    { id: 'tc-7-1', problemId: 'prob-7', input: '[[[1,3],[2,6],[8,10],[15,18]]]', expectedOutput: '[[1,6],[8,10],[15,18]]', isHidden: false },
    { id: 'tc-7-2', problemId: 'prob-7', input: '[[[1,4],[4,5]]]', expectedOutput: '[[1,5]]', isHidden: false },
    { id: 'tc-7-3', problemId: 'prob-7', input: '[[[1,4],[0,4]]]', expectedOutput: '[[0,4]]', isHidden: false },
    { id: 'tc-7-4', problemId: 'prob-7', input: '[[[1,4],[2,3]]]', expectedOutput: '[[1,4]]', isHidden: true },
    { id: 'tc-7-5', problemId: 'prob-7', input: '[[[2,3],[4,5],[6,7],[8,9],[1,10]]]', expectedOutput: '[[1,10]]', isHidden: true }
  ],
  'prob-8': [
    { id: 'tc-8-1', problemId: 'prob-8', input: '[[1,1,1,2,2,3], 2]', expectedOutput: '[1,2]', isHidden: false },
    { id: 'tc-8-2', problemId: 'prob-8', input: '[[1], 1]', expectedOutput: '[1]', isHidden: false },
    { id: 'tc-8-3', problemId: 'prob-8', input: '[[4,1,-1,2,-1,2,3], 2]', expectedOutput: '[-1,2]', isHidden: false },
    { id: 'tc-8-4', problemId: 'prob-8', input: '[[3,0,1,0], 1]', expectedOutput: '[0]', isHidden: true },
    { id: 'tc-8-5', problemId: 'prob-8', input: '[[5,5,5,5,5], 1]', expectedOutput: '[5]', isHidden: true }
  ],
  'prob-9': [
    { id: 'tc-9-1', problemId: 'prob-9', input: '["()"]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-9-2', problemId: 'prob-9', input: '["(*)"]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-9-3', problemId: 'prob-9', input: '["(*))"]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-9-4', problemId: 'prob-9', input: '["("]', expectedOutput: 'false', isHidden: true },
    { id: 'tc-9-5', problemId: 'prob-9', input: '["(((**))"]', expectedOutput: 'true', isHidden: true }
  ],
  'prob-10': [
    { id: 'tc-10-1', problemId: 'prob-10', input: '[[73,74,75,71,69,72,76,73]]', expectedOutput: '[1,1,4,2,1,1,0,0]', isHidden: false },
    { id: 'tc-10-2', problemId: 'prob-10', input: '[[30,40,50,60]]', expectedOutput: '[1,1,1,0]', isHidden: false },
    { id: 'tc-10-3', problemId: 'prob-10', input: '[[30,60,90]]', expectedOutput: '[1,1,0]', isHidden: false },
    { id: 'tc-10-4', problemId: 'prob-10', input: '[[90,80,70,60]]', expectedOutput: '[0,0,0,0]', isHidden: true },
    { id: 'tc-10-5', problemId: 'prob-10', input: '[[55,38,53,81,61,93,97,32,43,78]]', expectedOutput: '[3,1,1,2,1,1,0,1,1,0]', isHidden: true }
  ],
  'prob-11': [
    { id: 'tc-11-1', problemId: 'prob-11', input: '[[1,2,5], 11]', expectedOutput: '3', isHidden: false },
    { id: 'tc-11-2', problemId: 'prob-11', input: '[[2], 3]', expectedOutput: '-1', isHidden: false },
    { id: 'tc-11-3', problemId: 'prob-11', input: '[[1], 0]', expectedOutput: '0', isHidden: false },
    { id: 'tc-11-4', problemId: 'prob-11', input: '[[186,419,83,408], 6249]', expectedOutput: '20', isHidden: true },
    { id: 'tc-11-5', problemId: 'prob-11', input: '[[2,5,10,1], 27]', expectedOutput: '4', isHidden: true }
  ],
  'prob-12': [
    { id: 'tc-12-1', problemId: 'prob-12', input: '[[10,9,2,5,3,7,101,18]]', expectedOutput: '4', isHidden: false },
    { id: 'tc-12-2', problemId: 'prob-12', input: '[[0,1,0,3,2,3]]', expectedOutput: '4', isHidden: false },
    { id: 'tc-12-3', problemId: 'prob-12', input: '[[7,7,7,7,7,7,7]]', expectedOutput: '1', isHidden: false },
    { id: 'tc-12-4', problemId: 'prob-12', input: '[[4,10,4,3,8,9]]', expectedOutput: '3', isHidden: true },
    { id: 'tc-12-5', problemId: 'prob-12', input: '[[1,3,6,7,9,4,10,5,6]]', expectedOutput: '6', isHidden: true }
  ],
  'prob-13': [
    { id: 'tc-13-1', problemId: 'prob-13', input: '[[[2,1,1],[1,1,0],[0,1,1]]]', expectedOutput: '4', isHidden: false },
    { id: 'tc-13-2', problemId: 'prob-13', input: '[[[2,1,1],[0,1,1],[1,0,1]]]', expectedOutput: '-1', isHidden: false },
    { id: 'tc-13-3', problemId: 'prob-13', input: '[[[0,2]]]', expectedOutput: '0', isHidden: false },
    { id: 'tc-13-4', problemId: 'prob-13', input: '[[[1]]]', expectedOutput: '-1', isHidden: true },
    { id: 'tc-13-5', problemId: 'prob-13', input: '[[[2,2],[1,1],[0,0],[2,0]]]', expectedOutput: '1', isHidden: true }
  ],
  'prob-14': [
    { id: 'tc-14-1', problemId: 'prob-14', input: '[[4,5,6,7,0,1,2], 0]', expectedOutput: '4', isHidden: false },
    { id: 'tc-14-2', problemId: 'prob-14', input: '[[4,5,6,7,0,1,2], 3]', expectedOutput: '-1', isHidden: false },
    { id: 'tc-14-3', problemId: 'prob-14', input: '[[1], 0]', expectedOutput: '-1', isHidden: false },
    { id: 'tc-14-4', problemId: 'prob-14', input: '[[1], 1]', expectedOutput: '0', isHidden: true },
    { id: 'tc-14-5', problemId: 'prob-14', input: '[[5,1,3], 3]', expectedOutput: '2', isHidden: true }
  ],
  'prob-15': [
    { id: 'tc-15-1', problemId: 'prob-15', input: '[[0,1,0,2,1,0,1,3,2,1,2,1]]', expectedOutput: '6', isHidden: false },
    { id: 'tc-15-2', problemId: 'prob-15', input: '[[4,2,0,3,2,5]]', expectedOutput: '9', isHidden: false },
    { id: 'tc-15-3', problemId: 'prob-15', input: '[[3,0,2,0,4]]', expectedOutput: '7', isHidden: false },
    { id: 'tc-15-4', problemId: 'prob-15', input: '[[2,0,2]]', expectedOutput: '2', isHidden: true },
    { id: 'tc-15-5', problemId: 'prob-15', input: '[[1,2,3,4,5]]', expectedOutput: '0', isHidden: true }
  ],
  'prob-16': [
    { id: 'tc-16-1', problemId: 'prob-16', input: '["horse", "ros"]', expectedOutput: '3', isHidden: false },
    { id: 'tc-16-2', problemId: 'prob-16', input: '["intention", "execution"]', expectedOutput: '5', isHidden: false },
    { id: 'tc-16-3', problemId: 'prob-16', input: '["", "a"]', expectedOutput: '1', isHidden: false },
    { id: 'tc-16-4', problemId: 'prob-16', input: '["abc", "abc"]', expectedOutput: '0', isHidden: true },
    { id: 'tc-16-5', problemId: 'prob-16', input: '["zoologico", "zoologia"]', expectedOutput: '2', isHidden: true }
  ],
  'prob-17': [
    { id: 'tc-17-1', problemId: 'prob-17', input: '[[10,15,20]]', expectedOutput: '15', isHidden: false },
    { id: 'tc-17-2', problemId: 'prob-17', input: '[[1,100,1,1,1,100,1,1,100,1]]', expectedOutput: '6', isHidden: false },
    { id: 'tc-17-3', problemId: 'prob-17', input: '[[0,0,0,0]]', expectedOutput: '0', isHidden: false },
    { id: 'tc-17-4', problemId: 'prob-17', input: '[[10,15]]', expectedOutput: '10', isHidden: true },
    { id: 'tc-17-5', problemId: 'prob-17', input: '[[1,2,3,4,5,6,7]]', expectedOutput: '12', isHidden: true }
  ],
  'prob-18': [
    { id: 'tc-18-1', problemId: 'prob-18', input: '[[2,3,2]]', expectedOutput: '3', isHidden: false },
    { id: 'tc-18-2', problemId: 'prob-18', input: '[[1,2,3,1]]', expectedOutput: '4', isHidden: false },
    { id: 'tc-18-3', problemId: 'prob-18', input: '[[1,2,3]]', expectedOutput: '3', isHidden: false },
    { id: 'tc-18-4', problemId: 'prob-18', input: '[[20]]', expectedOutput: '20', isHidden: true },
    { id: 'tc-18-5', problemId: 'prob-18', input: '[[1,3,1,3,100]]', expectedOutput: '103', isHidden: true }
  ],
  'prob-19': [
    { id: 'tc-19-1', problemId: 'prob-19', input: '["leetcode", ["leet","code"]]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-19-2', problemId: 'prob-19', input: '["applepenapple", ["apple","pen"]]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-19-3', problemId: 'prob-19', input: '["catsandog", ["cats","dog","sand","and","cat"]]', expectedOutput: 'false', isHidden: false },
    { id: 'tc-19-4', problemId: 'prob-19', input: '["a", ["b"]]', expectedOutput: 'false', isHidden: true },
    { id: 'tc-19-5', problemId: 'prob-19', input: '["cars", ["car","ca","rs"]]', expectedOutput: 'true', isHidden: true }
  ],
  'prob-20': [
    { id: 'tc-20-1', problemId: 'prob-20', input: '[[2,3,1,1,4]]', expectedOutput: '2', isHidden: false },
    { id: 'tc-20-2', problemId: 'prob-20', input: '[[2,3,0,1,4]]', expectedOutput: '2', isHidden: false },
    { id: 'tc-20-3', problemId: 'prob-20', input: '[[1,1,1,1]]', expectedOutput: '3', isHidden: false },
    { id: 'tc-20-4', problemId: 'prob-20', input: '[[1]]', expectedOutput: '0', isHidden: true },
    { id: 'tc-20-5', problemId: 'prob-20', input: '[[7,0,9,6,9,6,1,7,9,0,1,2,9,0,3]]', expectedOutput: '2', isHidden: true }
  ],
  'prob-21': [
    { id: 'tc-21-1', problemId: 'prob-21', input: '[[3,2,1,5,6,4], 2]', expectedOutput: '5', isHidden: false },
    { id: 'tc-21-2', problemId: 'prob-21', input: '[[3,2,3,1,2,4,5,5,6], 4]', expectedOutput: '4', isHidden: false },
    { id: 'tc-21-3', problemId: 'prob-21', input: '[[1], 1]', expectedOutput: '1', isHidden: false },
    { id: 'tc-21-4', problemId: 'prob-21', input: '[[7,10,4,3,20,15], 3]', expectedOutput: '10', isHidden: true },
    { id: 'tc-21-5', problemId: 'prob-21', input: '[[-1,2,0], 2]', expectedOutput: '0', isHidden: true }
  ],
  'prob-22': [
    { id: 'tc-22-1', problemId: 'prob-22', input: '["aba"]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-22-2', problemId: 'prob-22', input: '["abca"]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-22-3', problemId: 'prob-22', input: '["abc"]', expectedOutput: 'false', isHidden: false },
    { id: 'tc-22-4', problemId: 'prob-22', input: '["racecar"]', expectedOutput: 'true', isHidden: true },
    { id: 'tc-22-5', problemId: 'prob-22', input: '["deeee"]', expectedOutput: 'true', isHidden: true }
  ],
  'prob-23': [
    { id: 'tc-23-1', problemId: 'prob-23', input: '[[3,9,20,null,null,15,7]]', expectedOutput: '[[3],[9,20],[15,7]]', isHidden: false },
    { id: 'tc-23-2', problemId: 'prob-23', input: '[[1]]', expectedOutput: '[[1]]', isHidden: false },
    { id: 'tc-23-3', problemId: 'prob-23', input: '[[]]', expectedOutput: '[]', isHidden: false },
    { id: 'tc-23-4', problemId: 'prob-23', input: '[[1,2,3,4,5]]', expectedOutput: '[[1],[2,3],[4,5]]', isHidden: true },
    { id: 'tc-23-5', problemId: 'prob-23', input: '[[1,null,2,null,3]]', expectedOutput: '[[1],[2],[3]]', isHidden: true }
  ],
  'prob-24': [
    { id: 'tc-24-1', problemId: 'prob-24', input: '[[1,3], [2]]', expectedOutput: '2', isHidden: false },
    { id: 'tc-24-2', problemId: 'prob-24', input: '[[1,2], [3,4]]', expectedOutput: '2.5', isHidden: false },
    { id: 'tc-24-3', problemId: 'prob-24', input: '[[0,0], [0,0]]', expectedOutput: '0', isHidden: false },
    { id: 'tc-24-4', problemId: 'prob-24', input: '[[], [1]]', expectedOutput: '1', isHidden: true },
    { id: 'tc-24-5', problemId: 'prob-24', input: '[[2], []]', expectedOutput: '2', isHidden: true }
  ],
  'prob-25': [
    { id: 'tc-25-1', problemId: 'prob-25', input: '[2, [[1,0]]]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-25-2', problemId: 'prob-25', input: '[2, [[1,0],[0,1]]]', expectedOutput: 'false', isHidden: false },
    { id: 'tc-25-3', problemId: 'prob-25', input: '[3, [[0,1],[0,2],[1,2]]]', expectedOutput: 'true', isHidden: false },
    { id: 'tc-25-4', problemId: 'prob-25', input: '[1, []]', expectedOutput: 'true', isHidden: true },
    { id: 'tc-25-5', problemId: 'prob-25', input: '[4, [[2,0],[1,0],[3,1],[3,2],[1,3]]]', expectedOutput: 'false', isHidden: true }
  ],
  'prob-26': [
    { id: 'tc-26-1', problemId: 'prob-26', input: '[[-1,2,1,-4], 1]', expectedOutput: '2', isHidden: false },
    { id: 'tc-26-2', problemId: 'prob-26', input: '[[0,0,0], 1]', expectedOutput: '0', isHidden: false },
    { id: 'tc-26-3', problemId: 'prob-26', input: '[[1,1,1,0], -100]', expectedOutput: '2', isHidden: false },
    { id: 'tc-26-4', problemId: 'prob-26', input: '[[1,2,4,8,16,32,64,128], 82]', expectedOutput: '82', isHidden: true },
    { id: 'tc-26-5', problemId: 'prob-26', input: '[[-3,-2,-5,3,-4], -1]', expectedOutput: '-2', isHidden: true }
  ]
};

// Initial Users
export const SEED_USERS: User[] = [
  {
    id: 'user-alex',
    username: 'alexchen',
    name: 'Alex Chen',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CSE',
    college: 'Apex Institute of Tech',
    teamId: 'team-binary-beasts',
    role: 'Captain',
    currentStreak: 7,
    maxStreak: 14,
    totalSolved: 19,
    score: 850,
    activityHistory: {
      '2026-11-14': 2,
      '2026-11-15': 1,
      '2026-11-16': 3,
      '2026-11-17': 2,
      '2026-11-18': 4,
      '2026-11-19': 2,
      '2026-11-20': 0
    }
  },
  {
    id: 'user-priya',
    username: 'priyasharma',
    name: 'Priya Sharma',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CSE',
    college: 'Apex Institute of Tech',
    teamId: 'team-binary-beasts',
    role: 'Member',
    currentStreak: 6,
    maxStreak: 9,
    totalSolved: 16,
    score: 720,
    activityHistory: {
      '2026-11-15': 1,
      '2026-11-16': 2,
      '2026-11-17': 1,
      '2026-11-18': 3,
      '2026-11-19': 1
    }
  },
  {
    id: 'user-marcus',
    username: 'marcusvance',
    name: 'Marcus Vance',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CSE',
    college: 'Apex Institute of Tech',
    teamId: 'team-binary-beasts',
    role: 'Member',
    currentStreak: 5,
    maxStreak: 12,
    totalSolved: 15,
    score: 680,
    activityHistory: {
      '2026-11-16': 1,
      '2026-11-17': 2,
      '2026-11-18': 2,
      '2026-11-19': 2
    }
  },
  // AlgoNinjas (Current 1st place)
  {
    id: 'user-rohit',
    username: 'rohitverma',
    name: 'Rohit Verma',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - IT',
    college: 'National Tech University',
    teamId: 'team-algo-ninjas',
    role: 'Captain',
    currentStreak: 12,
    maxStreak: 21,
    totalSolved: 24,
    score: 1100,
    activityHistory: { '2026-11-20': 1, '2026-11-19': 3 }
  },
  {
    id: 'user-elena',
    username: 'elenarostova',
    name: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - IT',
    college: 'National Tech University',
    teamId: 'team-algo-ninjas',
    role: 'Member',
    currentStreak: 8,
    maxStreak: 15,
    totalSolved: 19,
    score: 890,
    activityHistory: { '2026-11-20': 1, '2026-11-19': 2 }
  },
  {
    id: 'user-sam',
    username: 'samlee',
    name: 'Sam Lee',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - IT',
    college: 'National Tech University',
    teamId: 'team-algo-ninjas',
    role: 'Member',
    currentStreak: 10,
    maxStreak: 16,
    totalSolved: 18,
    score: 860,
    activityHistory: { '2026-11-20': 1, '2026-11-19': 2 }
  },
  // ByteBrawlers (Current 2nd place)
  {
    id: 'user-david',
    username: 'davidkim',
    name: 'David Kim',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CS',
    college: 'Metro State Engineering',
    teamId: 'team-byte-brawlers',
    role: 'Captain',
    currentStreak: 9,
    maxStreak: 18,
    totalSolved: 21,
    score: 980,
    activityHistory: { '2026-11-19': 2 }
  },
  {
    id: 'user-sarah',
    username: 'sarahconnor',
    name: 'Sarah Connor',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CS',
    college: 'Metro State Engineering',
    teamId: 'team-byte-brawlers',
    role: 'Member',
    currentStreak: 7,
    maxStreak: 11,
    totalSolved: 17,
    score: 820,
    activityHistory: { '2026-11-19': 1 }
  },
  {
    id: 'user-jason',
    username: 'jasonbrody',
    name: 'Jason Brody',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - CS',
    college: 'Metro State Engineering',
    teamId: 'team-byte-brawlers',
    role: 'Member',
    currentStreak: 6,
    maxStreak: 14,
    totalSolved: 16,
    score: 790,
    activityHistory: { '2026-11-19': 1 }
  },
  // DP Dynamos (Current 4th place)
  {
    id: 'user-ananya',
    username: 'ananyaiyer',
    name: 'Ananya Iyer',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - AI&DS',
    college: 'Silicon Valley College',
    teamId: 'team-dp-dynamos',
    role: 'Captain',
    currentStreak: 4,
    maxStreak: 10,
    totalSolved: 14,
    score: 640,
    activityHistory: { '2026-11-19': 2 }
  },
  {
    id: 'user-kenji',
    username: 'kenjisato',
    name: 'Kenji Sato',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - AI&DS',
    college: 'Silicon Valley College',
    teamId: 'team-dp-dynamos',
    role: 'Member',
    currentStreak: 5,
    maxStreak: 8,
    totalSolved: 12,
    score: 560,
    activityHistory: { '2026-11-19': 1 }
  },
  {
    id: 'user-chloe',
    username: 'chloebennett',
    name: 'Chloe Bennett',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2026 - AI&DS',
    college: 'Silicon Valley College',
    teamId: 'team-dp-dynamos',
    role: 'Member',
    currentStreak: 3,
    maxStreak: 7,
    totalSolved: 11,
    score: 520,
    activityHistory: { '2026-11-19': 1 }
  },
  // BitShifters (Current 5th place)
  {
    id: 'user-maya',
    username: 'mayalin',
    name: 'Maya Lin',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - ECE',
    college: 'Frontier Tech',
    teamId: 'team-bit-shifters',
    role: 'Captain',
    currentStreak: 2,
    maxStreak: 6,
    totalSolved: 10,
    score: 490,
    activityHistory: { '2026-11-19': 1 }
  },
  {
    id: 'user-liam',
    username: 'liamoconnor',
    name: 'Liam O\'Connor',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - ECE',
    college: 'Frontier Tech',
    teamId: 'team-bit-shifters',
    role: 'Member',
    currentStreak: 3,
    maxStreak: 9,
    totalSolved: 9,
    score: 450,
    activityHistory: { '2026-11-18': 1 }
  },
  {
    id: 'user-fatima',
    username: 'fatimazahra',
    name: 'Fatima Zahra',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    batch: 'Batch 2025 - ECE',
    college: 'Frontier Tech',
    teamId: 'team-bit-shifters',
    role: 'Member',
    currentStreak: 2,
    maxStreak: 5,
    totalSolved: 8,
    score: 410,
    activityHistory: { '2026-11-18': 1 }
  }
];

// Initial Teams configured specifically for the hackathon demo condition:
// Demo prompt:
// "The user logs into CodeDojo Daily and views today's challenge: 'Two Sum Variant'. The presenter types a solution in the integrated code editor and clicks 'Run Tests'; all 4 test cases pass with green status badges. The user submits the code, and their team 'Binary Beasts' instantly climbs from 3rd to 1st place on the live team contest leaderboard."
//
// So:
// 1st: AlgoNinjas (2850 pts)
// 2nd: ByteBrawlers (2590 pts)
// 3rd: Binary Beasts (2520 pts - Base 2250 + Streak 270)
// When Alex submits 'Two Sum Variant' (+100 base + 50 speed + 200 first blood streak = +350 pts):
// Binary Beasts reaches 2870 pts -> jumps to 1st place!
export const SEED_TEAMS: Team[] = [
  {
    id: 'team-algo-ninjas',
    name: 'AlgoNinjas',
    tagline: 'Silent O(1) space, lethal O(log n) time',
    avatar: '🥷',
    joinCode: 'NINJA9',
    batch: 'Batch 2025 - IT',
    totalScore: 2850,
    baseScore: 2500,
    streakBonus: 250,
    speedBonus: 100,
    solveCount: 61,
    rank: 1,
    previousRank: 1,
    rankChange: 0,
    members: [],
    completedProblemIds: ['prob-1', 'prob-2', 'prob-3', 'prob-4', 'prob-5', 'prob-6']
  },
  {
    id: 'team-byte-brawlers',
    name: 'ByteBrawlers',
    tagline: 'Crushing edge cases with brute force & finesse',
    avatar: '🥊',
    joinCode: 'BRAWL4',
    batch: 'Batch 2026 - CS',
    totalScore: 2590,
    baseScore: 2310,
    streakBonus: 200,
    speedBonus: 80,
    solveCount: 54,
    rank: 2,
    previousRank: 2,
    rankChange: 0,
    members: [],
    completedProblemIds: ['prob-2', 'prob-3', 'prob-4', 'prob-5', 'prob-6']
  },
  {
    id: 'team-binary-beasts',
    name: 'Binary Beasts',
    tagline: 'Zeroes and ones bow before us',
    avatar: '🐺',
    joinCode: 'BEAST7',
    batch: 'Batch 2026 - CSE',
    totalScore: 2520,
    baseScore: 2250,
    streakBonus: 270,
    speedBonus: 0,
    solveCount: 50,
    rank: 3,
    previousRank: 3,
    rankChange: 0,
    members: [],
    completedProblemIds: ['prob-2', 'prob-3', 'prob-4', 'prob-5']
  },
  {
    id: 'team-dp-dynamos',
    name: 'DP Dynamos',
    tagline: 'Remembering past results to conquer the future',
    avatar: '⚡',
    joinCode: 'DYNA3',
    batch: 'Batch 2026 - AI&DS',
    totalScore: 1720,
    baseScore: 1560,
    streakBonus: 120,
    speedBonus: 40,
    solveCount: 37,
    rank: 4,
    previousRank: 4,
    rankChange: 0,
    members: [],
    completedProblemIds: ['prob-2', 'prob-3']
  },
  {
    id: 'team-bit-shifters',
    name: 'BitShifters',
    tagline: 'Masking interrupts and shifting bits at lightspeed',
    avatar: '🔮',
    joinCode: 'SHIFT8',
    batch: 'Batch 2025 - ECE',
    totalScore: 1350,
    baseScore: 1250,
    streakBonus: 80,
    speedBonus: 20,
    solveCount: 27,
    rank: 5,
    previousRank: 5,
    rankChange: 0,
    members: [],
    completedProblemIds: ['prob-2']
  }
];
