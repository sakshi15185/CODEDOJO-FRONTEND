import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { PROBLEMS, TEST_CASES, SEED_USERS, SEED_TEAMS } from './seedData.js';
import { Problem, TestCase, User, Team, Submission, DerbyWarEvent, DerbySession } from '../types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '..', '..', 'codedojo.sqlite');

export class Database {
  private db: DatabaseSync;

  constructor() {
    this.db = new DatabaseSync(DB_PATH);
    this.initSchema();
    this.seedInitialData();
  }

  private initSchema() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS problems (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        difficulty TEXT NOT NULL,
        category TEXT NOT NULL,
        tags TEXT NOT NULL,
        description TEXT NOT NULL,
        input_format TEXT NOT NULL,
        output_format TEXT NOT NULL,
        constraints TEXT NOT NULL,
        examples TEXT NOT NULL,
        starter_code TEXT NOT NULL,
        function_name TEXT NOT NULL,
        is_daily INTEGER NOT NULL DEFAULT 0,
        daily_date TEXT,
        points INTEGER NOT NULL DEFAULT 100,
        acceptance_rate REAL DEFAULT 50.0,
        solved_count INTEGER DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS test_cases (
        id TEXT PRIMARY KEY,
        problem_id TEXT NOT NULL,
        input TEXT NOT NULL,
        expected_output TEXT NOT NULL,
        is_hidden INTEGER NOT NULL DEFAULT 0,
        explanation TEXT,
        FOREIGN KEY (problem_id) REFERENCES problems(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        avatar TEXT NOT NULL,
        batch TEXT NOT NULL,
        college TEXT NOT NULL,
        team_id TEXT,
        role TEXT NOT NULL DEFAULT 'Member',
        current_streak INTEGER NOT NULL DEFAULT 0,
        max_streak INTEGER NOT NULL DEFAULT 0,
        total_solved INTEGER NOT NULL DEFAULT 0,
        score INTEGER NOT NULL DEFAULT 0,
        activity_history TEXT NOT NULL DEFAULT '{}'
      );

      CREATE TABLE IF NOT EXISTS teams (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        tagline TEXT NOT NULL,
        avatar TEXT NOT NULL,
        join_code TEXT NOT NULL UNIQUE,
        batch TEXT NOT NULL,
        total_score INTEGER NOT NULL DEFAULT 0,
        base_score INTEGER NOT NULL DEFAULT 0,
        streak_bonus INTEGER NOT NULL DEFAULT 0,
        speed_bonus INTEGER NOT NULL DEFAULT 0,
        solve_count INTEGER NOT NULL DEFAULT 0,
        rank INTEGER NOT NULL DEFAULT 1,
        previous_rank INTEGER NOT NULL DEFAULT 1,
        rank_change INTEGER NOT NULL DEFAULT 0,
        completed_problem_ids TEXT NOT NULL DEFAULT '[]'
      );

      CREATE TABLE IF NOT EXISTS submissions (
        id TEXT PRIMARY KEY,
        problem_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        team_id TEXT,
        code TEXT NOT NULL,
        language TEXT NOT NULL,
        status TEXT NOT NULL,
        runtime_ms REAL NOT NULL,
        memory_mb REAL NOT NULL,
        passed_count INTEGER NOT NULL,
        total_count INTEGER NOT NULL,
        points_awarded INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        details TEXT
      );

      CREATE TABLE IF NOT EXISTS derby_events (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        team_id TEXT NOT NULL,
        team_name TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        user_avatar TEXT NOT NULL,
        problem_id TEXT NOT NULL,
        problem_title TEXT NOT NULL,
        points INTEGER NOT NULL,
        message TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS derby_sessions (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        status TEXT NOT NULL,
        start_time TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL,
        multiplier REAL NOT NULL DEFAULT 1.5,
        featured_problem_ids TEXT NOT NULL
      );
    `);
  }

  private seedInitialData() {
    const existing = this.db.prepare('SELECT count(*) as count FROM problems').get() as { count: number };
    if (existing && existing.count > 0) {
      return; // already seeded
    }

    console.log('[Database] Seeding initial problems, teams and users...');

    // Seed Problems
    const insertProblem = this.db.prepare(`
      INSERT INTO problems (
        id, title, slug, difficulty, category, tags, description,
        input_format, output_format, constraints, examples, starter_code,
        function_name, is_daily, daily_date, points, acceptance_rate, solved_count
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const p of PROBLEMS) {
      insertProblem.run(
        p.id,
        p.title,
        p.slug,
        p.difficulty,
        p.category,
        JSON.stringify(p.tags),
        p.description,
        p.inputFormat,
        p.outputFormat,
        JSON.stringify(p.constraints),
        JSON.stringify(p.examples),
        JSON.stringify(p.starterCode),
        p.functionName,
        p.isDaily ? 1 : 0,
        p.dailyDate || null,
        p.points,
        p.acceptanceRate,
        p.solvedCount
      );
    }

    // Seed Test Cases
    const insertTc = this.db.prepare(`
      INSERT INTO test_cases (id, problem_id, input, expected_output, is_hidden, explanation)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    for (const [probId, testcases] of Object.entries(TEST_CASES)) {
      for (const tc of testcases) {
        insertTc.run(tc.id, probId, tc.input, tc.expectedOutput, tc.isHidden ? 1 : 0, tc.explanation || null);
      }
    }

    // Seed Users
    const insertUser = this.db.prepare(`
      INSERT INTO users (
        id, username, name, avatar, batch, college, team_id, role,
        current_streak, max_streak, total_solved, score, activity_history
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const u of SEED_USERS) {
      insertUser.run(
        u.id,
        u.username,
        u.name,
        u.avatar,
        u.batch,
        u.college,
        u.teamId,
        u.role,
        u.currentStreak,
        u.maxStreak,
        u.totalSolved,
        u.score,
        JSON.stringify(u.activityHistory)
      );
    }

    // Seed Teams
    const insertTeam = this.db.prepare(`
      INSERT INTO teams (
        id, name, tagline, avatar, join_code, batch, total_score,
        base_score, streak_bonus, speed_bonus, solve_count, rank,
        previous_rank, rank_change, completed_problem_ids
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const t of SEED_TEAMS) {
      insertTeam.run(
        t.id,
        t.name,
        t.tagline,
        t.avatar,
        t.joinCode,
        t.batch,
        t.totalScore,
        t.baseScore,
        t.streakBonus,
        t.speedBonus,
        t.solveCount,
        t.rank,
        t.previousRank,
        t.rankChange,
        JSON.stringify(t.completedProblemIds)
      );
    }

    // Seed Initial Derby Session
    const insertDerby = this.db.prepare(`
      INSERT INTO derby_sessions (id, title, status, start_time, duration_minutes, multiplier, featured_problem_ids)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const now = new Date();
    insertDerby.run(
      'derby-session-live',
      'Campus Clash: Weekend Speed Sprint #4',
      'active',
      now.toISOString(),
      60,
      1.5,
      JSON.stringify(['prob-1', 'prob-4', 'prob-7', 'prob-11', 'prob-15'])
    );

    // Initial War Events
    const insertEvent = this.db.prepare(`
      INSERT INTO derby_events (id, timestamp, team_id, team_name, user_id, user_name, user_avatar, problem_id, problem_title, points, message)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const pastEvents = [
      {
        id: 'evt-1',
        timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        team_id: 'team-algo-ninjas',
        team_name: 'AlgoNinjas',
        user_id: 'user-rohit',
        user_name: 'Rohit Verma',
        user_avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
        problem_id: 'prob-4',
        problem_title: 'Longest Substring Without Repeating',
        points: 150,
        message: 'FIRST BLOOD! Rohit cracked Longest Substring in 4 mins!'
      },
      {
        id: 'evt-2',
        timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
        team_id: 'team-byte-brawlers',
        team_name: 'ByteBrawlers',
        user_id: 'user-david',
        user_name: 'David Kim',
        user_avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150',
        problem_id: 'prob-7',
        problem_title: 'Merge Intervals',
        points: 140,
        message: 'David Kim executed Merge Intervals with 100% test pass!'
      },
      {
        id: 'evt-3',
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        team_id: 'team-binary-beasts',
        team_name: 'Binary Beasts',
        user_id: 'user-priya',
        user_name: 'Priya Sharma',
        user_avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
        problem_id: 'prob-2',
        problem_title: 'Reverse Vowels of a String',
        points: 75,
        message: 'Priya Sharma secured speed bonus on Reverse Vowels!'
      }
    ];

    for (const e of pastEvents) {
      insertEvent.run(
        e.id, e.timestamp, e.team_id, e.team_name, e.user_id, e.user_name,
        e.user_avatar, e.problem_id, e.problem_title, e.points, e.message
      );
    }

    console.log('[Database] Seed completed successfully.');
  }

  // PROBLEMS
  getProblems(): Problem[] {
    const rows = this.db.prepare('SELECT * FROM problems ORDER BY is_daily DESC, id ASC').all() as any[];
    return rows.map(r => ({
      id: r.id,
      title: r.title,
      slug: r.slug,
      difficulty: r.difficulty,
      category: r.category,
      tags: JSON.parse(r.tags),
      description: r.description,
      inputFormat: r.input_format,
      outputFormat: r.output_format,
      constraints: JSON.parse(r.constraints),
      examples: JSON.parse(r.examples),
      starterCode: JSON.parse(r.starter_code),
      functionName: r.function_name,
      isDaily: r.is_daily === 1,
      dailyDate: r.daily_date,
      points: r.points,
      acceptanceRate: r.acceptance_rate,
      solvedCount: r.solved_count
    }));
  }

  getProblemById(idOrSlug: string): Problem | null {
    const row = this.db.prepare('SELECT * FROM problems WHERE id = ? OR slug = ?').get(idOrSlug, idOrSlug) as any;
    if (!row) return null;
    return {
      id: row.id,
      title: row.title,
      slug: row.slug,
      difficulty: row.difficulty,
      category: row.category,
      tags: JSON.parse(row.tags),
      description: row.description,
      inputFormat: row.input_format,
      outputFormat: row.output_format,
      constraints: JSON.parse(row.constraints),
      examples: JSON.parse(row.examples),
      starterCode: JSON.parse(row.starter_code),
      functionName: row.function_name,
      isDaily: row.is_daily === 1,
      dailyDate: row.daily_date,
      points: row.points,
      acceptanceRate: row.acceptance_rate,
      solvedCount: row.solved_count
    };
  }

  getDailyProblem(): Problem | null {
    const row = this.db.prepare('SELECT * FROM problems WHERE is_daily = 1 LIMIT 1').get() as any;
    if (!row) return null;
    return this.getProblemById(row.id);
  }

  // TEST CASES
  getTestCases(problemId: string, includeHidden = false): TestCase[] {
    let query = 'SELECT * FROM test_cases WHERE problem_id = ?';
    if (!includeHidden) {
      query += ' AND is_hidden = 0';
    }
    const rows = this.db.prepare(query).all(problemId) as any[];
    return rows.map(r => ({
      id: r.id,
      problemId: r.problem_id,
      input: r.input,
      expectedOutput: r.expected_output,
      isHidden: r.is_hidden === 1,
      explanation: r.explanation
    }));
  }

  // TEAMS
  getTeams(): Team[] {
    const rows = this.db.prepare('SELECT * FROM teams ORDER BY total_score DESC').all() as any[];
    const users = this.getUsers();

    return rows.map((r, index) => {
      const currentRank = index + 1;
      const prevRank = r.previous_rank || currentRank;
      const rankChange = prevRank - currentRank; // positive means climbed up

      return {
        id: r.id,
        name: r.name,
        tagline: r.tagline,
        avatar: r.avatar,
        joinCode: r.join_code,
        batch: r.batch,
        totalScore: r.total_score,
        baseScore: r.base_score,
        streakBonus: r.streak_bonus,
        speedBonus: r.speed_bonus,
        solveCount: r.solve_count,
        rank: currentRank,
        previousRank: prevRank,
        rankChange: rankChange,
        completedProblemIds: JSON.parse(r.completed_problem_ids || '[]'),
        members: users.filter(u => u.teamId === r.id)
      };
    });
  }

  getTeamById(id: string): Team | null {
    const teams = this.getTeams();
    return teams.find(t => t.id === id) || null;
  }

  updateTeamScore(teamId: string, deltaBase: number, deltaStreak: number, deltaSpeed: number, problemId?: string) {
    const team = this.db.prepare('SELECT * FROM teams WHERE id = ?').get(teamId) as any;
    if (!team) return null;

    const oldRank = team.rank;
    const completedList: string[] = JSON.parse(team.completed_problem_ids || '[]');
    let solveCountDelta = 0;

    if (problemId && !completedList.includes(problemId)) {
      completedList.push(problemId);
      solveCountDelta = 1;
    }

    const newBase = team.base_score + deltaBase;
    const newStreak = team.streak_bonus + deltaStreak;
    const newSpeed = team.speed_bonus + deltaSpeed;
    const newTotal = newBase + newStreak + newSpeed;
    const newSolveCount = team.solve_count + solveCountDelta;

    this.db.prepare(`
      UPDATE teams
      SET base_score = ?,
          streak_bonus = ?,
          speed_bonus = ?,
          total_score = ?,
          solve_count = ?,
          completed_problem_ids = ?,
          previous_rank = rank
      WHERE id = ?
    `).run(newBase, newStreak, newSpeed, newTotal, newSolveCount, JSON.stringify(completedList), teamId);

    // Recompute ranks for all teams
    this.recomputeTeamRanks();

    return this.getTeamById(teamId);
  }

  createTeam(data: { name: string; tagline: string; avatar: string; batch: string; creatorUserId: string }): Team {
    const id = 'team-' + Math.random().toString(36).substring(2, 9);
    const joinCode = (data.name.substring(0, 3) + Math.floor(100 + Math.random() * 900)).toUpperCase();

    this.db.prepare(`
      INSERT INTO teams (id, name, tagline, avatar, join_code, batch, total_score, base_score, streak_bonus, speed_bonus, solve_count, rank, previous_rank, rank_change, completed_problem_ids)
      VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 999, 999, 0, '[]')
    `).run(id, data.name, data.tagline, data.avatar, joinCode, data.batch);

    // Assign creator to team as captain
    this.db.prepare(`
      UPDATE users SET team_id = ?, role = 'Captain' WHERE id = ?
    `).run(id, data.creatorUserId);

    this.recomputeTeamRanks();
    return this.getTeamById(id)!;
  }

  joinTeamByCode(joinCode: string, userId: string): Team | null {
    const team = this.db.prepare('SELECT id FROM teams WHERE UPPER(join_code) = UPPER(?)').get(joinCode) as any;
    if (!team) return null;

    // Check squad size limit (max 4 members)
    const count = (this.db.prepare('SELECT count(*) as count FROM users WHERE team_id = ?').get(team.id) as any).count;
    if (count >= 4) {
      throw new Error('Squad is already full (maximum 4 members reached).');
    }

    this.db.prepare(`
      UPDATE users SET team_id = ?, role = 'Member' WHERE id = ?
    `).run(team.id, userId);

    return this.getTeamById(team.id);
  }

  private recomputeTeamRanks() {
    const teams = this.db.prepare('SELECT id, total_score, rank FROM teams ORDER BY total_score DESC').all() as any[];
    const updateStmt = this.db.prepare('UPDATE teams SET rank = ?, rank_change = ? WHERE id = ?');

    teams.forEach((t, index) => {
      const newRank = index + 1;
      const change = (t.rank || newRank) - newRank;
      updateStmt.run(newRank, change, t.id);
    });
  }

  // USERS
  getUsers(): User[] {
    const rows = this.db.prepare('SELECT * FROM users').all() as any[];
    return rows.map(r => ({
      id: r.id,
      username: r.username,
      name: r.name,
      avatar: r.avatar,
      batch: r.batch,
      college: r.college,
      teamId: r.team_id,
      role: r.role,
      currentStreak: r.current_streak,
      maxStreak: r.max_streak,
      totalSolved: r.total_solved,
      score: r.score,
      activityHistory: JSON.parse(r.activity_history || '{}')
    }));
  }

  getUserById(id: string): User | null {
    const row = this.db.prepare('SELECT * FROM users WHERE id = ?').get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      username: row.username,
      name: row.name,
      avatar: row.avatar,
      batch: row.batch,
      college: row.college,
      teamId: row.team_id,
      role: row.role,
      currentStreak: row.current_streak,
      maxStreak: row.max_streak,
      totalSolved: row.total_solved,
      score: row.score,
      activityHistory: JSON.parse(row.activity_history || '{}')
    };
  }

  updateUserSolved(userId: string, points: number) {
    const user = this.getUserById(userId);
    if (!user) return null;

    const today = new Date().toISOString().split('T')[0];
    const activity = { ...user.activityHistory };
    activity[today] = (activity[today] || 0) + 1;

    const newCurrentStreak = user.currentStreak + 1;
    const newMaxStreak = Math.max(user.maxStreak, newCurrentStreak);
    const newTotalSolved = user.totalSolved + 1;
    const newScore = user.score + points;

    this.db.prepare(`
      UPDATE users
      SET current_streak = ?, max_streak = ?, total_solved = ?, score = ?, activity_history = ?
      WHERE id = ?
    `).run(newCurrentStreak, newMaxStreak, newTotalSolved, newScore, JSON.stringify(activity), userId);

    return this.getUserById(userId);
  }

  // SUBMISSIONS
  createSubmission(submission: Submission): Submission {
    this.db.prepare(`
      INSERT INTO submissions (
        id, problem_id, user_id, team_id, code, language, status,
        runtime_ms, memory_mb, passed_count, total_count, points_awarded,
        created_at, details
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      submission.id,
      submission.problemId,
      submission.userId,
      submission.teamId,
      submission.code,
      submission.language,
      submission.status,
      submission.runtimeMs,
      submission.memoryMb,
      submission.passedCount,
      submission.totalCount,
      submission.pointsAwarded,
      submission.createdAt,
      JSON.stringify(submission.details || [])
    );
    return submission;
  }

  getSubmissions(filter?: { problemId?: string; userId?: string; teamId?: string }): Submission[] {
    let query = 'SELECT * FROM submissions WHERE 1=1';
    const params: any[] = [];
    if (filter?.problemId) {
      query += ' AND problem_id = ?';
      params.push(filter.problemId);
    }
    if (filter?.userId) {
      query += ' AND user_id = ?';
      params.push(filter.userId);
    }
    if (filter?.teamId) {
      query += ' AND team_id = ?';
      params.push(filter.teamId);
    }
    query += ' ORDER BY created_at DESC LIMIT 50';

    const rows = this.db.prepare(query).all(...params) as any[];
    return rows.map(r => ({
      id: r.id,
      problemId: r.problem_id,
      userId: r.user_id,
      teamId: r.team_id,
      code: r.code,
      language: r.language,
      status: r.status,
      runtimeMs: r.runtime_ms,
      memoryMb: r.memory_mb,
      passedCount: r.passed_count,
      totalCount: r.total_count,
      pointsAwarded: r.points_awarded,
      createdAt: r.created_at,
      details: JSON.parse(r.details || '[]')
    }));
  }

  hasUserAcceptedProblem(userId: string, problemId: string): boolean {
    const row = this.db.prepare(
      "SELECT count(*) as count FROM submissions WHERE user_id = ? AND problem_id = ? AND status = 'Accepted'"
    ).get(userId, problemId) as any;
    return row && row.count > 0;
  }

  // DERBY WAR & EVENTS
  getDerbySession(): DerbySession | null {
    const row = this.db.prepare("SELECT * FROM derby_sessions WHERE status = 'active' LIMIT 1").get() as any;
    if (!row) return null;
    const events = this.getDerbyEvents(20);
    return {
      id: row.id,
      title: row.title,
      status: row.status,
      startTime: row.start_time,
      durationMinutes: row.duration_minutes,
      multiplier: row.multiplier,
      featuredProblemIds: JSON.parse(row.featured_problem_ids),
      events
    };
  }

  getDerbyEvents(limit = 20): DerbyWarEvent[] {
    const rows = this.db.prepare('SELECT * FROM derby_events ORDER BY timestamp DESC LIMIT ?').all(limit) as any[];
    return rows.map(r => ({
      id: r.id,
      timestamp: r.timestamp,
      teamId: r.team_id,
      teamName: r.team_name,
      userId: r.user_id,
      userName: r.user_name,
      userAvatar: r.user_avatar,
      problemId: r.problem_id,
      problemTitle: r.problem_title,
      points: r.points,
      message: r.message
    }));
  }

  addDerbyEvent(event: DerbyWarEvent) {
    this.db.prepare(`
      INSERT INTO derby_events (id, timestamp, team_id, team_name, user_id, user_name, user_avatar, problem_id, problem_title, points, message)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      event.id,
      event.timestamp,
      event.teamId,
      event.teamName,
      event.userId,
      event.userName,
      event.userAvatar,
      event.problemId,
      event.problemTitle,
      event.points,
      event.message
    );
  }

  // Reset demo back to baseline state if presenter wants to re-run
  resetDemoState() {
    this.db.exec(`
      DELETE FROM submissions WHERE user_id = 'user-alex' AND problem_id = 'prob-1';
      DELETE FROM derby_events WHERE id = 'evt-alex-climb';
    `);

    // Reset Binary Beasts
    this.db.prepare(`
      UPDATE teams
      SET total_score = 2520, base_score = 2250, streak_bonus = 270, speed_bonus = 0, solve_count = 50, rank = 3, previous_rank = 3, rank_change = 0,
          completed_problem_ids = '["prob-2","prob-3","prob-4","prob-5"]'
      WHERE id = 'team-binary-beasts'
    `).run();

    // Reset Alex Chen
    this.db.prepare(`
      UPDATE users
      SET current_streak = 7, total_solved = 19, score = 850
      WHERE id = 'user-alex'
    `).run();

    this.recomputeTeamRanks();
  }
}

export const db = new Database();
