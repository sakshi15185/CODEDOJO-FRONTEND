import React from 'react';
import {
  Code2,
  Trophy,
  Users,
  Flame,
  Swords,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  activeTab: 'daily' | 'problems' | 'leaderboard' | 'team' | 'derby' | 'plagiarism';
  setActiveTab: (tab: 'daily' | 'problems' | 'leaderboard' | 'team' | 'derby' | 'plagiarism') => void;
  currentUser: User | null;
  users: User[];
  onSelectUser: (user: User) => void;
  onResetDemo: () => void;
  isResetting: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  users,
  onSelectUser,
  onResetDemo,
  isResetting
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0d1117]/95 backdrop-blur border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('daily')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 p-0.5 shadow-lg shadow-amber-500/20">
              <div className="w-full h-full bg-[#0d1117] rounded-[10px] flex items-center justify-center">
                <Code2 className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-amber-400 via-orange-300 to-rose-400 bg-clip-text text-transparent">
                  CodeDojo Daily
                </span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  Derby 2.0
                </span>
              </div>
              <p className="text-[11px] text-gray-400 font-medium">Campus Placement Team Contest Arena</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('daily')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'daily'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Daily Challenge
            </button>

            <button
              onClick={() => setActiveTab('problems')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'problems'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-blue-400" />
              Problem Hub
            </button>

            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'leaderboard'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-yellow-400" />
              Leaderboard
            </button>

            <button
              onClick={() => setActiveTab('team')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'team'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-emerald-400" />
              Squad Roster
            </button>

            <button
              onClick={() => setActiveTab('derby')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all relative ${
                activeTab === 'derby'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <Swords className="w-3.5 h-3.5 text-rose-400" />
              Team War Sprint
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
            </button>

            <button
              onClick={() => setActiveTab('plagiarism')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'plagiarism'
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
              Plagiarism Check
            </button>
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-3">
            {/* Demo Reset Button */}
            <button
              onClick={onResetDemo}
              disabled={isResetting}
              title="Reset Demo (Sets Binary Beasts to 3rd place to replay climb)"
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white border border-gray-700 text-xs font-medium transition-colors"
            >
              <RotateCcw className={`w-3.5 h-3.5 text-amber-400 ${isResetting ? 'animate-spin' : ''}`} />
              Reset Demo
            </button>

            {/* Streak Counter */}
            {currentUser && (
              <div
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold shadow-sm"
                title={`${currentUser.currentStreak}-day coding streak!`}
              >
                <Flame className="w-4 h-4 text-orange-500 animate-pulse fill-orange-500" />
                <span>{currentUser.currentStreak}d Streak</span>
              </div>
            )}

            {/* User Switcher Dropdown */}
            <div className="flex items-center gap-2 pl-2 border-l border-gray-800">
              {currentUser && (
                <div className="flex items-center gap-2">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-8 h-8 rounded-full border-2 border-amber-500/60 object-cover"
                  />
                  <div className="hidden sm:block text-left">
                    <select
                      value={currentUser.id}
                      onChange={(e) => {
                        const u = users.find((user) => user.id === e.target.value);
                        if (u) onSelectUser(u);
                      }}
                      className="bg-transparent text-xs font-semibold text-gray-200 border-none outline-none cursor-pointer pr-1"
                    >
                      {users.map((u) => (
                        <option key={u.id} value={u.id} className="bg-[#161b22] text-gray-200">
                          {u.name} ({u.role})
                        </option>
                      ))}
                    </select>
                    <div className="text-[10px] text-gray-400 leading-none">
                      {currentUser.batch.split(' - ')[0]}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
