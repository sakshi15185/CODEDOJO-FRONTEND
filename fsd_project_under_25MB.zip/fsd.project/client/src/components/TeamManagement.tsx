import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Shield,
  Copy,
  Check,
  Flame,
  Award,
  Sparkles,
  PlusCircle,
  LogIn
} from 'lucide-react';
import { Team, User } from '../types';
import { api } from '../services/api';

interface TeamManagementProps {
  currentTeam: Team | null;
  currentUser: User | null;
  allTeams: Team[];
  onTeamUpdated: () => void;
}

const AVATAR_OPTIONS = ['🐺', '🥷', '🥊', '⚡', '🔮', '🚀', '🐉', '🦁', '🦉', '🤖'];

export const TeamManagement: React.FC<TeamManagementProps> = ({
  currentTeam,
  currentUser,
  allTeams,
  onTeamUpdated
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);

  // Create Squad Form
  const [squadName, setSquadName] = useState('');
  const [tagline, setTagline] = useState('');
  const [avatar, setAvatar] = useState('🐺');
  const [batch, setBatch] = useState('Batch 2026 - CSE');

  // Join Squad Form
  const [joinCode, setJoinCode] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCopyCode = () => {
    if (!currentTeam) return;
    navigator.clipboard.writeText(currentTeam.joinCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCreateSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !squadName.trim()) return;

    try {
      setIsSubmitting(true);
      setActionError(null);
      await api.createTeam({
        name: squadName.trim(),
        tagline: tagline.trim() || 'Code and Conquer together',
        avatar,
        batch,
        creatorUserId: currentUser.id
      });
      setShowCreateModal(false);
      onTeamUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to create squad');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleJoinSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !joinCode.trim()) return;

    try {
      setIsSubmitting(true);
      setActionError(null);
      await api.joinTeam(joinCode.trim(), currentUser.id);
      setShowJoinModal(false);
      onTeamUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to join squad. Verify code or squad capacity.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner: Squad Management & Actions */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-[#161b22] via-[#1a2332] to-[#161b22] border border-gray-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Peer Squad Roster & Formation
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-gray-400">
            Form 3-4 member student cohorts for collaborative daily streak habit building and contest scoring.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              setActionError(null);
              setShowJoinModal(true);
            }}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 flex items-center gap-1.5 transition-colors"
          >
            <LogIn className="w-3.5 h-3.5 text-blue-400" />
            Join with Code
          </button>

          <button
            onClick={() => {
              setActionError(null);
              setShowCreateModal(true);
            }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all transform hover:-translate-y-0.5"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Form New Squad
          </button>
        </div>
      </div>

      {/* Current User Squad Card */}
      {currentTeam ? (
        <div className="bg-[#161b22] rounded-2xl border border-gray-800 p-6 shadow-xl space-y-6">
          {/* Squad Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-800">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 flex items-center justify-center text-4xl shadow-inner">
                {currentTeam.avatar}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl sm:text-2xl font-extrabold text-white">{currentTeam.name}</h3>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Rank #{currentTeam.rank}
                  </span>
                </div>
                <p className="text-xs text-gray-400 italic mt-0.5">{currentTeam.tagline}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs px-2.5 py-0.5 rounded bg-gray-800 text-gray-300 border border-gray-700">
                    {currentTeam.batch}
                  </span>
                  <span className="text-xs text-gray-400">
                    Capacity: {currentTeam.members.length}/4 Members
                  </span>
                </div>
              </div>
            </div>

            {/* Squad Join Code Card */}
            <div className="p-3.5 rounded-xl bg-[#0d1117] border border-gray-800 flex items-center justify-between gap-4">
              <div>
                <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">
                  Squad Invite Code
                </div>
                <div className="font-mono text-base font-extrabold text-amber-400 tracking-wider">
                  {currentTeam.joinCode}
                </div>
              </div>
              <button
                onClick={handleCopyCode}
                className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white transition-colors"
                title="Copy squad invite code"
              >
                {copiedCode ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          {/* Member Roster List */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              Cohort Members ({currentTeam.members.length}/4)
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {currentTeam.members.map(member => (
                <div
                  key={member.id}
                  className={`p-4 rounded-xl border transition-all ${
                    member.id === currentUser?.id
                      ? 'bg-amber-500/5 border-amber-500/30 ring-1 ring-amber-500/20'
                      : 'bg-[#0d1117] border-gray-800 hover:border-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-10 h-10 rounded-full border-2 border-gray-700 object-cover"
                    />
                    <div>
                      <div className="font-bold text-sm text-gray-100 flex items-center gap-1">
                        <span>{member.name}</span>
                        {member.role === 'Captain' && (
                          <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                            CAPTAIN
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400">@{member.username}</div>
                    </div>
                  </div>

                  {/* Member Stats */}
                  <div className="space-y-1.5 pt-2 border-t border-gray-800 text-xs">
                    <div className="flex items-center justify-between text-gray-400">
                      <span>Challenges Solved:</span>
                      <span className="font-mono font-bold text-gray-200">{member.totalSolved}</span>
                    </div>
                    <div className="flex items-center justify-between text-gray-400">
                      <span>Streak:</span>
                      <span className="font-mono font-bold text-orange-400 flex items-center gap-1">
                        <Flame className="w-3 h-3 fill-orange-500" />
                        {member.currentStreak} Days
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-gray-400">
                      <span>Contribution:</span>
                      <span className="font-mono font-bold text-amber-300">+{member.score} pts</span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Empty slot placeholder if < 4 members */}
              {Array.from({ length: 4 - currentTeam.members.length }).map((_, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-dashed border-gray-800 bg-[#0d1117]/40 flex flex-col items-center justify-center text-center text-gray-500 text-xs space-y-1 min-h-[140px]"
                >
                  <UserPlus className="w-6 h-6 text-gray-600 mb-1" />
                  <span className="font-medium">Open Squad Slot</span>
                  <span className="text-[10px] text-gray-600">Share code: {currentTeam.joinCode}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 rounded-2xl bg-[#161b22] border border-gray-800 text-center space-y-3">
          <Users className="w-10 h-10 text-gray-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">You are not in a squad yet</h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            Form a 3-4 member peer squad or join an existing cohort squad using an invite code to earn team points!
          </p>
        </div>
      )}

      {/* Modal: Form New Squad */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-[#161b22] border border-gray-700 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">Create New Peer Squad</h3>
            <p className="text-xs text-gray-400">
              Set up your cohort team (3-4 members limit). You will be assigned as the Squad Captain.
            </p>

            {actionError && (
              <div className="p-2.5 rounded bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {actionError}
              </div>
            )}

            <form onSubmit={handleCreateSquad} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Squad Name</label>
                <input
                  type="text"
                  required
                  value={squadName}
                  onChange={e => setSquadName(e.target.value)}
                  placeholder="e.g. Binary Beasts, AlgoNinjas"
                  className="w-full bg-[#0d1117] text-white border border-gray-700 rounded-lg p-2.5 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Squad Tagline</label>
                <input
                  type="text"
                  value={tagline}
                  onChange={e => setTagline(e.target.value)}
                  placeholder="e.g. Zeroes and ones bow before us"
                  className="w-full bg-[#0d1117] text-white border border-gray-700 rounded-lg p-2.5 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Squad Avatar</label>
                <div className="flex flex-wrap gap-2">
                  {AVATAR_OPTIONS.map(opt => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setAvatar(opt)}
                      className={`w-9 h-9 text-lg rounded-lg border flex items-center justify-center transition-all ${
                        avatar === opt
                          ? 'border-amber-400 bg-amber-500/20 shadow-sm'
                          : 'border-gray-700 bg-[#0d1117] hover:border-gray-600'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Cohort Batch</label>
                <input
                  type="text"
                  value={batch}
                  onChange={e => setBatch(e.target.value)}
                  className="w-full bg-[#0d1117] text-white border border-gray-700 rounded-lg p-2.5 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3.5 py-2 rounded-lg bg-gray-800 text-gray-300 hover:text-white font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-gray-950 font-bold"
                >
                  {isSubmitting ? 'Creating...' : 'Create Squad'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Join Squad with Code */}
      {showJoinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-[#161b22] border border-gray-700 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">Join Peer Squad</h3>
            <p className="text-xs text-gray-400">
              Enter the 6-character squad invite code provided by your squad captain.
            </p>

            {actionError && (
              <div className="p-2.5 rounded bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {actionError}
              </div>
            )}

            <form onSubmit={handleJoinSquad} className="space-y-4 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Squad Join Code</label>
                <input
                  type="text"
                  required
                  value={joinCode}
                  onChange={e => setJoinCode(e.target.value.toUpperCase())}
                  placeholder="e.g. BEAST7, NINJA9"
                  maxLength={10}
                  className="w-full bg-[#0d1117] text-amber-400 font-mono font-bold tracking-wider text-center text-lg border border-gray-700 rounded-lg p-2.5 focus:border-amber-500 focus:outline-none uppercase"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowJoinModal(false)}
                  className="px-3.5 py-2 rounded-lg bg-gray-800 text-gray-300 hover:text-white font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-bold"
                >
                  {isSubmitting ? 'Joining...' : 'Join Squad'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
