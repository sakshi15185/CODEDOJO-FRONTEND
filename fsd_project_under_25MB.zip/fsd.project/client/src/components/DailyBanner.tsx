import React, { useState, useEffect } from 'react';
import { Sparkles, Clock, ArrowRight, Award, Zap } from 'lucide-react';
import { Problem, User } from '../types';

interface DailyBannerProps {
  dailyProblem: Problem | null;
  currentUser: User | null;
  onSolveClick: (problem: Problem) => void;
}

export const DailyBanner: React.FC<DailyBannerProps> = ({
  dailyProblem,
  currentUser,
  onSolveClick
}) => {
  // 24-hr countdown timer simulation
  const [timeLeft, setTimeLeft] = useState({ hours: 11, minutes: 42, seconds: 18 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!dailyProblem) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#161b22] via-[#1a2332] to-[#161b22] border border-amber-500/30 p-6 md:p-8 shadow-2xl mb-8">
      {/* Ambient background glow */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="max-w-3xl">
          {/* Header pill badges */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Daily Challenge • Today
            </span>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              +{dailyProblem.points} Squad Points
            </span>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-gray-800 text-gray-300 border border-gray-700">
              <Clock className="w-3.5 h-3.5 text-gray-400" />
              Expires in {String(timeLeft.hours).padStart(2, '0')}:{String(timeLeft.minutes).padStart(2, '0')}:
              {String(timeLeft.seconds).padStart(2, '0')}
            </span>
          </div>

          {/* Problem Title */}
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
            {dailyProblem.title}
          </h2>

          <p className="text-gray-300 text-sm leading-relaxed mb-4 line-clamp-2">
            {dailyProblem.description.split('\n')[0]}
          </p>

          {/* Tags & Placement Note */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                dailyProblem.difficulty === 'Easy'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : dailyProblem.difficulty === 'Medium'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
              }`}
            >
              {dailyProblem.difficulty}
            </span>

            {dailyProblem.tags.map(t => (
              <span
                key={t}
                className="text-xs px-2.5 py-0.5 rounded-full bg-gray-800/80 text-gray-300 border border-gray-700 font-medium"
              >
                #{t}
              </span>
            ))}

            <span className="text-xs text-amber-300/80 italic hidden sm:inline ml-2">
              💡 Top Placement Pattern for Campus Coding Rounds
            </span>
          </div>
        </div>

        {/* Action Button & Squad Impact */}
        <div className="w-full lg:w-auto flex flex-col sm:flex-row lg:flex-col items-center gap-3 shrink-0">
          <button
            onClick={() => onSolveClick(dailyProblem)}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:from-amber-400 hover:via-orange-400 hover:to-rose-400 text-white shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            Solve Today's Challenge
            <ArrowRight className="w-4 h-4" />
          </button>

          {currentUser?.teamId && (
            <div className="text-[11px] text-gray-400 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Solves boost your squad's leaderboard score!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
