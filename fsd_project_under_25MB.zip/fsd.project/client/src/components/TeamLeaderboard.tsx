import React from 'react';
import {
  Trophy,
  Flame,
  Zap,
  TrendingUp,
  TrendingDown,
  Minus,
  Users,
  Award,
  Clock,
  Sparkles
} from 'lucide-react';
import { Team, User } from '../types';

interface TeamLeaderboardProps {
  teams: Team[];
  currentUser: User | null;
  onSelectTeam?: (team: Team) => void;
  lastUpdated?: Date;
}

export const TeamLeaderboard: React.FC<TeamLeaderboardProps> = ({
  teams,
  currentUser,
  onSelectTeam,
  lastUpdated
}) => {
  return (
    <div className="space-y-6">
      {/* Leaderboard Header with Formula Explainer Card */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#161b22] via-[#1c2433] to-[#161b22] border border-gray-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Squad Contest Leaderboard
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-gray-400">
            Real-time aggregate scoring across college squads. Auto-synced via lightweight polling.
          </p>
        </div>

        {/* Scoring formula card */}
        <div className="p-3 rounded-xl bg-[#0d1117]/80 border border-amber-500/30 text-xs">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold mb-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Scoring Formula
          </div>
          <div className="font-mono text-gray-300 text-[11px]">
            TeamScore = <span className="text-blue-300">Σ(MemberScores)</span> +{' '}
            <span className="text-orange-400">StreakBonus</span> +{' '}
            <span className="text-emerald-400">SpeedBonus</span>
          </div>
          <div className="text-[10px] text-gray-500 mt-1 flex items-center justify-between">
            <span>Only 1st accepted solve awards points</span>
            {lastUpdated && <span>Synced {lastUpdated.toLocaleTimeString()}</span>}
          </div>
        </div>
      </div>

      {/* Leaderboard Ranks Table */}
      <div className="bg-[#161b22] rounded-xl border border-gray-800 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-[#0d1117] text-gray-400 text-[11px] uppercase tracking-wider border-b border-gray-800">
              <tr>
                <th className="py-3.5 px-4 w-16 text-center">Rank</th>
                <th className="py-3.5 px-4 w-20 text-center">Change</th>
                <th className="py-3.5 px-4">Squad Name</th>
                <th className="py-3.5 px-4">Cohort Batch</th>
                <th className="py-3.5 px-4">Roster</th>
                <th className="py-3.5 px-4 text-center">Solves</th>
                <th className="py-3.5 px-4 text-right">Base</th>
                <th className="py-3.5 px-4 text-right">Streak</th>
                <th className="py-3.5 px-4 text-right">Speed</th>
                <th className="py-3.5 px-4 text-right">Total Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {teams.map((team, idx) => {
                const isUserSquad = currentUser?.teamId === team.id;
                const isFirst = idx === 0;
                const isSecond = idx === 1;
                const isThird = idx === 2;

                return (
                  <tr
                    key={team.id}
                    className={`transition-all duration-300 ${
                      isUserSquad
                        ? 'bg-amber-500/10 hover:bg-amber-500/15 border-l-4 border-l-amber-500'
                        : 'hover:bg-gray-800/40'
                    }`}
                  >
                    {/* Rank with Podium Medals */}
                    <td className="py-4 px-4 text-center font-bold">
                      {isFirst ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-sm shadow-md">
                          🥇
                        </span>
                      ) : isSecond ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-slate-300/20 text-slate-200 border border-slate-400/40 text-sm shadow-md">
                          🥈
                        </span>
                      ) : isThird ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-700/20 text-amber-500 border border-amber-700/40 text-sm shadow-md">
                          🥉
                        </span>
                      ) : (
                        <span className="text-gray-400 font-mono text-sm">#{idx + 1}</span>
                      )}
                    </td>

                    {/* Rank Change Indicator */}
                    <td className="py-4 px-4 text-center font-bold text-xs">
                      {team.rankChange > 0 ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse font-mono">
                          <TrendingUp className="w-3 h-3" />+{team.rankChange}
                        </span>
                      ) : team.rankChange < 0 ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 font-mono">
                          <TrendingDown className="w-3 h-3" />
                          {team.rankChange}
                        </span>
                      ) : (
                        <span className="text-gray-600 font-mono flex items-center justify-center">
                          <Minus className="w-3 h-3" />
                        </span>
                      )}
                    </td>

                    {/* Squad Info */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{team.avatar}</span>
                        <div>
                          <div className="font-extrabold text-white flex items-center gap-1.5">
                            <span>{team.name}</span>
                            {isUserSquad && (
                              <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                Your Squad
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-gray-400 line-clamp-1 italic">{team.tagline}</p>
                        </div>
                      </div>
                    </td>

                    {/* Cohort Batch */}
                    <td className="py-4 px-4 text-gray-300 text-xs font-medium">
                      <span className="px-2 py-0.5 rounded bg-gray-800 text-gray-300 border border-gray-700">
                        {team.batch}
                      </span>
                    </td>

                    {/* Roster Avatars */}
                    <td className="py-4 px-4">
                      <div className="flex items-center -space-x-2 overflow-hidden">
                        {team.members.map(m => (
                          <img
                            key={m.id}
                            src={m.avatar}
                            alt={m.name}
                            title={`${m.name} (${m.role}) - ${m.score} pts`}
                            className="inline-block w-6 h-6 rounded-full ring-2 ring-[#161b22] object-cover"
                          />
                        ))}
                      </div>
                    </td>

                    {/* Solves Count */}
                    <td className="py-4 px-4 text-center font-mono font-semibold text-gray-200">
                      {team.solveCount}
                    </td>

                    {/* Base Score */}
                    <td className="py-4 px-4 text-right font-mono text-gray-400 text-xs">
                      {team.baseScore}
                    </td>

                    {/* Streak Bonus */}
                    <td className="py-4 px-4 text-right font-mono text-orange-400 text-xs font-semibold">
                      +{team.streakBonus}
                    </td>

                    {/* Speed Bonus */}
                    <td className="py-4 px-4 text-right font-mono text-emerald-400 text-xs font-semibold">
                      +{team.speedBonus}
                    </td>

                    {/* Total Score */}
                    <td className="py-4 px-4 text-right font-mono font-extrabold text-sm sm:text-base">
                      <span className="bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
                        {team.totalScore}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
