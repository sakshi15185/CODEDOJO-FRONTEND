import React from 'react';
import { Flame, Calendar, Award, CheckCircle, Zap } from 'lucide-react';
import { User } from '../types';

interface StreakCalendarProps {
  user: User;
}

export const StreakCalendar: React.FC<StreakCalendarProps> = ({ user }) => {
  // Generate last 20 weeks of dates for the GitHub-style contribution heatmap
  const weeks = 20;
  const daysPerWeek = 7;
  const totalDays = weeks * daysPerWeek;

  const today = new Date();
  const dateSquares = Array.from({ length: totalDays }).map((_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (totalDays - 1 - i));
    const dateStr = d.toISOString().split('T')[0];
    const count = user.activityHistory[dateStr] || 0;
    return {
      date: dateStr,
      count,
      dayOfWeek: d.getDay(),
      formatted: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    };
  });

  return (
    <div className="bg-[#161b22] rounded-2xl border border-gray-800 p-6 shadow-xl space-y-6">
      {/* Header and User Consistency Stats */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-gray-800">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white">Daily Coding Consistency Heatmap</h3>
          </div>
          <p className="text-xs text-gray-400">
            GitHub-style activity record tracking placement prep habit and submission streaks.
          </p>
        </div>

        {/* Consistency Stat Badges */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2.5 rounded-xl bg-[#0d1117] border border-gray-800 text-center min-w-20">
            <div className="text-[10px] text-gray-500 uppercase flex items-center justify-center gap-1 font-sans">
              <Flame className="w-3 h-3 text-orange-500 fill-orange-500" />
              Streak
            </div>
            <div className="font-extrabold text-orange-400 text-sm mt-0.5">{user.currentStreak} Days</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0d1117] border border-gray-800 text-center min-w-20">
            <div className="text-[10px] text-gray-500 uppercase flex items-center justify-center gap-1 font-sans">
              <Zap className="w-3 h-3 text-amber-400" />
              Max Streak
            </div>
            <div className="font-extrabold text-amber-300 text-sm mt-0.5">{user.maxStreak} Days</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0d1117] border border-gray-800 text-center min-w-20">
            <div className="text-[10px] text-gray-500 uppercase flex items-center justify-center gap-1 font-sans">
              <CheckCircle className="w-3 h-3 text-emerald-400" />
              Solved
            </div>
            <div className="font-extrabold text-emerald-400 text-sm mt-0.5">{user.totalSolved}</div>
          </div>
        </div>
      </div>

      {/* GitHub-style Heatmap Grid */}
      <div className="overflow-x-auto pb-2">
        <div className="min-w-[640px] space-y-2">
          <div className="flex gap-1.5">
            {Array.from({ length: weeks }).map((_, weekIdx) => {
              const weekDays = dateSquares.slice(weekIdx * 7, (weekIdx + 1) * 7);
              return (
                <div key={weekIdx} className="flex flex-col gap-1.5">
                  {weekDays.map(day => {
                    let bg = 'bg-[#0d1117] border-gray-800/80';
                    if (day.count === 1) bg = 'bg-emerald-950 border-emerald-800/50';
                    else if (day.count === 2) bg = 'bg-emerald-800/70 border-emerald-600/50';
                    else if (day.count >= 3) bg = 'bg-emerald-500 border-emerald-400 shadow-sm shadow-emerald-500/20';

                    return (
                      <div
                        key={day.date}
                        title={`${day.formatted}: ${day.count} problem${day.count === 1 ? '' : 's'} solved`}
                        className={`w-3.5 h-3.5 rounded-sm border ${bg} transition-colors hover:scale-125 cursor-pointer`}
                      />
                    );
                  })}
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-between text-[11px] text-gray-500 pt-2 font-mono">
            <span>20 Weeks Coding History</span>
            <div className="flex items-center gap-1.5 font-sans">
              <span>Less</span>
              <div className="w-2.5 h-2.5 rounded-sm bg-[#0d1117] border border-gray-800" />
              <div className="w-2.5 h-2.5 rounded-sm bg-emerald-950 border border-emerald-800/50" />
              <div className="w-2.5 h-2.5 rounded-sm bg-emerald-800/70 border border-emerald-600/50" />
              <div className="w-2.5 h-2.5 rounded-sm bg-emerald-500 border border-emerald-400" />
              <span>More</span>
            </div>
          </div>
        </div>
      </div>

      {/* Placement Habit Milestone Callout */}
      <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border border-amber-500/20 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-amber-200">
          <Award className="w-4 h-4 text-amber-400" />
          <span>
            <strong>Consistency Milestone Unlocked:</strong> {user.currentStreak}-Day Streak placing you in the top 5% of {user.batch}!
          </span>
        </div>
        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
          Placement Ready
        </span>
      </div>
    </div>
  );
};
