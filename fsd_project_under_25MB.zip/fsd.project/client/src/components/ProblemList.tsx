import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  Circle,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Tag
} from 'lucide-react';
import { Problem } from '../types';

interface ProblemListProps {
  problems: Problem[];
  onSelectProblem: (problem: Problem) => void;
  userSolvedProblemIds?: string[];
}

const DOMAINS = [
  'All',
  'Arrays & Hash Maps',
  'Two Pointers',
  'Sliding Window',
  'Dynamic Programming',
  'Greedy',
  'Monotonic Stack',
  'Graph & Matrix',
  'Binary Search',
  'Trees & BFS'
];

export const ProblemList: React.FC<ProblemListProps> = ({
  problems,
  onSelectProblem,
  userSolvedProblemIds = []
}) => {
  const [search, setSearch] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedDomain, setSelectedDomain] = useState<string>('All');

  // Filtered problems
  const filteredProblems = useMemo(() => {
    return problems.filter(p => {
      // Search
      const matchesSearch =
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.tags.some(t => t.toLowerCase().includes(search.toLowerCase())) ||
        p.category.toLowerCase().includes(search.toLowerCase());

      // Difficulty
      const matchesDiff =
        selectedDifficulty === 'All' || p.difficulty.toLowerCase() === selectedDifficulty.toLowerCase();

      // Domain
      const matchesDomain =
        selectedDomain === 'All' || p.category.toLowerCase().includes(selectedDomain.toLowerCase());

      return matchesSearch && matchesDiff && matchesDomain;
    });
  }, [problems, search, selectedDifficulty, selectedDomain]);

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Placement Problem Repository</span>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30">
              {filteredProblems.length} Challenges
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-400">
            Curated high-frequency campus placement coding challenges with automated test suite evaluation.
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search problems, patterns, tags..."
            className="w-full bg-[#161b22] text-gray-200 border border-gray-700 rounded-xl pl-9 pr-4 py-2 text-xs focus:border-amber-500 focus:outline-none placeholder-gray-500"
          />
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#161b22]/70 border border-gray-800">
        {/* Difficulty Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <span className="text-xs font-medium text-gray-400 flex items-center gap-1 mr-1">
            <Filter className="w-3 h-3" />
            Tier:
          </span>
          {['All', 'Easy', 'Medium', 'Hard'].map(d => (
            <button
              key={d}
              onClick={() => setSelectedDifficulty(d)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                selectedDifficulty === d
                  ? 'bg-amber-500 text-gray-950 font-bold shadow-sm'
                  : 'bg-gray-800/80 text-gray-300 hover:bg-gray-800'
              }`}
            >
              {d}
            </button>
          ))}
        </div>

        {/* Domain Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <span className="text-xs font-medium text-gray-400 flex items-center gap-1 mr-1">
            <Tag className="w-3 h-3" />
            Domain:
          </span>
          <select
            value={selectedDomain}
            onChange={e => setSelectedDomain(e.target.value)}
            className="bg-[#0d1117] text-gray-300 border border-gray-700 rounded-lg px-2.5 py-1 text-xs focus:border-amber-500 focus:outline-none"
          >
            {DOMAINS.map(dom => (
              <option key={dom} value={dom}>
                {dom}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Problem Cards Table */}
      <div className="bg-[#161b22] rounded-xl border border-gray-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-[#0d1117]/80 text-gray-400 text-[11px] uppercase tracking-wider border-b border-gray-800">
              <tr>
                <th className="py-3 px-4 w-12 text-center">Status</th>
                <th className="py-3 px-4">Problem Name</th>
                <th className="py-3 px-4">Category & Tags</th>
                <th className="py-3 px-4 text-center">Difficulty</th>
                <th className="py-3 px-4 text-center">Acceptance</th>
                <th className="py-3 px-4 text-right">Points</th>
                <th className="py-3 px-4 text-center w-28">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filteredProblems.map(p => {
                const isSolved = userSolvedProblemIds.includes(p.id);
                return (
                  <tr
                    key={p.id}
                    className="hover:bg-gray-800/40 transition-colors cursor-pointer group"
                    onClick={() => onSelectProblem(p)}
                  >
                    <td className="py-3.5 px-4 text-center">
                      {isSolved ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 inline" />
                      ) : (
                        <Circle className="w-4 h-4 text-gray-600 inline" />
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-gray-100 group-hover:text-amber-300 transition-colors">
                      <div className="flex items-center gap-2">
                        <span>{p.title}</span>
                        {p.isDaily && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            <Sparkles className="w-2.5 h-2.5" />
                            Daily
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1.5">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
                          {p.category}
                        </span>
                        {p.tags.slice(0, 2).map(tag => (
                          <span
                            key={tag}
                            className="text-[10px] px-2 py-0.5 rounded bg-gray-800 text-gray-400 border border-gray-700 hidden sm:inline"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                          p.difficulty === 'Easy'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : p.difficulty === 'Medium'
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                        }`}
                      >
                        {p.difficulty}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-xs text-gray-400">
                      {p.acceptanceRate}%
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-amber-400">
                      +{p.points}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          onSelectProblem(p);
                        }}
                        className="px-3 py-1 rounded-lg text-xs font-semibold bg-gray-800 hover:bg-amber-500 hover:text-gray-950 text-gray-200 border border-gray-700 transition-all flex items-center justify-center gap-1 mx-auto"
                      >
                        Solve
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
