import React, { useState, useEffect } from 'react';
import {
  Swords,
  Clock,
  Zap,
  Flame,
  Trophy,
  Activity,
  ArrowRight,
  Shield,
  Sparkles
} from 'lucide-react';
import { DerbySession, DerbyWarEvent, Team, Problem } from '../types';
import { api } from '../services/api';

interface TeamWarArenaProps {
  teams: Team[];
  problems: Problem[];
  onSelectProblem: (problem: Problem) => void;
}

export const TeamWarArena: React.FC<TeamWarArenaProps> = ({
  teams,
  problems,
  onSelectProblem
}) => {
  const [session, setSession] = useState<DerbySession | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState(41 * 60 + 24); // 41 mins remaining

  // Poll derby state
  useEffect(() => {
    const loadSession = async () => {
      try {
        const s = await api.getDerbySession();
        setSession(s);
      } catch (err) {
        console.error('Failed to load derby session', err);
      }
    };
    loadSession();
    const interval = setInterval(loadSession, 4000);
    return () => clearInterval(interval);
  }, []);

  // Countdown clock tick
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining(prev => (prev > 0 ? prev - 1 : 60 * 60));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const featuredProblems = problems.filter(p => session?.featuredProblemIds.includes(p.id));

  return (
    <div className="space-y-8">
      {/* Giant War Arena Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-rose-950/40 via-[#161b22] to-amber-950/30 border border-rose-500/40 p-6 sm:p-8 shadow-2xl">
        {/* Glows */}
        <div className="absolute top-0 right-1/4 w-72 h-72 bg-rose-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40">
                <Swords className="w-3.5 h-3.5 text-rose-400" />
                Live Weekend Sprint War
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                <Zap className="w-3 h-3 text-amber-400" />
                1.5x Point Multiplier Active
              </span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {session?.title || 'Campus Clash: Weekend Speed Sprint #4'}
            </h2>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl">
              Synchronized 60-minute cohort sprint! All accepted submissions during the war receive a 1.5x multiplier
              and first-blood bonus points for your squad.
            </p>
          </div>

          {/* Synchronized War Countdown Timer Clock */}
          <div className="flex flex-col items-center justify-center p-4 sm:p-5 rounded-2xl bg-[#0d1117]/90 border border-rose-500/40 shadow-xl shrink-0">
            <div className="text-[10px] uppercase font-bold tracking-wider text-rose-400 flex items-center gap-1 mb-1">
              <Clock className="w-3 h-3 animate-spin" />
              Sprint War Clock
            </div>
            <div className="font-mono text-3xl sm:text-5xl font-black text-white tracking-widest text-shadow">
              {formatTime(secondsRemaining)}
            </div>
            <div className="text-[10px] text-gray-400 mt-1">Remaining in Round</div>
          </div>
        </div>
      </div>

      {/* Arena Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Event Ticker Feed */}
        <div className="lg:col-span-7 bg-[#161b22] rounded-2xl border border-gray-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-800">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400" />
              <h3 className="font-bold text-white text-sm">Live Squad Battle Activity Ticker</h3>
            </div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              LIVE STREAM
            </span>
          </div>

          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {session?.events && session.events.length > 0 ? (
              session.events.map(evt => (
                <div
                  key={evt.id}
                  className="p-3 rounded-xl bg-[#0d1117] border border-gray-800/80 hover:border-gray-700 transition-all flex items-start gap-3"
                >
                  <img
                    src={evt.userAvatar}
                    alt={evt.userName}
                    className="w-9 h-9 rounded-full border border-gray-700 object-cover mt-0.5"
                  />
                  <div className="flex-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-100 flex items-center gap-1.5">
                        <span>{evt.userName}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-amber-300 border border-gray-700">
                          {evt.teamName}
                        </span>
                      </span>
                      <span className="font-mono text-[10px] text-gray-500">
                        {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-gray-300 mt-1">{evt.message}</p>
                    <div className="mt-1 flex items-center gap-2 text-[11px] font-semibold text-emerald-400 font-mono">
                      <span>+{evt.points} Points</span>
                      <span className="text-gray-500">•</span>
                      <span className="text-gray-400">{evt.problemTitle}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500 text-xs">Awaiting live battle submissions...</div>
            )}
          </div>
        </div>

        {/* Right Column: Featured Sprint Challenges & Squad Progress */}
        <div className="lg:col-span-5 space-y-6">
          {/* Featured Sprint Challenges */}
          <div className="bg-[#161b22] rounded-2xl border border-gray-800 p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-white text-sm">Sprint Challenges Queue</h3>
              </div>
              <span className="text-[10px] text-gray-400 font-mono">1.5x Multiplier</span>
            </div>

            <div className="space-y-2.5">
              {featuredProblems.map(p => (
                <div
                  key={p.id}
                  onClick={() => onSelectProblem(p)}
                  className="p-3 rounded-xl bg-[#0d1117] border border-gray-800 hover:border-amber-500/40 transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div>
                    <div className="font-bold text-xs text-gray-200 group-hover:text-amber-300 transition-colors flex items-center gap-2">
                      <span>{p.title}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded border ${
                          p.difficulty === 'Easy'
                            ? 'text-emerald-400 border-emerald-500/30'
                            : p.difficulty === 'Medium'
                            ? 'text-amber-400 border-amber-500/30'
                            : 'text-rose-400 border-rose-500/30'
                        }`}
                      >
                        {p.difficulty}
                      </span>
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">{p.category}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-amber-400">
                      +{Math.round(p.points * 1.5)} pts
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-gray-500 group-hover:text-amber-300 transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Squad Live Sprint Progress Bar */}
          <div className="bg-[#161b22] rounded-2xl border border-gray-800 p-5 shadow-xl space-y-3">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              Live Sprint Leaderboard
            </h3>

            <div className="space-y-2.5">
              {teams.slice(0, 4).map((t, idx) => {
                const maxScore = teams[0]?.totalScore || 3000;
                const pct = Math.min(100, Math.round((t.totalScore / maxScore) * 100));

                return (
                  <div key={t.id} className="space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-gray-200">
                        <span>{t.avatar}</span>
                        <span>{t.name}</span>
                        <span className="text-[10px] text-gray-500">#{idx + 1}</span>
                      </div>
                      <span className="font-mono font-bold text-amber-400">{t.totalScore} pts</span>
                    </div>
                    <div className="w-full bg-[#0d1117] h-2 rounded-full overflow-hidden border border-gray-800">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          idx === 0
                            ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                            : idx === 1
                            ? 'bg-gradient-to-r from-blue-500 to-indigo-500'
                            : 'bg-gradient-to-r from-emerald-500 to-teal-500'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
