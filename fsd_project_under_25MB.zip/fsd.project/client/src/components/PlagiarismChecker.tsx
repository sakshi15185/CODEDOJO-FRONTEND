import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Cpu,
  ArrowRightLeft,
  FileCode,
  AlertTriangle,
  Play
} from 'lucide-react';
import { PlagiarismComparisonResult } from '../types';
import { api } from '../services/api';

const PRESET_COPIED = {
  name: 'Suspected Plagiarism (Variable Renamed Copy)',
  code1: `function twoSumVariant(nums, target) {
  const map = new Map();
  let bestPair = null;
  let minDiff = Infinity;

  for (let j = 0; j < nums.length; j++) {
    const complement = target - nums[j];
    if (map.has(complement)) {
      const i = map.get(complement);
      const diff = Math.abs(nums[i] - nums[j]);
      if (diff < minDiff) {
        minDiff = diff;
        bestPair = [Math.min(i, j), Math.max(i, j)];
      }
    }
    if (!map.has(nums[j])) {
      map.set(nums[j], j);
    }
  }

  return bestPair || [];
}`,
  code2: `function twoSumVariant(arr, k) {
  const lookup = new Map();
  let resultPair = null;
  let leastDiff = Infinity;

  for (let idx = 0; idx < arr.length; idx++) {
    const remaining = k - arr[idx];
    if (lookup.has(remaining)) {
      const firstIdx = lookup.get(remaining);
      const gap = Math.abs(arr[firstIdx] - arr[idx]);
      if (gap < leastDiff) {
        leastDiff = gap;
        resultPair = [Math.min(firstIdx, idx), Math.max(firstIdx, idx)];
      }
    }
    if (!lookup.has(arr[idx])) {
      lookup.set(arr[idx], idx);
    }
  }

  return resultPair || [];
}`
};

const PRESET_DISTINCT = {
  name: 'Independent Implementations (Hash Map vs Two Pointers)',
  code1: `function twoSumVariant(nums, target) {
  const map = new Map();
  let best = null, minDiff = Infinity;
  for (let j = 0; j < nums.length; j++) {
    const comp = target - nums[j];
    if (map.has(comp)) {
      const i = map.get(comp);
      const diff = Math.abs(nums[i] - nums[j]);
      if (diff < minDiff) {
        minDiff = diff;
        best = [i, j];
      }
    }
    if (!map.has(nums[j])) map.set(nums[j], j);
  }
  return best || [];
}`,
  code2: `function twoSumVariant(nums, target) {
  // Brute force alternative implementation
  let ans = [];
  let minGap = Infinity;
  for (let i = 0; i < nums.length; i++) {
    for (let j = i + 1; j < nums.length; j++) {
      if (nums[i] + nums[j] === target) {
        const gap = Math.abs(nums[i] - nums[j]);
        if (gap < minGap) {
          minGap = gap;
          ans = [i, j];
        }
      }
    }
  }
  return ans;
}`
};

export const PlagiarismChecker: React.FC = () => {
  const [code1, setCode1] = useState(PRESET_COPIED.code1);
  const [code2, setCode2] = useState(PRESET_COPIED.code2);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<PlagiarismComparisonResult | null>(null);

  const handleRunComparison = async (c1 = code1, c2 = code2) => {
    try {
      setIsAnalyzing(true);
      const analysis = await api.comparePlagiarism(c1, c2);
      setResult(analysis);
    } catch (err) {
      console.error('Plagiarism check failed', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadPreset = (preset: typeof PRESET_COPIED) => {
    setCode1(preset.code1);
    setCode2(preset.code2);
    handleRunComparison(preset.code1, preset.code2);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-[#161b22] via-[#231b2e] to-[#161b22] border border-purple-500/30">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldAlert className="w-5 h-5 text-purple-400" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Code Plagiarism Similarity Checker
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-gray-400">
            Calculates normalized Levenshtein edit distance and structural token Jaccard similarity across submissions.
          </p>
        </div>

        {/* Demo Presets */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => loadPreset(PRESET_COPIED)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 transition-colors"
          >
            Demo Copied Pair
          </button>
          <button
            onClick={() => loadPreset(PRESET_DISTINCT)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 transition-colors"
          >
            Demo Distinct Pair
          </button>
        </div>
      </div>

      {/* Analysis Verdict Result Card */}
      {result && (
        <div
          className={`p-5 rounded-2xl border transition-all ${
            result.isFlagged
              ? 'bg-rose-950/20 border-rose-500/40'
              : 'bg-emerald-950/20 border-emerald-500/40'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-gray-800">
            <div className="flex items-center gap-3">
              {result.isFlagged ? (
                <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40">
                  <AlertTriangle className="w-6 h-6" />
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <ShieldCheck className="w-6 h-6" />
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-lg text-white">{result.verdict}</span>
                  <span
                    className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                      result.isFlagged
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {result.similarityPercentage}% Similarity
                  </span>
                </div>
                <p className="text-xs text-gray-300 mt-0.5">{result.explanation}</p>
              </div>
            </div>

            {/* Metrics Breakdown */}
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="p-2 rounded-lg bg-[#0d1117] border border-gray-800 text-center">
                <div className="text-[10px] text-gray-500 uppercase">Levenshtein Dist</div>
                <div className="font-bold text-amber-400">{result.levenshteinDistance} chars</div>
              </div>
              <div className="p-2 rounded-lg bg-[#0d1117] border border-gray-800 text-center">
                <div className="text-[10px] text-gray-500 uppercase">Token Jaccard</div>
                <div className="font-bold text-blue-400">{result.tokenSimilarity}%</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Side-by-Side Code Editors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Code 1: Submission A */}
        <div className="bg-[#161b22] rounded-xl border border-gray-800 p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400 pb-2 border-b border-gray-800">
            <span className="font-bold text-gray-200 flex items-center gap-1.5">
              <FileCode className="w-3.5 h-3.5 text-blue-400" />
              Submission A (Binary Beasts - Alex Chen)
            </span>
            <span className="font-mono text-[11px] text-gray-500">Source Solution</span>
          </div>
          <textarea
            value={code1}
            onChange={e => setCode1(e.target.value)}
            rows={14}
            className="w-full bg-[#0d1117] text-gray-200 border border-gray-800 rounded-lg p-3 font-mono text-xs focus:border-purple-500 focus:outline-none"
          />
        </div>

        {/* Code 2: Submission B */}
        <div className="bg-[#161b22] rounded-xl border border-gray-800 p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400 pb-2 border-b border-gray-800">
            <span className="font-bold text-gray-200 flex items-center gap-1.5">
              <FileCode className="w-3.5 h-3.5 text-purple-400" />
              Submission B (Peer Submission for Inspection)
            </span>
            <span className="font-mono text-[11px] text-gray-500">Target to Check</span>
          </div>
          <textarea
            value={code2}
            onChange={e => setCode2(e.target.value)}
            rows={14}
            className="w-full bg-[#0d1117] text-gray-200 border border-gray-800 rounded-lg p-3 font-mono text-xs focus:border-purple-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={() => handleRunComparison()}
          disabled={isAnalyzing}
          className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/25 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
        >
          <Play className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
          {isAnalyzing ? 'Calculating Distance...' : 'Compare Code Submissions'}
        </button>
      </div>
    </div>
  );
};
