import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import confetti from 'canvas-confetti';
import {
  Play,
  Send,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  Cpu,
  HelpCircle,
  FileCode,
  ArrowLeft,
  Flame,
  Award,
  Zap,
  ChevronRight,
  Code
} from 'lucide-react';
import { Problem, TestCase, ExecutionResult, User, Team, AIHintResponse } from '../types';
import { api } from '../services/api';

interface ProblemWorkspaceProps {
  problem: Problem;
  initialTestCases: TestCase[];
  currentUser: User | null;
  onBack: () => void;
  onTeamRankJump?: (team: Team) => void;
}

export const ProblemWorkspace: React.FC<ProblemWorkspaceProps> = ({
  problem,
  initialTestCases,
  currentUser,
  onBack,
  onTeamRankJump
}) => {
  const [language, setLanguage] = useState<'javascript' | 'python'>('javascript');
  const [code, setCode] = useState(problem.starterCode.javascript);
  const [activeTab, setActiveTab] = useState<'description' | 'hints' | 'submissions'>('description');
  const [activeTestCaseIndex, setActiveTestCaseIndex] = useState(0);
  const [customInput, setCustomInput] = useState('');
  const [isCustomTab, setIsCustomTab] = useState(false);

  // Execution state
  const [isRunning, setIsRunning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [execResult, setExecResult] = useState<ExecutionResult | null>(null);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState(false);
  const [submissionFeedback, setSubmissionFeedback] = useState<string | null>(null);

  // Failed runs counter (for 3-fails auto hint trigger)
  const [failedRunsCount, setFailedRunsCount] = useState(0);
  const [hints, setHints] = useState<AIHintResponse | null>(null);
  const [isLoadingHints, setIsLoadingHints] = useState(false);
  const [autoHintAlert, setAutoHintAlert] = useState(false);

  // Update starter code when language changes
  useEffect(() => {
    setCode(language === 'javascript' ? problem.starterCode.javascript : problem.starterCode.python);
  }, [language, problem]);

  // Fetch hints when requested or when failedCount >= 3
  const fetchHints = async (failedCount: number) => {
    try {
      setIsLoadingHints(true);
      const res = await api.getAIHints(problem.id, failedCount, code);
      setHints(res);
    } catch (err) {
      console.error('Failed to load AI hints', err);
    } finally {
      setIsLoadingHints(false);
    }
  };

  // Run Tests against sample testcases
  const handleRunTests = async () => {
    try {
      setIsRunning(true);
      setIsSubmittedSuccess(false);
      setSubmissionFeedback(null);

      const result = await api.runTests(
        problem.id,
        code,
        language,
        isCustomTab ? customInput : undefined
      );

      setExecResult(result);

      if (result.status !== 'Accepted') {
        const nextFailed = failedRunsCount + 1;
        setFailedRunsCount(nextFailed);
        if (nextFailed >= 3) {
          setAutoHintAlert(true);
          fetchHints(nextFailed);
        }
      }
    } catch (err: any) {
      console.error('Run failed', err);
    } finally {
      setIsRunning(false);
    }
  };

  // Submit Solution against all test cases (public + hidden)
  const handleFormalSubmit = async () => {
    if (!currentUser) return;
    try {
      setIsSubmitting(true);
      setIsSubmittedSuccess(false);
      setSubmissionFeedback(null);

      const response = await api.submitSolution(problem.id, currentUser.id, code, language);
      setExecResult(response.execution);

      if (response.submission.status === 'Accepted') {
        setIsSubmittedSuccess(true);
        // Trigger celebratory confetti
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });

        const outcome = response.scoreOutcome;
        if (outcome.isFirstAccepted && outcome.teamUpdated) {
          setSubmissionFeedback(
            `Accepted! +${outcome.pointsAwarded} pts awarded! Your squad '${outcome.teamUpdated.name}' gained +${outcome.teamScoreDelta} pts and is now Rank #${outcome.teamUpdated.rank}!`
          );
          if (onTeamRankJump) {
            onTeamRankJump(outcome.teamUpdated);
          }
        } else {
          setSubmissionFeedback('Accepted! All test cases passed with optimal runtime.');
        }
      } else {
        const nextFailed = failedRunsCount + 1;
        setFailedRunsCount(nextFailed);
        if (nextFailed >= 3) {
          setAutoHintAlert(true);
          fetchHints(nextFailed);
        }
      }
    } catch (err: any) {
      console.error('Submission failed', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper to load reference solution for smooth demo presentations
  const handleLoadReferenceSolution = () => {
    if (problem.id === 'prob-1') {
      if (language === 'javascript') {
        setCode(`function twoSumVariant(nums, target) {
  const map = new Map();
  let bestPair = null;
  let minDiff = Infinity;

  for (let j = 0; j < nums.length; j++) {
    const complement = target - nums[j];
    if (map.has(complement)) {
      const i = map.get(complement);
      const diff = Math.abs(nums[i] - nums[j]);
      if (diff < minDiff) {
        minDiff = diff;
        bestPair = [Math.min(i, j), Math.max(i, j)];
      }
    }
    if (!map.has(nums[j])) {
      map.set(nums[j], j);
    }
  }

  return bestPair || [];
}`);
      } else {
        setCode(`def twoSumVariant(nums: list[int], target: int) -> list[int]:
    lookup = {}
    best_pair = []
    min_diff = float('inf')

    for j, val in enumerate(nums):
        complement = target - val
        if complement in lookup:
            i = lookup[complement]
            diff = abs(nums[i] - val)
            if diff < min_diff:
                min_diff = diff
                best_pair = [min(i, j), max(i, j)]
        if val not in lookup:
            lookup[val] = j

    return best_pair`);
      }
    } else {
      setCode(language === 'javascript' ? problem.starterCode.javascript : problem.starterCode.python);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-5rem)]">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#161b22] border-b border-gray-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-xs font-semibold text-gray-400 hover:text-white px-2 py-1 rounded bg-gray-800/80 hover:bg-gray-800 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Library
          </button>
          <div className="h-4 w-[1px] bg-gray-700 hidden sm:block" />
          <h1 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
            <span>{problem.title}</span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                problem.difficulty === 'Easy'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : problem.difficulty === 'Medium'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
              }`}
            >
              {problem.difficulty}
            </span>
          </h1>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-2">
          {/* Quick Demo Pre-load Button */}
          <button
            onClick={handleLoadReferenceSolution}
            className="text-xs px-2.5 py-1 rounded bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 font-medium flex items-center gap-1.5 transition-colors"
            title="Load the optimized canonical solution for testing"
          >
            <Code className="w-3 h-3 text-amber-400" />
            <span className="hidden sm:inline">Load Optimal Solution</span>
          </button>

          {/* Language selector */}
          <select
            value={language}
            onChange={e => setLanguage(e.target.value as any)}
            className="text-xs bg-[#0d1117] text-gray-200 border border-gray-700 rounded-lg px-2.5 py-1 font-mono focus:border-amber-500 focus:outline-none"
          >
            <option value="javascript">JavaScript (Node.js)</option>
            <option value="python">Python 3.14</option>
          </select>

          {/* Reset Code */}
          <button
            onClick={() =>
              setCode(language === 'javascript' ? problem.starterCode.javascript : problem.starterCode.python)
            }
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-gray-800 transition-colors"
            title="Reset to Starter Code"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3-Fails AI Hint Auto Banner */}
      {autoHintAlert && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2 flex items-center justify-between text-xs text-amber-200 animate-fadeIn">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
            <span>
              <strong>AI Hint Assistant Activated!</strong> You have failed 3 test runs. Progressive conceptual
              clues and code diagnosis have been unlocked.
            </span>
          </div>
          <button
            onClick={() => setActiveTab('hints')}
            className="px-2.5 py-0.5 rounded bg-amber-500 text-gray-900 font-bold hover:bg-amber-400 transition-colors"
          >
            View Clues
          </button>
        </div>
      )}

      {/* Success Notification Banner */}
      {isSubmittedSuccess && submissionFeedback && (
        <div className="bg-emerald-500/20 border-b border-emerald-500/40 px-4 py-2.5 flex items-center justify-between text-xs text-emerald-200 animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{submissionFeedback}</span>
          </div>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-300">
            Recorded
          </span>
        </div>
      )}

      {/* Main Workspace Split Pane */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Pane: Problem Description, Examples, AI Hints */}
        <div className="lg:col-span-5 flex flex-col border-r border-gray-800 bg-[#0d1117] overflow-y-auto">
          {/* Sub-tabs header */}
          <div className="flex border-b border-gray-800 bg-[#161b22]/50 px-4">
            <button
              onClick={() => setActiveTab('description')}
              className={`py-2.5 px-3 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'description'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              Description
            </button>
            <button
              onClick={() => {
                setActiveTab('hints');
                if (!hints) fetchHints(Math.max(1, failedRunsCount));
              }}
              className={`py-2.5 px-3 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors relative ${
                activeTab === 'hints'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              AI Hint Assistant
              {failedRunsCount >= 3 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping absolute top-2 right-1" />
              )}
            </button>
          </div>

          {/* Description Content */}
          <div className="p-5 space-y-5 text-gray-300 text-xs sm:text-sm">
            {activeTab === 'description' && (
              <>
                <div>
                  <h3 className="font-bold text-gray-100 mb-2">Problem Statement</h3>
                  <div className="whitespace-pre-line leading-relaxed text-gray-300">
                    {problem.description}
                  </div>
                </div>

                {/* Examples */}
                <div>
                  <h3 className="font-bold text-gray-100 mb-2">Examples</h3>
                  <div className="space-y-3">
                    {problem.examples.map((ex, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg bg-[#161b22] border border-gray-800 space-y-1.5 font-mono text-xs"
                      >
                        <div>
                          <span className="text-gray-400">Input: </span>
                          <span className="text-amber-200">{ex.input}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Output: </span>
                          <span className="text-emerald-300">{ex.output}</span>
                        </div>
                        {ex.explanation && (
                          <div className="text-gray-400 font-sans text-[11px] pt-1 border-t border-gray-800">
                            <strong>Explanation: </strong> {ex.explanation}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Constraints */}
                <div>
                  <h3 className="font-bold text-gray-100 mb-2">Constraints</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-400 font-mono text-xs">
                    {problem.constraints.map((c, idx) => (
                      <li key={idx}>{c}</li>
                    ))}
                  </ul>
                </div>
              </>
            )}

            {activeTab === 'hints' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-gray-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-gray-200">Progressive Non-Spoiler Guidance</span>
                  </div>
                  <button
                    onClick={() => fetchHints(Math.max(3, failedRunsCount))}
                    disabled={isLoadingHints}
                    className="text-[11px] text-amber-400 hover:text-amber-300 underline"
                  >
                    Unlock All Clues
                  </button>
                </div>

                {isLoadingHints && (
                  <div className="p-4 text-center text-gray-400 text-xs">
                    Synthesizing algorithmic clues...
                  </div>
                )}

                {hints && (
                  <>
                    {hints.codeDiagnosis && (
                      <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30">
                        <div className="flex items-center gap-1.5 text-rose-300 font-bold mb-1">
                          <XCircle className="w-3.5 h-3.5" />
                          Code Pitfall Diagnosis
                        </div>
                        <p className="text-xs text-rose-200/90 mb-1">
                          <strong>Detected: </strong> {hints.codeDiagnosis.likelyPitfall}
                        </p>
                        <p className="text-[11px] text-gray-300 font-sans">
                          💡 {hints.codeDiagnosis.suggestion}
                        </p>
                      </div>
                    )}

                    <div className="space-y-3">
                      {hints.unlockedClues.map(clue => (
                        <div
                          key={clue.level}
                          className="p-3.5 rounded-lg bg-[#161b22] border border-gray-800 space-y-1"
                        >
                          <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                            <span>
                              Clue {clue.level}: {clue.title}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400">
                              Unlocked
                            </span>
                          </div>
                          <p className="text-xs text-gray-300 leading-relaxed font-sans">{clue.content}</p>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Pane: Monaco Editor & Testcase Runner Drawer */}
        <div className="lg:col-span-7 flex flex-col bg-[#0b0e14] overflow-hidden">
          {/* Monaco Editor Container */}
          <div className="flex-1 min-h-[340px] border-b border-gray-800">
            <Editor
              height="100%"
              theme="vs-dark"
              language={language === 'javascript' ? 'javascript' : 'python'}
              value={code}
              onChange={val => setCode(val || '')}
              options={{
                minimap: { enabled: false },
                fontSize: 13,
                fontFamily: '"Fira Code", monospace',
                scrollBeyondLastLine: false,
                tabSize: 2,
                automaticLayout: true,
                padding: { top: 12, bottom: 12 }
              }}
            />
          </div>

          {/* Testcases & Execution Drawer */}
          <div className="h-64 flex flex-col bg-[#0d1117]">
            {/* Testcase Tabs Header */}
            <div className="flex items-center justify-between px-3 bg-[#161b22] border-b border-gray-800 text-xs">
              <div className="flex items-center gap-1 overflow-x-auto py-1">
                {initialTestCases.map((tc, idx) => {
                  const testDetail = execResult?.details?.find(d => d.testCaseId === tc.id);
                  return (
                    <button
                      key={tc.id}
                      onClick={() => {
                        setIsCustomTab(false);
                        setActiveTestCaseIndex(idx);
                      }}
                      className={`px-3 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
                        !isCustomTab && activeTestCaseIndex === idx
                          ? 'bg-gray-800 text-white font-bold'
                          : 'text-gray-400 hover:text-gray-200'
                      }`}
                    >
                      Case {idx + 1}
                      {testDetail && (
                        testDetail.passed ? (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        ) : (
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                        )
                      )}
                    </button>
                  );
                })}

                <button
                  onClick={() => setIsCustomTab(true)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                    isCustomTab ? 'bg-gray-800 text-white font-bold' : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  + Custom Case
                </button>
              </div>

              {/* Execution Summary Badges if result exists */}
              {execResult && (
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      execResult.status === 'Accepted'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}
                  >
                    {execResult.status} ({execResult.passedCount}/{execResult.totalCount})
                  </span>
                  <span className="text-[11px] text-gray-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {execResult.runtimeMs}ms
                  </span>
                </div>
              )}
            </div>

            {/* Testcase Display Body */}
            <div className="flex-1 p-3 overflow-y-auto text-xs font-mono">
              {isCustomTab ? (
                <div className="space-y-2">
                  <div className="text-gray-400 text-[11px]">
                    Enter custom test input as JSON array of function parameters:
                  </div>
                  <input
                    type="text"
                    value={customInput}
                    onChange={e => setCustomInput(e.target.value)}
                    placeholder='e.g. [[2, 7, 11, 15], 9]'
                    className="w-full bg-[#161b22] text-gray-200 border border-gray-700 rounded p-2 text-xs font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              ) : (
                initialTestCases[activeTestCaseIndex] && (
                  <div className="space-y-2">
                    <div>
                      <div className="text-gray-500 text-[11px]">Input:</div>
                      <div className="p-2 rounded bg-[#161b22] border border-gray-800 text-gray-200">
                        {initialTestCases[activeTestCaseIndex].input}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-500 text-[11px]">Expected Output:</div>
                      <div className="p-2 rounded bg-[#161b22] border border-gray-800 text-emerald-300">
                        {initialTestCases[activeTestCaseIndex].expectedOutput}
                      </div>
                    </div>

                    {/* Actual output from execution */}
                    {execResult?.details && (
                      <div>
                        <div className="text-gray-500 text-[11px]">Your Output:</div>
                        <div
                          className={`p-2 rounded border text-xs font-mono ${
                            execResult.details[activeTestCaseIndex]?.passed
                              ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                              : 'bg-rose-950/20 border-rose-500/30 text-rose-300'
                          }`}
                        >
                          {execResult.details[activeTestCaseIndex]?.actual !== undefined
                            ? execResult.details[activeTestCaseIndex].actual
                            : execResult.details[activeTestCaseIndex]?.error || 'Not executed'}
                        </div>
                      </div>
                    )}
                  </div>
                )
              )}
            </div>

            {/* Run & Submit Action Footer */}
            <div className="px-4 py-2.5 bg-[#161b22] border-t border-gray-800 flex items-center justify-between">
              <div className="text-[11px] text-gray-400 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  Submit passes 5/5 public & hidden edge cases to score points.
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunTests}
                  disabled={isRunning || isSubmitting}
                  className="px-4 py-2 rounded-lg text-xs font-bold bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <Play className={`w-3.5 h-3.5 text-emerald-400 ${isRunning ? 'animate-spin' : ''}`} />
                  Run Tests
                </button>

                <button
                  onClick={handleFormalSubmit}
                  disabled={isRunning || isSubmitting}
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50"
                >
                  <Send className={`w-3.5 h-3.5 ${isSubmitting ? 'animate-pulse' : ''}`} />
                  Submit Solution
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
