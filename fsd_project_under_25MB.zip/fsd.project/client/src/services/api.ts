import {
  Problem,
  TestCase,
  Team,
  User,
  Submission,
  ExecutionResult,
  DerbySession,
  AIHintResponse,
  PlagiarismComparisonResult
} from '../types';

const API_BASE = '/api';

export const api = {
  // Problems
  async getProblems(filters?: { difficulty?: string; category?: string; tag?: string; search?: string }): Promise<Problem[]> {
    const params = new URLSearchParams();
    if (filters?.difficulty) params.append('difficulty', filters.difficulty);
    if (filters?.category) params.append('category', filters.category);
    if (filters?.tag) params.append('tag', filters.tag);
    if (filters?.search) params.append('search', filters.search);

    const res = await fetch(`${API_BASE}/problems?${params.toString()}`);
    const data = await res.json();
    return data.problems;
  },

  async getDailyProblem(): Promise<{ problem: Problem; testCases: TestCase[] }> {
    const res = await fetch(`${API_BASE}/problems/daily`);
    const data = await res.json();
    return { problem: data.problem, testCases: data.testCases };
  },

  async getProblemById(idOrSlug: string): Promise<{ problem: Problem; testCases: TestCase[] }> {
    const res = await fetch(`${API_BASE}/problems/${idOrSlug}`);
    const data = await res.json();
    return { problem: data.problem, testCases: data.testCases };
  },

  // Code Execution
  async runTests(
    problemId: string,
    code: string,
    language: 'javascript' | 'python',
    customInput?: string
  ): Promise<ExecutionResult> {
    const res = await fetch(`${API_BASE}/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ problemId, code, language, customInput })
    });
    const data = await res.json();
    return data.result;
  },

  async submitSolution(
    problemId: string,
    userId: string,
    code: string,
    language: 'javascript' | 'python'
  ): Promise<{
    submission: Submission;
    execution: ExecutionResult;
    scoreOutcome: {
      pointsAwarded: number;
      teamScoreDelta: number;
      streakBonusDelta: number;
      speedBonusDelta: number;
      isFirstAccepted: boolean;
      teamUpdated?: Team;
    };
    updatedUser: User;
    leaderboard: Team[];
  }> {
    const res = await fetch(`${API_BASE}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ problemId, userId, code, language })
    });
    return await res.json();
  },

  async getSubmissions(problemId?: string, userId?: string): Promise<Submission[]> {
    const params = new URLSearchParams();
    if (problemId) params.append('problemId', problemId);
    if (userId) params.append('userId', userId);
    const res = await fetch(`${API_BASE}/submissions?${params.toString()}`);
    const data = await res.json();
    return data.submissions;
  },

  // Teams & Leaderboards
  async getTeams(): Promise<Team[]> {
    const res = await fetch(`${API_BASE}/teams`);
    const data = await res.json();
    return data.teams;
  },

  async getTeamById(id: string): Promise<Team> {
    const res = await fetch(`${API_BASE}/teams/${id}`);
    const data = await res.json();
    return data.team;
  },

  async createTeam(data: { name: string; tagline: string; avatar: string; batch: string; creatorUserId: string }): Promise<Team> {
    const res = await fetch(`${API_BASE}/teams`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error);
    return json.team;
  },

  async joinTeam(joinCode: string, userId: string): Promise<Team> {
    const res = await fetch(`${API_BASE}/teams/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ joinCode, userId })
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error);
    return json.team;
  },

  // Users
  async getUsers(): Promise<User[]> {
    const res = await fetch(`${API_BASE}/users`);
    const data = await res.json();
    return data.users;
  },

  async getUserById(id: string): Promise<User> {
    const res = await fetch(`${API_BASE}/users/${id}`);
    const data = await res.json();
    return data.user;
  },

  // Derby Live War Arena
  async getDerbySession(): Promise<DerbySession> {
    const res = await fetch(`${API_BASE}/derby`);
    const data = await res.json();
    return data.session;
  },

  // AI Hints
  async getAIHints(problemId: string, failedCount: number, userCode?: string): Promise<AIHintResponse> {
    const res = await fetch(`${API_BASE}/hints`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ problemId, failedCount, userCode })
    });
    const data = await res.json();
    return data.hints;
  },

  // Plagiarism Checker
  async comparePlagiarism(code1: string, code2: string): Promise<PlagiarismComparisonResult> {
    const res = await fetch(`${API_BASE}/plagiarism/compare`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code1, code2 })
    });
    const data = await res.json();
    return data.analysis;
  },

  // Demo Reset
  async resetDemo(): Promise<{ teams: Team[]; user: User }> {
    const res = await fetch(`${API_BASE}/demo/reset`, { method: 'POST' });
    const data = await res.json();
    return { teams: data.teams, user: data.user };
  }
};
