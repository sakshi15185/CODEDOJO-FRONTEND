import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DailyBanner } from './components/DailyBanner';
import { ProblemList } from './components/ProblemList';
import { ProblemWorkspace } from './components/ProblemWorkspace';
import { TeamLeaderboard } from './components/TeamLeaderboard';
import { TeamManagement } from './components/TeamManagement';
import { TeamWarArena } from './components/TeamWarArena';
import { PlagiarismChecker } from './components/PlagiarismChecker';
import { StreakCalendar } from './components/StreakCalendar';
import { Problem, TestCase, Team, User } from './types';
import { api } from './services/api';
import { Trophy, TrendingUp, Sparkles, CheckCircle2 } from 'lucide-react';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'daily' | 'problems' | 'leaderboard' | 'team' | 'derby' | 'plagiarism'>('daily');
  const [activeProblem, setActiveProblem] = useState<Problem | null>(null);
  const [workspaceTestCases, setWorkspaceTestCases] = useState<TestCase[]>([]);

  // Core Data
  const [problems, setProblems] = useState<Problem[]>([]);
  const [dailyProblem, setDailyProblem] = useState<Problem | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());

  // UI state
  const [isLoading, setIsLoading] = useState(true);
  const [isResetting, setIsResetting] = useState(false);
  const [rankJumpNotice, setRankJumpNotice] = useState<string | null>(null);

  // Initial load
  useEffect(() => {
    const initData = async () => {
      try {
        setIsLoading(true);
        const [probs, daily, tms, usrs] = await Promise.all([
          api.getProblems(),
          api.getDailyProblem(),
          api.getTeams(),
          api.getUsers()
        ]);

        setProblems(probs);
        setDailyProblem(daily.problem);
        setTeams(tms);
        setUsers(usrs);

        // Default to Alex Chen (Captain of Binary Beasts)
        const defaultUser = usrs.find(u => u.id === 'user-alex') || usrs[0];
        setCurrentUser(defaultUser);
      } catch (err) {
        console.error('Failed to initialize CodeDojo Daily', err);
      } finally {
        setIsLoading(false);
      }
    };

    initData();
  }, []);

  // Poll teams every 5 seconds for real-time scoreboard synchronization
  useEffect(() => {
    const pollInterval = setInterval(async () => {
      try {
        const updatedTeams = await api.getTeams();
        setTeams(updatedTeams);
        setLastSyncTime(new Date());

        if (currentUser) {
          const freshUser = await api.getUserById(currentUser.id);
          setCurrentUser(freshUser);
        }
      } catch (err) {
        // Silently catch polling errors
      }
    }, 5000);

    return () => clearInterval(pollInterval);
  }, [currentUser?.id]);

  // Handle solving a problem: open in workspace
  const handleOpenProblem = async (prob: Problem) => {
    try {
      const data = await api.getProblemById(prob.id);
      setActiveProblem(data.problem);
      setWorkspaceTestCases(data.testCases);
    } catch (err) {
      console.error('Failed to load problem details', err);
    }
  };

  // Handle Team Rank Jump celebratory toast
  const handleTeamRankJump = (updatedTeam: Team) => {
    if (updatedTeam.rank === 1 && updatedTeam.rankChange > 0) {
      setRankJumpNotice(
        `🚀 SQUAD CLIMB! ${updatedTeam.name} climbed from Rank #${updatedTeam.previousRank} to #1 on the Contest Leaderboard!`
      );
      setTimeout(() => setRankJumpNotice(null), 8000);
    }
  };

  // Demo Reset: resets Binary Beasts to 3rd place so presenter can replay anytime
  const handleResetDemo = async () => {
    try {
      setIsResetting(true);
      const res = await api.resetDemo();
      setTeams(res.teams);
      setCurrentUser(res.user);
      setRankJumpNotice('Demo state restored! Binary Beasts is back at Rank #3 (2520 pts). Ready for presentation.');
      setTimeout(() => setRankJumpNotice(null), 5000);
    } catch (err) {
      console.error('Failed to reset demo', err);
    } finally {
      setIsResetting(false);
    }
  };

  const currentTeam = teams.find(t => t.id === currentUser?.teamId) || null;
  const userSolvedIds = problems.filter(p => currentUser?.activityHistory && (currentUser.score > 850 && p.id === 'prob-1')).map(p => p.id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0b0e14] flex flex-col items-center justify-center text-gray-400 gap-3">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 animate-spin p-1">
          <div className="w-full h-full bg-[#0b0e14] rounded-lg" />
        </div>
        <div className="text-sm font-semibold tracking-wide text-gray-300">
          Loading CodeDojo Daily Arena...
        </div>
      </div>
    );
  }

  // If viewing Workspace
  if (activeProblem) {
    return (
      <div className="min-h-screen bg-[#0b0e14] flex flex-col">
        <Navbar
          activeTab={activeTab}
          setActiveTab={tab => {
            setActiveProblem(null);
            setActiveTab(tab);
          }}
          currentUser={currentUser}
          users={users}
          onSelectUser={u => setCurrentUser(u)}
          onResetDemo={handleResetDemo}
          isResetting={isResetting}
        />
        <ProblemWorkspace
          problem={activeProblem}
          initialTestCases={workspaceTestCases}
          currentUser={currentUser}
          onBack={() => setActiveProblem(null)}
          onTeamRankJump={handleTeamRankJump}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0e14] flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        users={users}
        onSelectUser={u => setCurrentUser(u)}
        onResetDemo={handleResetDemo}
        isResetting={isResetting}
      />

      {/* Rank Jump Toast Notification */}
      {rankJumpNotice && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white text-xs sm:text-sm font-bold py-2.5 px-4 text-center shadow-lg flex items-center justify-center gap-2 animate-bounce">
          <Trophy className="w-4 h-4 text-yellow-200" />
          <span>{rankJumpNotice}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'daily' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Daily Challenge Hero Banner */}
            <DailyBanner
              dailyProblem={dailyProblem}
              currentUser={currentUser}
              onSolveClick={handleOpenProblem}
            />

            {/* Streak & Activity Heatmap */}
            {currentUser && <StreakCalendar user={currentUser} />}

            {/* Quick Leaderboard Preview */}
            <div className="pt-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  Live Squad Standings
                </h3>
                <button
                  onClick={() => setActiveTab('leaderboard')}
                  className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  View Full Leaderboard & Formula →
                </button>
              </div>
              <TeamLeaderboard
                teams={teams}
                currentUser={currentUser}
                lastUpdated={lastSyncTime}
              />
            </div>
          </div>
        )}

        {activeTab === 'problems' && (
          <div className="animate-fadeIn">
            <ProblemList
              problems={problems}
              onSelectProblem={handleOpenProblem}
              userSolvedProblemIds={userSolvedIds}
            />
          </div>
        )}

        {activeTab === 'leaderboard' && (
          <div className="animate-fadeIn">
            <TeamLeaderboard
              teams={teams}
              currentUser={currentUser}
              lastUpdated={lastSyncTime}
            />
          </div>
        )}

        {activeTab === 'team' && (
          <div className="animate-fadeIn">
            <TeamManagement
              currentTeam={currentTeam}
              currentUser={currentUser}
              allTeams={teams}
              onTeamUpdated={async () => {
                const updatedTeams = await api.getTeams();
                setTeams(updatedTeams);
                if (currentUser) {
                  const freshUser = await api.getUserById(currentUser.id);
                  setCurrentUser(freshUser);
                }
              }}
            />
          </div>
        )}

        {activeTab === 'derby' && (
          <div className="animate-fadeIn">
            <TeamWarArena
              teams={teams}
              problems={problems}
              onSelectProblem={handleOpenProblem}
            />
          </div>
        )}

        {activeTab === 'plagiarism' && (
          <div className="animate-fadeIn">
            <PlagiarismChecker />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800/80 bg-[#0d1117] py-6 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-amber-400">CodeDojo Daily</span>
            <span>• DailyDebug Derby Hackathon Platform</span>
          </div>
          <div>Built for Computer Science Campus Placement Prep & Cohort Collaboration</div>
        </div>
      </footer>
    </div>
  );
};

export default App;
