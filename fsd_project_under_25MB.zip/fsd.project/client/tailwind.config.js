/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        dojo: {
          dark: '#0d1117',
          card: '#161b22',
          border: '#30363d',
          gold: '#e3b341',
          crimson: '#f85149',
          emerald: '#2ea043',
          cyan: '#388bfd',
          purple: '#a371f7'
        }
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'Menlo', 'Consolas', 'Courier New', 'monospace'],
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif']
      }
    },
  },
  plugins: [],
}
